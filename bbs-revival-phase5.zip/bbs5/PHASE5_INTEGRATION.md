# Phase 5 — Integration Instructions

No new npm dependencies. No changes to tsconfig or turbo.

---

## Run the Phase 5 Migration

```bash
pnpm --filter server tsx src/db/migrate-phase5.ts
```

Adds 4 migrations (022–025):
- `door_games` table + 5 seeded games
- `door_sessions` table (session lifecycle + scores)
- `door_scores` table (leaderboard entries)

---

## New Files — copy into place

### Server
```
apps/server/src/db/migrate-phase5.ts           → copy as-is
apps/server/src/games/base.ts                  → copy as-is
apps/server/src/games/guess.ts                 → copy as-is
apps/server/src/games/trivia.ts                → copy as-is
apps/server/src/games/hangman.ts               → copy as-is
apps/server/src/games/blackjack.ts             → copy as-is
apps/server/src/games/dungeon.ts               → copy as-is
apps/server/src/games/registry.ts             → copy as-is
apps/server/src/services/door.service.ts       → copy as-is
apps/server/src/routes/door.routes.ts          → copy as-is
```

### Web
```
apps/web/src/pages/DoorsPage.tsx               → copy as-is
apps/web/src/pages/DoorsPage.module.css        → copy as-is
```

---

## Files to Replace Entirely

```
apps/server/src/plugins/socket.ts  → replace (adds door:input routing to game engine)
apps/server/src/index.ts           → replace (registers doorRoutes)
apps/web/src/stores/socket.store.ts → replace (minor cleanup; door events handled in DoorsPage)
apps/web/src/App.tsx               → replace (adds /doors route)
```

Shell.tsx and Shell.module.css are unchanged from Phase 3.

---

## After Merging — Test It

```bash
pnpm dev
```

1. Click **Door Games** in the sidebar
2. You'll see 5 games: Number Guesser, BBS Trivia, Hangman, BlackJack 21, Dungeon Crawler
3. Click a game — see the description and leaderboard (empty on first run)
4. Click **▶ PLAY** — the terminal opens and the game starts streaming
5. Type your input and press Enter
6. When the game ends, your score appears and the leaderboard reloads
7. Play a second time — your score shows on the board

---

## Adding a Custom Game

1. Create `apps/server/src/games/mygame.ts` implementing the `DoorGame` interface
2. Import and add it to `apps/server/src/games/registry.ts`
3. INSERT a row into `door_games` with the matching `slug`

The game engine is purely text I/O — `ctx.emit(string)` sends ANSI output to the terminal, `ctx.end(score)` ends the session and records the score.

---

## What's New in Phase 5

| Feature | Detail |
|---------|--------|
| Door game lobby | List of all enabled games with play counts |
| WebSocket terminal | ANSI-rendered output streamed from server |
| Line-based input | Enter-to-submit, echoed to terminal |
| Session management | Tracks start/end, cleans up on disconnect |
| Score recording | Every completed game saves to door_scores |
| Global leaderboards | Top 10 per game with rank medals |
| Number Guesser | Classic 1–100 guessing game, 10 tries |
| BBS Trivia | 7 shuffled questions on BBS/retro history |
| Hangman | BBS-themed word list, gallows ASCII art |
| BlackJack 21 | Full BJ with chip stack, multi-hand |
| Dungeon Crawler | 5-floor dungeon with combat, shop, loot |
| Extensible engine | Add games by implementing DoorGame interface |
