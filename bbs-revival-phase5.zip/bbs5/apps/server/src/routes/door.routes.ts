import type { FastifyInstance } from 'fastify';
import { getDoorGames, getLeaderboard, getUserBestScores } from '../services/door.service.js';
import type { UserRole } from '@bbs/shared';

function getUser(req: { user?: unknown }) {
  return req.user as { sub: string; role: UserRole };
}

export async function doorRoutes(fastify: FastifyInstance) {
  // GET /api/doors
  fastify.get('/', { preHandler: [fastify.authenticate] }, async (request, reply) => {
    const { role } = getUser(request);
    const games = await getDoorGames(role);
    return reply.send({ ok: true, data: games });
  });

  // GET /api/doors/:gameId/leaderboard
  fastify.get('/:gameId/leaderboard', { preHandler: [fastify.authenticate] }, async (request, reply) => {
    const { gameId } = request.params as { gameId: string };
    const board = await getLeaderboard(gameId);
    return reply.send({ ok: true, data: board });
  });

  // GET /api/doors/me/scores
  fastify.get('/me/scores', { preHandler: [fastify.authenticate] }, async (request, reply) => {
    const { sub } = getUser(request);
    const scores = await getUserBestScores(sub);
    return reply.send({ ok: true, data: scores });
  });
}
