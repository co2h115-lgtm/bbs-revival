import { db } from '../db/pool.js';

const migrations = [
  {
    name: '022_create_door_games',
    sql: `
      CREATE TABLE door_games (
        id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        slug          VARCHAR(32) UNIQUE NOT NULL,
        name          VARCHAR(64) NOT NULL,
        description   TEXT,
        author        VARCHAR(64),
        min_role      user_role NOT NULL DEFAULT 'validated',
        max_players   INTEGER NOT NULL DEFAULT 1,
        has_scores    BOOLEAN NOT NULL DEFAULT TRUE,
        enabled       BOOLEAN NOT NULL DEFAULT TRUE,
        play_count    INTEGER NOT NULL DEFAULT 0,
        created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
    `,
  },
  {
    name: '023_create_door_sessions',
    sql: `
      CREATE TABLE door_sessions (
        id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        game_id     UUID NOT NULL REFERENCES door_games(id) ON DELETE CASCADE,
        user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        started_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        ended_at    TIMESTAMPTZ,
        score       INTEGER,
        meta        JSONB NOT NULL DEFAULT '{}'
      );

      CREATE INDEX idx_door_sessions_game ON door_sessions(game_id);
      CREATE INDEX idx_door_sessions_user ON door_sessions(user_id);
    `,
  },
  {
    name: '024_create_door_scores',
    sql: `
      CREATE TABLE door_scores (
        id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        game_id    UUID NOT NULL REFERENCES door_games(id) ON DELETE CASCADE,
        user_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        score      INTEGER NOT NULL,
        meta       JSONB NOT NULL DEFAULT '{}',
        achieved_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );

      CREATE INDEX idx_door_scores_game_score ON door_scores(game_id, score DESC);
      CREATE INDEX idx_door_scores_user       ON door_scores(user_id);
    `,
  },
  {
    name: '025_seed_door_games',
    sql: `
      INSERT INTO door_games (slug, name, description, author, min_role, has_scores) VALUES
        ('guess',    'Number Guesser',   'Guess the secret number in as few tries as possible. Classic BBS game.', 'BBS Revival', 'new', true),
        ('trivia',   'BBS Trivia',       'Test your knowledge of BBS history and retro computing culture.',         'BBS Revival', 'new', true),
        ('dungeon',  'Dungeon Crawler',  'A simple text-based dungeon exploration game. How deep can you go?',      'BBS Revival', 'validated', true),
        ('hangman',  'Hangman',          'Classic word-guessing game. Guess the word before the man is hung!',      'BBS Revival', 'new', true),
        ('blackjack','BlackJack 21',     'Beat the dealer. Stands on soft 17. Purely for entertainment.',           'BBS Revival', 'validated', true)
      ON CONFLICT (slug) DO NOTHING;
    `,
  },
];

async function runMigrations() {
  const client = await db.connect();
  try {
    await client.query(`
      CREATE TABLE IF NOT EXISTS schema_migrations (
        name TEXT PRIMARY KEY,
        applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      )
    `);
    for (const m of migrations) {
      const { rows } = await client.query(
        'SELECT name FROM schema_migrations WHERE name = $1', [m.name]
      );
      if (rows.length > 0) { console.log(`  ✓ ${m.name}`); continue; }
      await client.query('BEGIN');
      try {
        await client.query(m.sql);
        await client.query('INSERT INTO schema_migrations (name) VALUES ($1)', [m.name]);
        await client.query('COMMIT');
        console.log(`  ✅ ${m.name}`);
      } catch (e) { await client.query('ROLLBACK'); throw e; }
    }
    console.log('\n✅ Phase 5 migrations complete.\n');
  } finally {
    client.release();
    await db.end();
  }
}

runMigrations().catch((e) => { console.error('❌', e); process.exit(1); });
