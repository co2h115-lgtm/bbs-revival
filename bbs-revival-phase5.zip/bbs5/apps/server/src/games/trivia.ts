import type { DoorGame, GameContext } from './base.js';
import { A, banner } from './base.js';

const QUESTIONS = [
  { q: 'What year was the first BBS (CBBS) launched?',           a: '1978', hint: '197_' },
  { q: 'What does BBS stand for?',                               a: 'bulletin board system', hint: 'B_lletin B_ard S_stem' },
  { q: 'What protocol was commonly used for file transfers on BBS?', a: 'zmodem', hint: 'z_____' },
  { q: 'What is the name of the first IBM PC BBS software?',     a: 'rbbs-pc', hint: 'r___-pc' },
  { q: 'What modem speed (bps) was common in 1984?',             a: '1200', hint: '1___' },
  { q: 'What protocol allowed real-time chat on BBS networks?',  a: 'irc', hint: 'i__' },
  { q: 'What does ANSI stand for in ANSI art?',                  a: 'american national standards institute', hint: 'A_______ N_______ S________ I_________' },
  { q: 'What file archiver was dominant in the DOS BBS era?',    a: 'pkzip', hint: 'pk___' },
  { q: 'What network connected BBS systems via FidoNet echos?',  a: 'fidonet', hint: 'f______' },
  { q: 'What does the "door" in "door game" refer to?',          a: 'external program', hint: 'e_______ p_______' },
];

interface State {
  qIdx: number;
  score: number;
  answered: number;
  wrongThisQ: number;
  total: number;
}

const sessions = new Map<string, State>();

function shuffled<T>(arr: T[]): T[] {
  return [...arr].sort(() => Math.random() - 0.5);
}

export const TriviaGame: DoorGame = {
  slug: 'trivia',
  name: 'BBS Trivia',

  start(ctx) {
    const qs = shuffled(QUESTIONS).slice(0, 7);
    (ctx as unknown as { _qs: typeof QUESTIONS })._qs = qs;
    sessions.set(ctx.sessionId, { qIdx: 0, score: 0, answered: 0, wrongThisQ: 0, total: qs.length });

    ctx.emit(
      A.clr +
      banner('BBS TRIVIA', A.yellow) +
      `${A.cyan}Test your knowledge of BBS history & retro computing!\n` +
      `${A.dim}Type your answer and press Enter. Not case-sensitive.\n` +
      `${A.yellow}${qs.length} questions · scoring: 300/200/100 for 1st/2nd/3rd attempt\n\n` +
      A.reset
    );
    askQuestion(ctx, qs, 0);
  },

  input(ctx, line) {
    const state = sessions.get(ctx.sessionId);
    const qs = (ctx as unknown as { _qs: typeof QUESTIONS })._qs;
    if (!state || !qs) return;

    const q = qs[state.qIdx];
    const answer = line.trim().toLowerCase();
    const correct = q.a.toLowerCase();

    if (answer === correct || correct.split(' ').some((w) => answer === w && w.length > 4)) {
      // Correct
      const pts = state.wrongThisQ === 0 ? 300 : state.wrongThisQ === 1 ? 200 : 100;
      state.score += pts;
      state.answered++;
      state.wrongThisQ = 0;

      ctx.emit(
        `${A.bgreen}✓ CORRECT! ${A.yellow}+${pts} points${A.reset}  ` +
        `Total: ${A.bwhite}${state.score}${A.reset}\n\n`
      );

      state.qIdx++;
      if (state.qIdx >= qs.length) {
        // Game over
        sessions.delete(ctx.sessionId);
        const pct = Math.round((state.answered / state.total) * 100);
        ctx.emit(
          `${A.bold}${A.cyan}━━━━━━━━━━━━━━━━ GAME OVER ━━━━━━━━━━━━━━━━${A.reset}\n` +
          `${A.yellow}You answered ${state.answered}/${state.total} (${pct}%) correctly.\n` +
          `${A.bwhite}Final Score: ${state.score} points${A.reset}\n\n` +
          `${A.dim}Press Enter to exit...${A.reset}`
        );
        ctx.end(state.score);
      } else {
        askQuestion(ctx, qs, state.qIdx);
      }
    } else {
      state.wrongThisQ++;
      if (state.wrongThisQ >= 3) {
        ctx.emit(
          `${A.red}✗ The answer was: ${A.bwhite}${q.a}${A.reset}\n\n`
        );
        state.qIdx++;
        state.wrongThisQ = 0;
        if (state.qIdx >= qs.length) {
          sessions.delete(ctx.sessionId);
          ctx.emit(
            `${A.bold}${A.cyan}━━━━━━ GAME OVER ━━━━━━${A.reset}\n` +
            `${A.bwhite}Final Score: ${state.score}${A.reset}\n\n` +
            `${A.dim}Press Enter to exit...${A.reset}`
          );
          ctx.end(state.score);
        } else {
          askQuestion(ctx, qs, state.qIdx);
        }
      } else {
        const attemptsLeft = 3 - state.wrongThisQ;
        ctx.emit(
          `${A.red}✗ Wrong.${A.reset}  ` +
          `${A.dim}Hint: ${q.hint}  (${attemptsLeft} ${attemptsLeft === 1 ? 'attempt' : 'attempts'} left)${A.reset}\n` +
          `${A.cyan}Your answer: ${A.reset}`
        );
      }
    }
  },

  cleanup(ctx) { sessions.delete(ctx.sessionId); },
};

function askQuestion(ctx: GameContext, qs: typeof QUESTIONS, idx: number) {
  const q = qs[idx];
  const num = idx + 1;
  const total = qs.length;
  ctx.emit(
    `${A.bold}${A.cyan}Question ${num}/${total}${A.reset}\n` +
    `${A.bwhite}${q.q}${A.reset}\n` +
    `${A.cyan}Your answer: ${A.reset}`
  );
}
