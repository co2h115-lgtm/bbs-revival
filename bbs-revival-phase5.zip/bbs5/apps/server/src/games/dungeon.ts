import type { DoorGame, GameContext } from './base.js';
import { A, banner } from './base.js';

interface Monster { name: string; hp: number; maxHp: number; attack: number; xp: number; gold: number; }
interface Player  { hp: number; maxHp: number; attack: number; defense: number; xp: number; level: number; gold: number; floor: number; }

type Phase = 'explore' | 'combat' | 'shop' | 'dead' | 'won';

interface State { player: Player; monster: Monster | null; phase: Phase; }

const MONSTERS_BY_FLOOR: Record<number, Monster[]> = {
  1: [
    { name: 'Rat',     hp: 8,  maxHp: 8,  attack: 2,  xp: 10,  gold: 5  },
    { name: 'Bat',     hp: 6,  maxHp: 6,  attack: 3,  xp: 12,  gold: 3  },
  ],
  2: [
    { name: 'Goblin',  hp: 15, maxHp: 15, attack: 5,  xp: 20,  gold: 10 },
    { name: 'Spider',  hp: 12, maxHp: 12, attack: 6,  xp: 18,  gold: 8  },
  ],
  3: [
    { name: 'Orc',     hp: 25, maxHp: 25, attack: 8,  xp: 35,  gold: 20 },
    { name: 'Zombie',  hp: 30, maxHp: 30, attack: 6,  xp: 30,  gold: 15 },
  ],
  4: [
    { name: 'Troll',   hp: 40, maxHp: 40, attack: 12, xp: 55,  gold: 35 },
    { name: 'Witch',   hp: 35, maxHp: 35, attack: 15, xp: 60,  gold: 30 },
  ],
  5: [
    { name: 'Dragon',  hp: 80, maxHp: 80, attack: 20, xp: 150, gold: 100 },
  ],
};

const sessions = new Map<string, State>();

function xpForLevel(lvl: number): number { return lvl * 50; }

function renderStatus(p: Player): string {
  const hpColor = p.hp / p.maxHp < 0.3 ? A.bred : p.hp / p.maxHp < 0.6 ? A.yellow : A.bgreen;
  return (
    `${A.dim}${'─'.repeat(50)}${A.reset}\n` +
    `${A.bwhite}Lv.${p.level} ${A.cyan}❤ ${hpColor}${p.hp}/${p.maxHp}${A.reset}  ` +
    `${A.yellow}⚔ ${p.attack}  ${A.cyan}🛡 ${p.defense}${A.reset}  ` +
    `${A.byellow}💰 ${p.gold}${A.reset}  ` +
    `${A.dim}Floor ${p.floor}/5  XP ${p.xp}/${xpForLevel(p.level)}${A.reset}\n` +
    `${A.dim}${'─'.repeat(50)}${A.reset}\n`
  );
}

function tryLevelUp(p: Player, ctx: GameContext): void {
  while (p.xp >= xpForLevel(p.level)) {
    p.xp -= xpForLevel(p.level);
    p.level++;
    p.maxHp += 10;
    p.hp = p.maxHp;
    p.attack += 3;
    p.defense += 1;
    ctx.emit(`${A.bold}${A.byellow}✨ LEVEL UP! You are now Level ${p.level}!${A.reset}\n`);
  }
}

function spawnMonster(floor: number): Monster {
  const pool = MONSTERS_BY_FLOOR[Math.min(floor, 5)];
  const template = pool[Math.floor(Math.random() * pool.length)];
  return { ...template };
}

export const DungeonGame: DoorGame = {
  slug: 'dungeon',
  name: 'Dungeon Crawler',

  start(ctx) {
    const player: Player = {
      hp: 30, maxHp: 30, attack: 8, defense: 2,
      xp: 0, level: 1, gold: 20, floor: 1,
    };
    sessions.set(ctx.sessionId, { player, monster: null, phase: 'explore' });

    ctx.emit(
      A.clr +
      banner('DUNGEON CRAWLER', A.magenta) +
      `${A.cyan}You enter a dark dungeon seeking treasure and glory.\n` +
      `Descend 5 floors and defeat the Dragon to win!\n\n` +
      `${A.dim}Commands: [E]xplore  [D]escend  [S]hop  [Q]uit${A.reset}\n\n` +
      renderStatus(player) +
      `${A.cyan}> ${A.reset}`
    );
  },

  input(ctx, line) {
    const state = sessions.get(ctx.sessionId);
    if (!state) return;
    const { player } = state;
    const cmd = line.trim().toLowerCase();

    // ── Combat phase ─────────────────────────────────────
    if (state.phase === 'combat') {
      const m = state.monster!;
      if (cmd === 'f' || cmd === 'fight' || cmd === 'a' || cmd === 'attack') {
        // Player attacks
        const pDmg = Math.max(1, player.attack - Math.floor(Math.random() * 3));
        m.hp -= pDmg;
        let out = `${A.bgreen}You hit the ${m.name} for ${pDmg} damage!${A.reset}\n`;

        if (m.hp <= 0) {
          player.xp  += m.xp;
          player.gold += m.gold;
          out += `${A.byellow}${m.name} defeated! +${m.xp} XP, +${m.gold} gold${A.reset}\n`;
          tryLevelUp(player, ctx);
          state.monster = null;
          state.phase = 'explore';
          ctx.emit(
            out + renderStatus(player) +
            (player.floor >= 5 && state.phase === 'explore'
              ? `${A.bgreen}${A.bold}You defeated the DRAGON! You WIN!${A.reset}\n\n${A.dim}Press Enter to exit...${A.reset}`
              : `${A.cyan}> ${A.reset}`)
          );
          if (player.floor >= 5 && m.name === 'Dragon') {
            sessions.delete(ctx.sessionId);
            ctx.end(player.gold + player.level * 100);
          }
          return;
        }

        // Monster attacks
        const mDmg = Math.max(1, m.attack - player.defense - Math.floor(Math.random() * 3));
        player.hp -= mDmg;
        out += `${A.bred}${m.name} hits you for ${mDmg} damage!${A.reset}\n`;

        if (player.hp <= 0) {
          player.hp = 0;
          state.phase = 'dead';
          sessions.delete(ctx.sessionId);
          ctx.emit(
            out + renderStatus(player) +
            `\n${A.bred}${A.bold}YOU HAVE DIED... ☠${A.reset}\n` +
            `${A.dim}Reached floor ${player.floor}. Final score: ${player.gold + player.level * 50}\n` +
            `Press Enter to exit...${A.reset}`
          );
          ctx.end(player.gold + player.level * 50);
          return;
        }

        const mHpBar = '█'.repeat(Math.ceil((m.hp / m.maxHp) * 10));
        ctx.emit(
          out +
          `${A.cyan}${m.name}: ${A.bred}${mHpBar}${A.reset} ${m.hp}/${m.maxHp}\n` +
          renderStatus(player) +
          `${A.cyan}[F]ight [R]un: ${A.reset}`
        );
        return;
      }

      if (cmd === 'r' || cmd === 'run') {
        if (Math.random() < 0.4) {
          // Monster attacks on flee attempt
          const mDmg = Math.max(1, state.monster!.attack - player.defense);
          player.hp -= mDmg;
          if (player.hp <= 0) {
            sessions.delete(ctx.sessionId);
            ctx.emit(
              `${A.bred}You failed to escape and were slain!${A.reset}\n\n${A.dim}Press Enter to exit...${A.reset}`
            );
            ctx.end(0);
            return;
          }
          ctx.emit(
            `${A.bred}Couldn't escape! ${state.monster!.name} hit you for ${mDmg}!${A.reset}\n` +
            renderStatus(player) +
            `${A.cyan}[F]ight [R]un: ${A.reset}`
          );
        } else {
          state.monster = null;
          state.phase = 'explore';
          ctx.emit(`${A.yellow}You fled successfully!\n${A.reset}${renderStatus(player)}${A.cyan}> ${A.reset}`);
        }
        return;
      }

      ctx.emit(`${A.red}Enter F(ight) or R(un).${A.reset}\n${A.cyan}[F]ight [R]un: ${A.reset}`);
      return;
    }

    // ── Shop phase ────────────────────────────────────────
    if (state.phase === 'shop') {
      const ITEMS = [
        { name: 'Health Potion (+20 HP)',  cost: 30,  apply: (p: Player) => { p.hp = Math.min(p.maxHp, p.hp + 20); } },
        { name: 'Sword Upgrade (+5 ATK)', cost: 50,  apply: (p: Player) => { p.attack += 5; } },
        { name: 'Shield (+3 DEF)',         cost: 40,  apply: (p: Player) => { p.defense += 3; } },
        { name: 'Elixir (Full HP restore)',cost: 80,  apply: (p: Player) => { p.hp = p.maxHp; } },
      ];

      const idx = parseInt(cmd) - 1;
      if (cmd === 'l' || cmd === 'leave') {
        state.phase = 'explore';
        ctx.emit(`${A.yellow}You leave the shop.\n${A.reset}${renderStatus(player)}${A.cyan}> ${A.reset}`);
        return;
      }
      if (isNaN(idx) || idx < 0 || idx >= ITEMS.length) {
        shopMenu(ctx, player, ITEMS);
        return;
      }
      const item = ITEMS[idx];
      if (player.gold < item.cost) {
        ctx.emit(`${A.red}Not enough gold!\n${A.reset}`);
        shopMenu(ctx, player, ITEMS);
        return;
      }
      player.gold -= item.cost;
      item.apply(player);
      ctx.emit(`${A.bgreen}Bought: ${item.name}${A.reset}\n`);
      shopMenu(ctx, player, ITEMS);
      return;
    }

    // ── Explore phase ─────────────────────────────────────
    if (cmd === 'e' || cmd === 'explore') {
      const roll = Math.random();
      if (roll < 0.55) {
        // Encounter
        const monster = spawnMonster(player.floor);
        state.monster = monster;
        state.phase = 'combat';
        ctx.emit(
          `${A.bred}⚔ A ${monster.name} appears!${A.reset}\n` +
          `${A.cyan}${monster.name}: ${A.bwhite}HP ${monster.hp}  ATK ${monster.attack}${A.reset}\n` +
          renderStatus(player) +
          `${A.cyan}[F]ight [R]un: ${A.reset}`
        );
      } else if (roll < 0.75) {
        // Gold
        const found = Math.floor(Math.random() * 15) + 5;
        player.gold += found;
        ctx.emit(`${A.byellow}💰 You find ${found} gold coins!${A.reset}\n${renderStatus(player)}${A.cyan}> ${A.reset}`);
      } else if (roll < 0.88) {
        // Health potion
        const heal = Math.floor(Math.random() * 15) + 10;
        player.hp = Math.min(player.maxHp, player.hp + heal);
        ctx.emit(`${A.bgreen}🧪 You find a potion and drink it (+${heal} HP)!${A.reset}\n${renderStatus(player)}${A.cyan}> ${A.reset}`);
      } else {
        ctx.emit(`${A.dim}The corridor is empty...${A.reset}\n${renderStatus(player)}${A.cyan}> ${A.reset}`);
      }
      return;
    }

    if (cmd === 'd' || cmd === 'descend') {
      if (player.floor >= 5) {
        ctx.emit(`${A.yellow}There is nowhere deeper to go.\n${A.reset}${A.cyan}> ${A.reset}`);
        return;
      }
      player.floor++;
      ctx.emit(
        `${A.cyan}You descend to ${A.bwhite}Floor ${player.floor}${A.cyan}...\n` +
        (player.floor === 5 ? `${A.bred}You sense a powerful presence nearby...\n` : '') +
        A.reset + renderStatus(player) + `${A.cyan}> ${A.reset}`
      );
      return;
    }

    if (cmd === 's' || cmd === 'shop') {
      const ITEMS = [
        { name: 'Health Potion (+20 HP)',  cost: 30 },
        { name: 'Sword Upgrade (+5 ATK)', cost: 50 },
        { name: 'Shield (+3 DEF)',         cost: 40 },
        { name: 'Elixir (Full HP restore)',cost: 80 },
      ];
      state.phase = 'shop';
      shopMenu(ctx, player, ITEMS);
      return;
    }

    if (cmd === 'q' || cmd === 'quit') {
      sessions.delete(ctx.sessionId);
      const score = player.gold + player.level * 50;
      ctx.emit(
        `${A.yellow}You retreat from the dungeon.\nFloor reached: ${player.floor}  Score: ${score}${A.reset}\n\n` +
        `${A.dim}Press Enter to exit...${A.reset}`
      );
      ctx.end(score);
      return;
    }

    // Help
    ctx.emit(
      `${A.dim}Commands: [E]xplore  [D]escend  [S]hop  [Q]uit${A.reset}\n` +
      renderStatus(player) + `${A.cyan}> ${A.reset}`
    );
  },

  cleanup(ctx) { sessions.delete(ctx.sessionId); },
};

function shopMenu(ctx: GameContext, player: Player, items: { name: string; cost: number }[]) {
  let out = `${A.yellow}╔══ MERCHANT ══╗${A.reset}\n`;
  items.forEach((item, i) => {
    const canAfford = player.gold >= item.cost;
    out += `  ${A.bwhite}[${i + 1}]${A.reset} ${item.name.padEnd(28)} ${canAfford ? A.byellow : A.red}${item.cost}g${A.reset}\n`;
  });
  out += `  ${A.dim}[L]eave${A.reset}\n`;
  out += `${A.yellow}Gold: ${A.bwhite}${player.gold}${A.reset}\n${A.cyan}Choice: ${A.reset}`;
  ctx.emit(out);
}
