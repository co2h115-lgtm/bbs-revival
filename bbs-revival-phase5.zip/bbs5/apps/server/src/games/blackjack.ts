import type { DoorGame, GameContext } from './base.js';
import { A, banner } from './base.js';

type Suit = '♠' | '♥' | '♦' | '♣';
type Rank = 'A' | '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' | '10' | 'J' | 'Q' | 'K';

interface Card { rank: Rank; suit: Suit; }

function newDeck(): Card[] {
  const suits: Suit[] = ['♠', '♥', '♦', '♣'];
  const ranks: Rank[] = ['A','2','3','4','5','6','7','8','9','10','J','Q','K'];
  const deck: Card[] = [];
  for (const suit of suits)
    for (const rank of ranks)
      deck.push({ rank, suit });
  return deck.sort(() => Math.random() - 0.5);
}

function cardValue(rank: Rank): number {
  if (rank === 'A') return 11;
  if (['J','Q','K'].includes(rank)) return 10;
  return parseInt(rank);
}

function handValue(hand: Card[]): number {
  let total = hand.reduce((s, c) => s + cardValue(c.rank), 0);
  let aces = hand.filter((c) => c.rank === 'A').length;
  while (total > 21 && aces > 0) { total -= 10; aces--; }
  return total;
}

function renderCard(c: Card): string {
  const isRed = c.suit === '♥' || c.suit === '♦';
  const color = isRed ? A.bred : A.bwhite;
  return `${color}[${c.rank}${c.suit}]${A.reset}`;
}

function renderHand(hand: Card[], hideSecond = false): string {
  return hand
    .map((c, i) => (i === 1 && hideSecond ? `${A.dim}[??]${A.reset}` : renderCard(c)))
    .join(' ');
}

type GamePhase = 'bet' | 'play' | 'done';

interface State {
  deck: Card[];
  player: Card[];
  dealer: Card[];
  chips: number;
  bet: number;
  phase: GamePhase;
  handsPlayed: number;
  totalWon: number;
}

const sessions = new Map<string, State>();

const STARTING_CHIPS = 500;

function showTable(state: State, revealDealer = false): string {
  const pVal = handValue(state.player);
  const dVal = handValue(state.dealer);
  return (
    `${A.dim}${'─'.repeat(50)}${A.reset}\n` +
    `${A.yellow}DEALER: ${renderHand(state.dealer, !revealDealer)}` +
    (revealDealer ? `  ${A.dim}(${dVal})${A.reset}` : '') + '\n' +
    `${A.cyan}PLAYER: ${renderHand(state.player)}  ${A.dim}(${pVal})${A.reset}\n` +
    `${A.dim}${'─'.repeat(50)}${A.reset}\n` +
    `${A.yellow}Chips: ${A.bwhite}$${state.chips}${A.reset}` +
    (state.bet > 0 ? `  Bet: ${A.byellow}$${state.bet}${A.reset}` : '') + '\n'
  );
}

export const BlackjackGame: DoorGame = {
  slug: 'blackjack',
  name: 'BlackJack 21',

  start(ctx) {
    sessions.set(ctx.sessionId, {
      deck: newDeck(),
      player: [], dealer: [],
      chips: STARTING_CHIPS, bet: 0,
      phase: 'bet', handsPlayed: 0, totalWon: 0,
    });
    ctx.emit(
      A.clr +
      banner('BLACKJACK 21', A.green) +
      `${A.yellow}You start with ${A.bwhite}$${STARTING_CHIPS}${A.yellow} in chips.\n` +
      `${A.dim}Dealer stands on soft 17. Blackjack pays 3:2.\n\n` +
      `${A.reset}` +
      `${A.cyan}Enter your bet (1–${STARTING_CHIPS}): ${A.reset}`
    );
  },

  input(ctx, line) {
    const state = sessions.get(ctx.sessionId);
    if (!state) return;

    if (state.phase === 'bet') {
      const bet = parseInt(line.trim());
      if (isNaN(bet) || bet < 1 || bet > state.chips) {
        ctx.emit(`${A.red}Invalid bet. Enter 1–${state.chips}.\n${A.cyan}Bet: ${A.reset}`);
        return;
      }

      // Refresh deck if running low
      if (state.deck.length < 15) state.deck = newDeck();

      state.bet = bet;
      state.player = [state.deck.pop()!, state.deck.pop()!];
      state.dealer = [state.deck.pop()!, state.deck.pop()!];
      state.phase = 'play';

      const pVal = handValue(state.player);
      if (pVal === 21) {
        // Blackjack!
        const win = Math.floor(state.bet * 1.5);
        state.chips += win;
        state.totalWon += win;
        state.handsPlayed++;
        state.bet = 0;
        state.phase = 'bet';
        ctx.emit(
          showTable(state, true) +
          `\n${A.bold}${A.bgreen}BLACKJACK! 🃏 You win $${win}!${A.reset}\n\n` +
          nextOrQuit(state)
        );
        return;
      }

      ctx.emit(
        showTable(state) +
        `\n${A.cyan}[H]it, [S]tand, or [Q]uit: ${A.reset}`
      );
      return;
    }

    if (state.phase === 'play') {
      const cmd = line.trim().toLowerCase();

      if (cmd === 'q' || cmd === 'quit') {
        sessions.delete(ctx.sessionId);
        const score = state.chips;
        ctx.emit(
          `\n${A.yellow}Thanks for playing! Final chips: ${A.bwhite}$${score}${A.reset}\n\n` +
          `${A.dim}Press Enter to exit...${A.reset}`
        );
        ctx.end(score);
        return;
      }

      if (cmd === 'h' || cmd === 'hit') {
        state.player.push(state.deck.pop()!);
        const pVal = handValue(state.player);
        if (pVal > 21) {
          state.chips -= state.bet;
          state.handsPlayed++;
          state.bet = 0;
          state.phase = 'bet';
          ctx.emit(
            showTable(state, true) +
            `\n${A.bred}BUST! You lose!${A.reset}\n` +
            (state.chips <= 0
              ? `\n${A.red}${A.bold}OUT OF CHIPS! GAME OVER.${A.reset}\n\n${A.dim}Press Enter to exit...${A.reset}`
              : '\n' + nextOrQuit(state))
          );
          if (state.chips <= 0) {
            sessions.delete(ctx.sessionId);
            ctx.end(0);
          }
        } else {
          ctx.emit(showTable(state) + `\n${A.cyan}[H]it, [S]tand, or [Q]uit: ${A.reset}`);
        }
        return;
      }

      if (cmd === 's' || cmd === 'stand') {
        // Dealer draws to 17+
        while (handValue(state.dealer) < 17) {
          state.dealer.push(state.deck.pop()!);
        }
        const pVal = handValue(state.player);
        const dVal = handValue(state.dealer);
        let result: string;
        let delta = 0;
        if (dVal > 21 || pVal > dVal) {
          delta = state.bet;
          state.chips += delta;
          state.totalWon += delta;
          result = `${A.bgreen}YOU WIN! +$${delta}${A.reset}`;
        } else if (pVal === dVal) {
          result = `${A.yellow}PUSH — Bet returned${A.reset}`;
        } else {
          delta = -state.bet;
          state.chips += delta;
          result = `${A.bred}DEALER WINS. -$${state.bet}${A.reset}`;
        }
        state.handsPlayed++;
        state.bet = 0;
        state.phase = 'bet';
        ctx.emit(
          showTable(state, true) + `\n${result}\n` +
          (state.chips <= 0
            ? `\n${A.red}${A.bold}OUT OF CHIPS! GAME OVER.${A.reset}\n\n${A.dim}Press Enter to exit...${A.reset}`
            : '\n' + nextOrQuit(state))
        );
        if (state.chips <= 0) {
          sessions.delete(ctx.sessionId);
          ctx.end(0);
        }
        return;
      }

      ctx.emit(`${A.red}Enter H, S, or Q.${A.reset}\n${A.cyan}[H]it, [S]tand, or [Q]uit: ${A.reset}`);
    }

    // In bet phase after a hand
    if (state.phase === 'bet') {
      const bet = parseInt(line.trim());
      if (isNaN(bet) || bet < 1 || bet > state.chips) {
        ctx.emit(`${A.red}Invalid bet.\n${A.cyan}Bet (1–${state.chips}): ${A.reset}`);
        return;
      }
      if (state.deck.length < 15) state.deck = newDeck();
      state.bet = bet;
      state.player = [state.deck.pop()!, state.deck.pop()!];
      state.dealer = [state.deck.pop()!, state.deck.pop()!];
      state.phase = 'play';
      ctx.emit(showTable(state) + `\n${A.cyan}[H]it, [S]tand, or [Q]uit: ${A.reset}`);
    }
  },

  cleanup(ctx) { sessions.delete(ctx.sessionId); },
};

function nextOrQuit(state: State): string {
  return `${A.cyan}New bet (1–${state.chips}) or [Q]uit: ${A.reset}`;
}
