// Base class for all door games.
// Games communicate purely through text output and line input.
// The socket handler streams output to the client terminal.

export interface GameContext {
  userId: string;
  handle: string;
  sessionId: string;
  emit: (text: string) => void;   // send output to terminal
  end: (score?: number) => void;  // end the session
}

export interface DoorGame {
  slug: string;
  name: string;
  start(ctx: GameContext): void;
  input(ctx: GameContext, line: string): void;
  cleanup?(ctx: GameContext): void;
}

// ANSI helpers
export const A = {
  reset:   '\x1b[0m',
  bold:    '\x1b[1m',
  dim:     '\x1b[2m',
  blink:   '\x1b[5m',
  clr:     '\x1b[2J\x1b[H',       // clear screen + home
  home:    '\x1b[H',
  // Foreground colors
  black:   '\x1b[30m', red:     '\x1b[31m', green:  '\x1b[32m',
  yellow:  '\x1b[33m', blue:    '\x1b[34m', magenta:'\x1b[35m',
  cyan:    '\x1b[36m', white:   '\x1b[37m',
  // Bright foreground
  bred:    '\x1b[91m', bgreen:  '\x1b[92m', byellow:'\x1b[93m',
  bblue:   '\x1b[94m', bmagenta:'\x1b[95m', bcyan:  '\x1b[96m',
  bwhite:  '\x1b[97m',
  // Background
  bgBlack: '\x1b[40m', bgRed:   '\x1b[41m', bgGreen:'\x1b[42m',
  bgBlue:  '\x1b[44m', bgCyan:  '\x1b[46m',
};

export function banner(title: string, color = A.cyan): string {
  const w = 60;
  const pad = Math.floor((w - title.length - 4) / 2);
  const line = '═'.repeat(w);
  return (
    `${color}${A.bold}╔${line}╗\n` +
    `║${' '.repeat(pad)}[ ${title} ]${' '.repeat(w - pad - title.length - 4)}║\n` +
    `╚${line}╝${A.reset}\n`
  );
}
