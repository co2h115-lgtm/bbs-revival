import type { DoorGame, GameContext } from './base.js';
import { A, banner } from './base.js';

const WORDS = [
  'BULLETIN', 'MODEM', 'SYSOP', 'FIDONET', 'TERMINAL', 'PROTOCOL',
  'DOWNLOAD', 'UPLOAD', 'PACKET', 'NETWORK', 'GATEWAY', 'MATRIX',
  'CYBERPUNK', 'HACKER', 'CRACKER', 'PHREAKER', 'WAREZ', 'CODEC',
  'COMMODORE', 'AMIGA', 'ATARI', 'TANDY', 'COMPUSERVE', 'PRODIGY',
  'ZMODEM', 'XMODEM', 'YMODEM', 'KERMIT', 'TELNET', 'UUCP',
];

const GALLOWS = [
  // 0 wrong      1         2         3         4         5         6 = dead
  ['     ', '  ╔══', '  ╔══', '  ╔══', '  ╔══', '  ╔══', '  ╔══'],
  ['     ', '  ║  ', '  ║  ', '  ║  ', '  ║  ', '  ║  ', '  ║  '],
  ['     ', '     ', '  ●  ', '  ●  ', '  ●  ', '  ●  ', '  ●  '],
  ['     ', '     ', '     ', '  │  ', ' /│  ', ' /│\\ ', ' /│\\ '],
  ['     ', '     ', '     ', '     ', ' /   ', ' /   ', ' / \\ '],
  ['═════', '═════', '═════', '═════', '═════', '═════', '═════'],
];

interface State {
  word: string;
  guessed: Set<string>;
  wrong: number;
  maxWrong: number;
}

const sessions = new Map<string, State>();

function drawBoard(state: State): string {
  const stage = Math.min(state.wrong, 6);
  const gallows = GALLOWS.map((row) => row[stage]).join('\n');
  const display = state.word
    .split('')
    .map((c) => (state.guessed.has(c) ? `${A.bgreen}${c}${A.reset}` : `${A.dim}_${A.reset}`))
    .join(' ');
  const guessed = [...state.guessed].sort().join(' ');
  const wrong = state.maxWrong - state.wrong;

  return (
    `${A.cyan}${gallows}${A.reset}\n\n` +
    `  ${display}\n\n` +
    `${A.yellow}Guessed: ${A.white}${guessed || '(none)'}${A.reset}\n` +
    `${A.yellow}Wrong guesses left: ${wrong <= 2 ? A.bred : A.bwhite}${wrong}${A.reset}\n\n` +
    `${A.cyan}Enter a letter: ${A.reset}`
  );
}

export const HangmanGame: DoorGame = {
  slug: 'hangman',
  name: 'Hangman',

  start(ctx) {
    const word = WORDS[Math.floor(Math.random() * WORDS.length)];
    sessions.set(ctx.sessionId, { word, guessed: new Set(), wrong: 0, maxWrong: 6 });

    ctx.emit(
      A.clr +
      banner('HANGMAN', A.magenta) +
      `${A.cyan}Guess the BBS-themed word! One letter at a time.\n` +
      `${A.dim}The word has ${A.bwhite}${word.length}${A.dim} letters.\n\n` +
      A.reset +
      drawBoard(sessions.get(ctx.sessionId)!)
    );
  },

  input(ctx, line) {
    const state = sessions.get(ctx.sessionId);
    if (!state) return;

    const letter = line.trim().toUpperCase();
    if (!/^[A-Z]$/.test(letter)) {
      ctx.emit(`${A.red}Please enter a single letter.\n${A.reset}${drawBoard(state)}`);
      return;
    }
    if (state.guessed.has(letter)) {
      ctx.emit(`${A.yellow}You already guessed '${letter}'!\n${A.reset}${drawBoard(state)}`);
      return;
    }

    state.guessed.add(letter);
    if (!state.word.includes(letter)) state.wrong++;

    const won = state.word.split('').every((c) => state.guessed.has(c));
    const lost = state.wrong >= state.maxWrong;

    if (won) {
      const score = (state.maxWrong - state.wrong) * 200 + state.word.length * 50;
      sessions.delete(ctx.sessionId);
      ctx.emit(
        `\n${A.bgreen}${A.bold}YOU WIN! 🎉${A.reset}\n` +
        `${A.cyan}The word was: ${A.bwhite}${state.word}${A.reset}\n` +
        `${A.yellow}Score: ${A.bwhite}${score} points${A.reset}\n\n` +
        `${A.dim}Press Enter to exit...${A.reset}`
      );
      ctx.end(score);
    } else if (lost) {
      sessions.delete(ctx.sessionId);
      ctx.emit(
        drawBoard(state) +
        `\n${A.bred}${A.bold}YOU LOSE! ☠${A.reset}\n` +
        `${A.red}The word was: ${A.bwhite}${state.word}${A.reset}\n\n` +
        `${A.dim}Press Enter to exit...${A.reset}`
      );
      ctx.end(0);
    } else {
      ctx.emit(drawBoard(state));
    }
  },

  cleanup(ctx) { sessions.delete(ctx.sessionId); },
};
