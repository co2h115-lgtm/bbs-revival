import type { DoorGame } from './base.js';
import { GuessGame }    from './guess.js';
import { TriviaGame }   from './trivia.js';
import { HangmanGame }  from './hangman.js';
import { BlackjackGame }from './blackjack.js';
import { DungeonGame }  from './dungeon.js';

const registry = new Map<string, DoorGame>();

for (const game of [GuessGame, TriviaGame, HangmanGame, BlackjackGame, DungeonGame]) {
  registry.set(game.slug, game);
}

export function getGame(slug: string): DoorGame | undefined {
  return registry.get(slug);
}

export function listGames(): DoorGame[] {
  return [...registry.values()];
}
