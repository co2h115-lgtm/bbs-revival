import type { DoorGame, GameContext } from './base.js';
import { A, banner } from './base.js';

interface State {
  secret: number;
  tries: number;
  max: number;
  low: number;
  high: number;
  won: boolean;
}

const sessions = new Map<string, State>();

export const GuessGame: DoorGame = {
  slug: 'guess',
  name: 'Number Guesser',

  start(ctx) {
    const max = 10;
    const secret = Math.floor(Math.random() * 100) + 1;
    sessions.set(ctx.sessionId, { secret, tries: 0, max, low: 1, high: 100, won: false });

    ctx.emit(
      A.clr +
      banner('NUMBER GUESSER', A.cyan) +
      `${A.yellow}I'm thinking of a number between ${A.bwhite}1${A.yellow} and ${A.bwhite}100${A.yellow}.\n` +
      `You have ${A.bwhite}${max}${A.yellow} guesses. Good luck!\n` +
      `${A.reset}Range: [${A.bgreen}1${A.reset} — ${A.bgreen}100${A.reset}]\n\n` +
      `${A.cyan}Enter your guess: ${A.reset}`
    );
  },

  input(ctx, line) {
    const state = sessions.get(ctx.sessionId);
    if (!state || state.won) return;

    const guess = parseInt(line.trim());
    if (isNaN(guess) || guess < 1 || guess > 100) {
      ctx.emit(`${A.red}Please enter a number between 1 and 100.\n${A.cyan}Enter your guess: ${A.reset}`);
      return;
    }

    state.tries++;
    const remaining = state.max - state.tries;

    if (guess === state.secret) {
      state.won = true;
      const score = Math.max(0, (state.max - state.tries + 1) * 100);
      sessions.delete(ctx.sessionId);
      ctx.emit(
        `\n${A.bold}${A.bgreen}🎉 CORRECT! ${A.yellow}The number was ${state.secret}!${A.reset}\n` +
        `${A.cyan}You guessed it in ${A.bwhite}${state.tries}${A.cyan} ${state.tries === 1 ? 'try' : 'tries'}.\n` +
        `${A.yellow}Score: ${A.bwhite}${score} points${A.reset}\n\n` +
        `${A.dim}Press Enter to exit...${A.reset}`
      );
      ctx.end(score);
    } else if (remaining === 0) {
      sessions.delete(ctx.sessionId);
      ctx.emit(
        `\n${A.red}${A.bold}GAME OVER!${A.reset} ${A.red}The number was ${A.bwhite}${state.secret}${A.red}.\n` +
        `Better luck next time!\n\n${A.dim}Press Enter to exit...${A.reset}`
      );
      ctx.end(0);
    } else {
      if (guess < state.secret) state.low = Math.max(state.low, guess + 1);
      else state.high = Math.min(state.high, guess - 1);

      const arrow = guess < state.secret
        ? `${A.bgreen}▲ HIGHER${A.reset}`
        : `${A.bred}▼ LOWER${A.reset}`;

      ctx.emit(
        `${arrow}  Range: [${A.bgreen}${state.low}${A.reset}—${A.bgreen}${state.high}${A.reset}]` +
        `  Guesses left: ${remaining <= 3 ? A.bred : A.yellow}${remaining}${A.reset}\n` +
        `${A.cyan}Enter your guess: ${A.reset}`
      );
    }
  },

  cleanup(ctx) { sessions.delete(ctx.sessionId); },
};
