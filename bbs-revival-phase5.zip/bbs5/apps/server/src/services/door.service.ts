import { db } from '../db/pool.js';
import { hasMinRole } from '@bbs/shared';
import type { UserRole } from '@bbs/shared';

export async function getDoorGames(userRole: UserRole) {
  const { rows } = await db.query(
    `SELECT dg.*, 
            (SELECT COUNT(*) FROM door_sessions ds WHERE ds.game_id = dg.id) AS total_sessions,
            (SELECT MAX(ds2.score) FROM door_sessions ds2 WHERE ds2.game_id = dg.id) AS top_score
     FROM door_games dg
     WHERE dg.enabled = true
     ORDER BY dg.play_count DESC`
  );
  return rows.filter((g) => hasMinRole(userRole, g.min_role as UserRole));
}

export async function createSession(gameId: string, userId: string): Promise<string> {
  // End any lingering sessions for this user+game
  await db.query(
    `UPDATE door_sessions SET ended_at = NOW()
     WHERE game_id = $1 AND user_id = $2 AND ended_at IS NULL`,
    [gameId, userId]
  );
  const { rows } = await db.query(
    `INSERT INTO door_sessions (game_id, user_id) VALUES ($1, $2) RETURNING id`,
    [gameId, userId]
  );
  await db.query(
    `UPDATE door_games SET play_count = play_count + 1 WHERE id = $1`,
    [gameId]
  );
  return rows[0].id as string;
}

export async function endSession(sessionId: string, score: number | undefined) {
  await db.query(
    `UPDATE door_sessions SET ended_at = NOW(), score = $1 WHERE id = $2`,
    [score ?? null, sessionId]
  );

  if (score !== undefined && score > 0) {
    // Record high score
    const { rows } = await db.query(
      `SELECT game_id, user_id FROM door_sessions WHERE id = $1`, [sessionId]
    );
    if (rows.length > 0) {
      await db.query(
        `INSERT INTO door_scores (game_id, user_id, score) VALUES ($1, $2, $3)`,
        [rows[0].game_id, rows[0].user_id, score]
      );
    }
  }
}

export async function getLeaderboard(gameId: string, limit = 10) {
  const { rows } = await db.query(
    `SELECT ds.score, ds.achieved_at,
            u.handle AS user_handle,
            RANK() OVER (ORDER BY ds.score DESC) AS rank
     FROM door_scores ds
     JOIN users u ON u.id = ds.user_id
     WHERE ds.game_id = $1
     ORDER BY ds.score DESC
     LIMIT $2`,
    [gameId, limit]
  );
  return rows;
}

export async function getUserBestScores(userId: string) {
  const { rows } = await db.query(
    `SELECT dg.slug, dg.name, MAX(ds.score) AS best_score, COUNT(ds.id) AS plays
     FROM door_scores ds
     JOIN door_games dg ON dg.id = ds.game_id
     WHERE ds.user_id = $1
     GROUP BY dg.id
     ORDER BY dg.name`,
    [userId]
  );
  return rows;
}
