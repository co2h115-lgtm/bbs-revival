import 'dotenv/config';
import Fastify from 'fastify';
import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import rateLimit from '@fastify/rate-limit';
import jwt from '@fastify/jwt';
import multipart from '@fastify/multipart';
import { Server as SocketServer } from 'socket.io';
import type { ServerToClientEvents, ClientToServerEvents } from '@bbs/shared';

import { checkDbConnection } from './db/pool.js';
import { checkRedisConnection, redis } from './db/redis.js';
import authenticatePlugin from './plugins/authenticate.js';
import { setupSocketHandlers } from './plugins/socket.js';
import { authRoutes }    from './routes/auth.routes.js';
import { userRoutes }    from './routes/user.routes.js';
import { boardRoutes }   from './routes/board.routes.js';
import { threadRoutes }  from './routes/thread.routes.js';
import { pmRoutes }      from './routes/pm.routes.js';
import { searchRoutes }  from './routes/search.routes.js';
import { chatRoutes }    from './routes/chat.routes.js';
import { fileRoutes }    from './routes/file.routes.js';
import { galleryRoutes } from './routes/gallery.routes.js';
import { doorRoutes }    from './routes/door.routes.js';   // Phase 5

async function buildServer() {
  const fastify = Fastify({
    logger: {
      transport:
        process.env.NODE_ENV === 'development'
          ? { target: 'pino-pretty', options: { colorize: true } }
          : undefined,
    },
  });

  await fastify.register(helmet, { contentSecurityPolicy: false });
  await fastify.register(cors, {
    origin: process.env.CORS_ORIGIN ?? 'http://localhost:5173',
    credentials: true,
  });
  await fastify.register(rateLimit, {
    max: 100, timeWindow: '1 minute', redis, keyGenerator: (req) => req.ip,
  });
  await fastify.register(jwt, {
    secret: process.env.JWT_SECRET ?? 'dev-secret-change-in-production',
  });
  await fastify.register(multipart, {
    limits: { fileSize: 50 * 1024 * 1024, files: 1 },
  });
  await fastify.register(authenticatePlugin);

  fastify.register(authRoutes,    { prefix: '/api/auth' });
  fastify.register(userRoutes,    { prefix: '/api/users' });
  fastify.register(boardRoutes,   { prefix: '/api/boards' });
  fastify.register(threadRoutes,  { prefix: '/api/boards' });
  fastify.register(pmRoutes,      { prefix: '/api/messages' });
  fastify.register(searchRoutes,  { prefix: '/api/search' });
  fastify.register(chatRoutes,    { prefix: '/api/chat' });
  fastify.register(fileRoutes,    { prefix: '/api/files' });
  fastify.register(galleryRoutes, { prefix: '/api/gallery' });
  fastify.register(doorRoutes,    { prefix: '/api/doors' });  // Phase 5

  fastify.get('/health', async () => ({
    status: 'ok', bbs: process.env.BBS_NAME ?? 'BBS Revival',
    timestamp: new Date().toISOString(),
  }));

  const io = new SocketServer<ClientToServerEvents, ServerToClientEvents>(fastify.server, {
    cors: { origin: process.env.CORS_ORIGIN ?? 'http://localhost:5173', credentials: true },
  });
  fastify.decorate('io', io);
  setupSocketHandlers(io, fastify);

  return { fastify };
}

async function main() {
  const port = parseInt(process.env.PORT ?? '3001');
  const host = process.env.HOST ?? '0.0.0.0';

  console.log('\n████████████████████████████████████');
  console.log(`██  ${(process.env.BBS_NAME ?? 'BBS Revival').padEnd(29)}██`);
  console.log('██  Phase 5 — Door Games           ██');
  console.log('████████████████████████████████████\n');

  await checkDbConnection();  console.log('  ✅ PostgreSQL connected');
  await checkRedisConnection(); console.log('  ✅ Redis connected');

  const { fastify } = await buildServer();
  await fastify.listen({ port, host });
  console.log(`\n  ✅ API on http://${host}:${port}\n`);
}

main().catch((e) => { console.error(e); process.exit(1); });
