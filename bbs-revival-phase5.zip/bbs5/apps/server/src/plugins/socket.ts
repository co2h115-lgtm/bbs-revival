import type { Server as SocketServer, Socket } from 'socket.io';
import type { ServerToClientEvents, ClientToServerEvents } from '@bbs/shared';
import { db } from '../db/pool.js';
import { redis, Keys } from '../db/redis.js';
import type { FastifyInstance } from 'fastify';
import { getGame } from '../games/registry.js';
import { createSession, endSession } from '../services/door.service.js';
import type { GameContext } from '../games/base.js';

const PRESENCE_TTL = 90;
const RL_WINDOW    = 10_000;
const RL_MAX       = 10;
const MAX_MSG_LEN  = 1000;

interface SocketData {
  userId: string;
  handle: string;
  role: string;
  // door session tracking
  doorSessionId?: string;
  doorGameSlug?: string;
}

type AppSocket = Socket<ClientToServerEvents, ServerToClientEvents> & { data: SocketData };

export function setupSocketHandlers(
  io: SocketServer<ClientToServerEvents, ServerToClientEvents>,
  fastify: FastifyInstance
) {
  // ── Auth middleware ──────────────────────────────────────
  io.use(async (socket, next) => {
    const token = socket.handshake.auth?.token as string | undefined;
    if (!token) return next(new Error('Authentication required'));
    try {
      const decoded = fastify.jwt.verify<{ sub: string }>(token);
      const { rows } = await db.query(
        'SELECT id, handle, role FROM users WHERE id = $1', [decoded.sub]
      );
      if (!rows.length) return next(new Error('User not found'));
      if (rows[0].role === 'banned') return next(new Error('Account banned'));
      socket.data.userId = rows[0].id as string;
      socket.data.handle = rows[0].handle as string;
      socket.data.role   = rows[0].role as string;
      next();
    } catch {
      next(new Error('Invalid token'));
    }
  });

  io.on('connection', async (socket: AppSocket) => {
    const { userId, handle } = socket.data;

    // Presence
    await redis.sadd(Keys.onlineUsers(), userId);
    await redis.setex(Keys.userStatus(userId), PRESENCE_TTL, 'online');
    await db.query('UPDATE users SET last_seen = NOW() WHERE id = $1', [userId]);
    io.emit('presence:update', { userId, handle, status: 'online' });

    // ── Chat ────────────────────────────────────────────────
    socket.on('chat:join', async (roomId) => {
      const { rows } = await db.query('SELECT id FROM chat_rooms WHERE id = $1', [roomId]);
      if (!rows.length) { socket.emit('error', { message: 'Room not found' }); return; }
      await socket.join(`room:${roomId}`);
      await redis.sadd(Keys.roomMembers(roomId), userId);
      io.to(`room:${roomId}`).emit('chat:user_joined', { userId, handle, roomId });
    });

    socket.on('chat:leave', async (roomId) => {
      await socket.leave(`room:${roomId}`);
      await redis.srem(Keys.roomMembers(roomId), userId);
      io.to(`room:${roomId}`).emit('chat:user_left', { userId, handle, roomId });
    });

    socket.on('chat:message', async (payload) => {
      const { roomId, body } = payload;
      if (!body?.trim() || body.length > MAX_MSG_LEN) return;
      if (!socket.rooms.has(`room:${roomId}`)) return;

      const rlKey = `rl:chat:${userId}`;
      const count = await redis.incr(rlKey);
      if (count === 1) await redis.pexpire(rlKey, RL_WINDOW);
      if (count > RL_MAX) {
        socket.emit('error', { message: 'Slow down — you\'re sending too fast.' });
        return;
      }

      const { rows } = await db.query(
        `INSERT INTO chat_messages (room_id, user_id, body) VALUES ($1,$2,$3) RETURNING id, created_at`,
        [roomId, userId, body.trim()]
      );
      io.to(`room:${roomId}`).emit('chat:message', {
        id: rows[0].id as string, roomId, userId,
        userHandle: handle, userRole: socket.data.role as 'validated',
        body: body.trim(), createdAt: (rows[0].created_at as Date).toISOString(),
      });
    });

    socket.on('chat:typing', (roomId) => {
      if (!socket.rooms.has(`room:${roomId}`)) return;
      socket.to(`room:${roomId}`).emit('chat:typing', { userId, handle, roomId });
    });

    socket.on('presence:ping', async () => {
      await redis.setex(Keys.userStatus(userId), PRESENCE_TTL, 'online');
      await db.query('UPDATE users SET last_seen = NOW() WHERE id = $1', [userId]);
    });

    // ── Door games ──────────────────────────────────────────
    socket.on('door:input', async (payload) => {
      const { gameSlug, input } = payload as { gameSlug: string; input: string };

      // Start new game session
      if (input === '__START__') {
        // Clean up existing door session
        if (socket.data.doorSessionId && socket.data.doorGameSlug) {
          const oldGame = getGame(socket.data.doorGameSlug);
          oldGame?.cleanup?.({ sessionId: socket.data.doorSessionId, userId, handle, emit: () => {}, end: () => {} });
          await endSession(socket.data.doorSessionId, undefined);
        }

        const game = getGame(gameSlug);
        if (!game) { socket.emit('error', { message: `Game '${gameSlug}' not found` }); return; }

        // Look up gameId from slug
        const { rows } = await db.query(
          'SELECT id, min_role FROM door_games WHERE slug = $1 AND enabled = true', [gameSlug]
        );
        if (!rows.length) { socket.emit('error', { message: 'Game not available' }); return; }

        const sessionId = await createSession(rows[0].id as string, userId);
        socket.data.doorSessionId = sessionId;
        socket.data.doorGameSlug  = gameSlug;

        const ctx = makeCtx(socket, sessionId, userId, handle, gameSlug, io);
        game.start(ctx);
        return;
      }

      // Route input to active game
      if (!socket.data.doorSessionId || !socket.data.doorGameSlug) return;
      const game = getGame(socket.data.doorGameSlug);
      if (!game) return;
      const ctx = makeCtx(socket, socket.data.doorSessionId, userId, handle, socket.data.doorGameSlug, io);
      game.input(ctx, input);
    });

    // ── Disconnect ──────────────────────────────────────────
    socket.on('disconnect', async () => {
      // End door session if active
      if (socket.data.doorSessionId && socket.data.doorGameSlug) {
        const game = getGame(socket.data.doorGameSlug);
        game?.cleanup?.({
          sessionId: socket.data.doorSessionId, userId, handle,
          emit: () => {}, end: () => {},
        });
        await endSession(socket.data.doorSessionId, undefined);
        socket.data.doorSessionId = undefined;
        socket.data.doorGameSlug  = undefined;
      }

      for (const room of socket.rooms) {
        if (room.startsWith('room:')) {
          const roomId = room.replace('room:', '');
          await redis.srem(Keys.roomMembers(roomId), userId);
          io.to(room).emit('chat:user_left', { userId, handle, roomId });
        }
      }

      const allSockets = await io.fetchSockets();
      const stillConnected = allSockets.some(
        (s) => s.id !== socket.id && (s.data as SocketData).userId === userId
      );
      if (!stillConnected) {
        await redis.srem(Keys.onlineUsers(), userId);
        await redis.del(Keys.userStatus(userId));
        await db.query('UPDATE users SET last_seen = NOW() WHERE id = $1', [userId]);
        io.emit('presence:update', { userId, handle, status: 'offline' });
      }
    });
  });

  // Presence sweep
  setInterval(async () => {
    const onlineIds = await redis.smembers(Keys.onlineUsers());
    for (const uid of onlineIds) {
      const status = await redis.get(Keys.userStatus(uid));
      if (!status) {
        await redis.srem(Keys.onlineUsers(), uid);
        const { rows } = await db.query('SELECT handle FROM users WHERE id = $1', [uid]);
        if (rows.length > 0) {
          io.emit('presence:update', { userId: uid, handle: rows[0].handle as string, status: 'offline' });
        }
      }
    }
  }, 120_000);
}

function makeCtx(
  socket: AppSocket,
  sessionId: string,
  userId: string,
  handle: string,
  gameSlug: string,
  io: SocketServer
): GameContext {
  let ended = false;
  return {
    sessionId,
    userId,
    handle,
    emit(text: string) {
      socket.emit('door:output', { gameSlug, output: text });
    },
    end(score?: number) {
      if (ended) return;
      ended = true;
      endSession(sessionId, score).catch(console.error);
      socket.data.doorSessionId = undefined;
      socket.data.doorGameSlug  = undefined;
      socket.emit('door:end', { gameSlug, score });
    },
  };
}
