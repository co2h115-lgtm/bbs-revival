import { create } from 'zustand';
import { io, Socket } from 'socket.io-client';
import type { ServerToClientEvents, ClientToServerEvents, ChatMessage, ChatRoom } from '@bbs/shared';

type AppSocket = Socket<ServerToClientEvents, ClientToServerEvents>;

interface OnlineUser {
  userId: string;
  handle: string;
  status: 'online' | 'offline' | 'away';
}

interface SocketState {
  socket: AppSocket | null;
  connected: boolean;
  onlineUsers: Map<string, OnlineUser>;
  rooms: ChatRoom[];
  messages: Map<string, ChatMessage[]>;
  typingUsers: Map<string, Set<string>>;
  unreadCounts: Map<string, number>;
  activeRoomId: string | null;

  connect: (token: string) => void;
  disconnect: () => void;
  joinRoom: (roomId: string) => void;
  leaveRoom: (roomId: string) => void;
  sendMessage: (roomId: string, body: string) => void;
  sendTyping: (roomId: string) => void;
  setActiveRoom: (roomId: string | null) => void;
  loadHistory: (roomId: string, messages: ChatMessage[]) => void;
  clearUnread: (roomId: string) => void;
  setRooms: (rooms: ChatRoom[]) => void;
}

export const useSocketStore = create<SocketState>((set, get) => ({
  socket: null,
  connected: false,
  onlineUsers: new Map(),
  rooms: [],
  messages: new Map(),
  typingUsers: new Map(),
  unreadCounts: new Map(),
  activeRoomId: null,

  connect: (token: string) => {
    const existing = get().socket;
    if (existing?.connected) return;

    const socket: AppSocket = io('/', {
      auth: { token },
      transports: ['websocket'],
      reconnectionAttempts: 5,
      reconnectionDelay: 2000,
    });

    socket.on('connect', () => {
      set({ connected: true });
      const pingInterval = setInterval(() => {
        if (socket.connected) socket.emit('presence:ping');
      }, 30_000);
      socket.on('disconnect', () => clearInterval(pingInterval));
    });

    socket.on('disconnect', () => set({ connected: false }));

    socket.on('presence:update', (payload) => {
      set((state) => {
        const next = new Map(state.onlineUsers);
        if (payload.status === 'offline') next.delete(payload.userId);
        else next.set(payload.userId, payload);
        return { onlineUsers: next };
      });
    });

    socket.on('chat:message', (msg) => {
      set((state) => {
        const next = new Map(state.messages);
        const roomMsgs = [...(next.get(msg.roomId) ?? []), msg].slice(-200);
        next.set(msg.roomId, roomMsgs);
        const unread = new Map(state.unreadCounts);
        if (state.activeRoomId !== msg.roomId) {
          unread.set(msg.roomId, (unread.get(msg.roomId) ?? 0) + 1);
        }
        return { messages: next, unreadCounts: unread };
      });
    });

    socket.on('chat:typing', ({ handle, roomId }) => {
      set((state) => {
        const next = new Map(state.typingUsers);
        const s = new Set(next.get(roomId) ?? []);
        s.add(handle);
        next.set(roomId, s);
        return { typingUsers: next };
      });
      setTimeout(() => {
        set((state) => {
          const next = new Map(state.typingUsers);
          const s = new Set(next.get(roomId) ?? []);
          s.delete(handle);
          next.set(roomId, s);
          return { typingUsers: next };
        });
      }, 3000);
    });

    socket.on('chat:user_joined', ({ roomId, handle }) => {
      set((state) => {
        const next = new Map(state.messages);
        next.set(roomId, [...(next.get(roomId) ?? []), {
          id: `system-${Date.now()}`, roomId,
          userId: 'system', userHandle: 'SYSTEM',
          userRole: 'validated' as const,
          body: `*** ${handle} has joined ***`,
          createdAt: new Date().toISOString(),
        }]);
        return { messages: next };
      });
    });

    socket.on('chat:user_left', ({ roomId, handle }) => {
      set((state) => {
        const next = new Map(state.messages);
        next.set(roomId, [...(next.get(roomId) ?? []), {
          id: `system-${Date.now()}`, roomId,
          userId: 'system', userHandle: 'SYSTEM',
          userRole: 'validated' as const,
          body: `*** ${handle} has left ***`,
          createdAt: new Date().toISOString(),
        }]);
        return { messages: next };
      });
    });

    socket.on('system:broadcast', ({ message, from }) => {
      set((state) => {
        const next = new Map(state.messages);
        for (const [roomId, msgs] of next.entries()) {
          next.set(roomId, [...msgs, {
            id: `broadcast-${Date.now()}`, roomId,
            userId: 'system', userHandle: `[${from}]`,
            userRole: 'sysop' as const,
            body: `🔔 BROADCAST: ${message}`,
            createdAt: new Date().toISOString(),
          }]);
        }
        return { messages: next };
      });
    });

    // door:output and door:end are handled by DoorsPage directly via socket.on()
    // to keep terminal state local to that component

    socket.on('error', ({ message }) => {
      console.warn('Socket error:', message);
    });

    set({ socket });
  },

  disconnect: () => {
    get().socket?.disconnect();
    set({
      socket: null, connected: false,
      onlineUsers: new Map(), messages: new Map(),
      typingUsers: new Map(), unreadCounts: new Map(), activeRoomId: null,
    });
  },

  joinRoom:     (roomId) => { get().socket?.emit('chat:join', roomId); set((s) => { if (!s.messages.has(roomId)) { const n = new Map(s.messages); n.set(roomId, []); return { messages: n }; } return {}; }); },
  leaveRoom:    (roomId) => { get().socket?.emit('chat:leave', roomId); },
  sendMessage:  (roomId, body) => { get().socket?.emit('chat:message', { roomId, body }); },
  sendTyping:   (roomId) => { get().socket?.emit('chat:typing', roomId); },
  setActiveRoom:(roomId) => { set({ activeRoomId: roomId }); if (roomId) { set((s) => { const n = new Map(s.unreadCounts); n.delete(roomId); return { unreadCounts: n }; }); } },
  loadHistory:  (roomId, messages) => { set((s) => { const n = new Map(s.messages); const ex = n.get(roomId) ?? []; const ids = new Set(ex.map((m) => m.id)); n.set(roomId, [...messages.filter((m) => !ids.has(m.id)), ...ex]); return { messages: n }; }); },
  clearUnread:  (roomId) => { set((s) => { const n = new Map(s.unreadCounts); n.delete(roomId); return { unreadCounts: n }; }); },
  setRooms:     (rooms) => set({ rooms }),
}));
