import { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { WelcomeScreen } from './components/WelcomeScreen';
import { Shell } from './components/Shell';
import { AuthPage } from './pages/AuthPage';
import { BoardsPage } from './pages/BoardsPage';
import { ThreadListPage } from './pages/ThreadListPage';
import { ThreadPage } from './pages/ThreadPage';
import { MessagesPage } from './pages/MessagesPage';
import { SearchPage } from './pages/SearchPage';
import { ChatPage } from './pages/ChatPage';
import { FilesPage } from './pages/FilesPage';
import { GalleryPage } from './pages/GalleryPage';
import { DoorsPage } from './pages/DoorsPage';
import { PlaceholderPage } from './pages/PlaceholderPage';

export function App() {
  const [showWelcome, setShowWelcome] = useState(
    !sessionStorage.getItem('bbs_welcomed')
  );

  if (showWelcome) {
    return (
      <WelcomeScreen
        onContinue={() => {
          sessionStorage.setItem('bbs_welcomed', '1');
          setShowWelcome(false);
        }}
      />
    );
  }

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/auth" element={<AuthPage />} />
        <Route path="/" element={<Shell />}>
          <Route index element={<Navigate to="/boards" replace />} />

          <Route path="boards"                      element={<BoardsPage />} />
          <Route path="boards/:boardId"             element={<ThreadListPage />} />
          <Route path="boards/threads/:threadId"    element={<ThreadPage />} />
          <Route path="messages"                    element={<MessagesPage />} />
          <Route path="search"                      element={<SearchPage />} />
          <Route path="chat"                        element={<ChatPage />} />
          <Route path="files"                       element={<FilesPage />} />
          <Route path="gallery"                     element={<GalleryPage />} />
          <Route path="doors"                       element={<DoorsPage />} />   {/* Phase 5 */}

          <Route path="profile" element={
            <PlaceholderPage title="MY PROFILE" phase="Phase 6"
              description="View and edit your BBS profile, handle, bio, and account settings." />
          } />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
