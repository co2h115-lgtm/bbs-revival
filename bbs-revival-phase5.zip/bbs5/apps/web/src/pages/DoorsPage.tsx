import { useEffect, useRef, useState, useCallback } from 'react';
import { apiFetch, useAuthStore } from '../stores/auth.store';
import { useSocketStore } from '../stores/socket.store';
import { AnsiRenderer } from '../components/AnsiRenderer';
import styles from './DoorsPage.module.css';

interface DoorGame {
  id: string;
  slug: string;
  name: string;
  description: string;
  author: string;
  min_role: string;
  has_scores: boolean;
  play_count: number;
  top_score: number | null;
}

interface LeaderboardEntry {
  rank: number;
  user_handle: string;
  score: number;
  achieved_at: string;
}

interface TerminalLine {
  id: number;
  content: string;
}

let lineId = 0;

export function DoorsPage() {
  const { user } = useAuthStore();
  const { socket, connected } = useSocketStore();

  const [games, setGames] = useState<DoorGame[]>([]);
  const [selected, setSelected] = useState<DoorGame | null>(null);
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [loadingBoard, setLoadingBoard] = useState(false);

  // Terminal state
  const [playing, setPlaying] = useState(false);
  const [termLines, setTermLines] = useState<TerminalLine[]>([]);
  const [inputLine, setInputLine] = useState('');
  const [gameEnded, setGameEnded] = useState(false);
  const [finalScore, setFinalScore] = useState<number | undefined>();

  const termBottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    apiFetch('/api/doors')
      .then((r) => r.json())
      .then((d) => { if (d.ok) setGames(d.data); });
  }, []);

  // Scroll terminal to bottom on new output
  useEffect(() => {
    termBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [termLines]);

  // Socket event listeners for door I/O
  useEffect(() => {
    if (!socket) return;

    const onOutput = ({ output }: { gameSlug: string; output: string }) => {
      // Split output by newlines into separate render lines
      const chunks = output.split(/(\n)/);
      const newLines: TerminalLine[] = [];
      let current = '';
      for (const chunk of chunks) {
        if (chunk === '\n') {
          newLines.push({ id: lineId++, content: current });
          current = '';
        } else {
          current += chunk;
        }
      }
      if (current) newLines.push({ id: lineId++, content: current });
      setTermLines((prev) => [...prev, ...newLines].slice(-500)); // keep last 500 lines
    };

    const onEnd = ({ score }: { gameSlug: string; score?: number }) => {
      setGameEnded(true);
      setFinalScore(score);
      setTermLines((prev) => [
        ...prev,
        { id: lineId++, content: '' },
        { id: lineId++, content: `\x1b[90m─────────────────────────────────────────────────────\x1b[0m` },
        { id: lineId++, content: score !== undefined ? `\x1b[33mGame over. Final score: \x1b[97m${score}\x1b[0m` : `\x1b[90mSession ended.\x1b[0m` },
        { id: lineId++, content: '' },
      ]);
    };

    socket.on('door:output', onOutput);
    socket.on('door:end', onEnd);
    return () => {
      socket.off('door:output', onOutput);
      socket.off('door:end', onEnd);
    };
  }, [socket]);

  const selectGame = async (game: DoorGame) => {
    setSelected(game);
    setPlaying(false);
    setGameEnded(false);
    setTermLines([]);

    if (game.has_scores) {
      setLoadingBoard(true);
      try {
        const res = await apiFetch(`/api/doors/${game.id}/leaderboard`);
        const d = await res.json();
        if (d.ok) setLeaderboard(d.data);
      } finally {
        setLoadingBoard(false);
      }
    }
  };

  const startGame = useCallback(() => {
    if (!socket || !connected || !selected) return;
    setTermLines([]);
    setGameEnded(false);
    setFinalScore(undefined);
    setPlaying(true);
    socket.emit('door:input', { gameSlug: selected.slug, input: '__START__' } as never);
    setTimeout(() => inputRef.current?.focus(), 100);
  }, [socket, connected, selected]);

  const handleInput = (e: React.FormEvent) => {
    e.preventDefault();
    if (!socket || !selected || !playing) return;
    const line = inputLine;
    setInputLine('');
    // Echo input to terminal
    setTermLines((prev) => [...prev, { id: lineId++, content: `\x1b[97m${line}\x1b[0m` }]);
    socket.emit('door:input', { gameSlug: selected.slug, input: line } as never);
  };

  const exitGame = () => {
    setPlaying(false);
    setGameEnded(false);
    setTermLines([]);
    // Reload leaderboard
    if (selected) selectGame(selected);
  };

  const rankColor = (rank: number) => {
    if (rank === 1) return styles.gold;
    if (rank === 2) return styles.silver;
    if (rank === 3) return styles.bronze;
    return '';
  };

  return (
    <div className={styles.layout}>
      {/* Game list */}
      <aside className={styles.sidebar}>
        <div className={styles.sidebarHeader}>DOOR GAMES</div>
        {games.map((game) => (
          <button
            key={game.id}
            className={`${styles.gameItem} ${selected?.id === game.id ? styles.gameItemActive : ''}`}
            onClick={() => selectGame(game)}
          >
            <div className={styles.gameName}>{game.name}</div>
            <div className={styles.gamePlays}>{game.play_count} plays</div>
          </button>
        ))}
      </aside>

      {/* Content pane */}
      <div className={styles.content}>
        {!selected && (
          <div className={styles.welcome}>
            <AnsiRenderer content={WELCOME_ART} />
            <p className={styles.welcomeText}>Select a game from the left to begin.</p>
          </div>
        )}

        {selected && !playing && (
          <div className={styles.gameLobby}>
            <div className={styles.gameHeader}>
              <div>
                <h1 className={styles.gameTitle}>{selected.name.toUpperCase()}</h1>
                <p className={styles.gameDesc}>{selected.description}</p>
                <div className={styles.gameMeta}>
                  <span>By {selected.author}</span>
                  <span>·</span>
                  <span>{selected.play_count} total plays</span>
                  {selected.top_score !== null && (
                    <>
                      <span>·</span>
                      <span>Top score: <strong>{selected.top_score}</strong></span>
                    </>
                  )}
                </div>
              </div>
              <button
                className={`${styles.playBtn} btn-primary`}
                onClick={startGame}
                disabled={!connected}
              >
                {connected ? '[ ▶ PLAY ]' : '[ CONNECTING... ]'}
              </button>
            </div>

            {/* Leaderboard */}
            {selected.has_scores && (
              <div className={styles.leaderboard}>
                <div className={styles.lbHeader}>
                  ⚡ LEADERBOARD — {selected.name.toUpperCase()}
                </div>
                {loadingBoard ? (
                  <div className={styles.lbEmpty}>Loading...</div>
                ) : leaderboard.length === 0 ? (
                  <div className={styles.lbEmpty}>No scores yet. Be the first!</div>
                ) : (
                  <table className={styles.lbTable}>
                    <thead>
                      <tr>
                        <th>RANK</th>
                        <th>PLAYER</th>
                        <th>SCORE</th>
                        <th>DATE</th>
                      </tr>
                    </thead>
                    <tbody>
                      {leaderboard.map((entry) => (
                        <tr key={`${entry.user_handle}-${entry.score}`} className={rankColor(entry.rank)}>
                          <td className={styles.lbRank}>
                            {entry.rank === 1 ? '🥇' : entry.rank === 2 ? '🥈' : entry.rank === 3 ? '🥉' : `#${entry.rank}`}
                          </td>
                          <td className={styles.lbHandle}>{entry.user_handle}</td>
                          <td className={styles.lbScore}>{entry.score.toLocaleString()}</td>
                          <td className={styles.lbDate}>{new Date(entry.achieved_at).toLocaleDateString()}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            )}
          </div>
        )}

        {/* Terminal */}
        {playing && (
          <div className={styles.terminal}>
            <div className={styles.termHeader}>
              <span className={styles.termTitle}>{selected?.name}</span>
              <div className={styles.termActions}>
                {gameEnded ? (
                  <button className="btn-primary" onClick={exitGame}>[ EXIT GAME ]</button>
                ) : (
                  <button className={styles.abortBtn} onClick={exitGame}>[ ABORT ]</button>
                )}
              </div>
            </div>

            <div className={styles.termBody}>
              {termLines.map((line) => (
                <div key={line.id} className={styles.termLine}>
                  <AnsiRenderer content={line.content} />
                </div>
              ))}
              <div ref={termBottomRef} />
            </div>

            {!gameEnded && (
              <form className={styles.termInput} onSubmit={handleInput}>
                <input
                  ref={inputRef}
                  type="text"
                  value={inputLine}
                  onChange={(e) => setInputLine(e.target.value)}
                  className={styles.termInputField}
                  placeholder="Type and press Enter..."
                  autoComplete="off"
                  autoCorrect="off"
                  autoCapitalize="off"
                  spellCheck={false}
                />
              </form>
            )}

            {gameEnded && finalScore !== undefined && (
              <div className={styles.scoreToast}>
                Final Score: <strong>{finalScore.toLocaleString()}</strong>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

const WELCOME_ART = `\x1b[36m ██████╗  ██████╗  ██████╗ ██████╗ ███████╗\x1b[0m
\x1b[36m ██╔══██╗██╔═══██╗██╔═══██╗██╔══██╗██╔════╝\x1b[0m
\x1b[96m ██║  ██║██║   ██║██║   ██║██████╔╝███████╗\x1b[0m
\x1b[96m ██║  ██║██║   ██║██║   ██║██╔══██╗╚════██║\x1b[0m
\x1b[97m ██████╔╝╚██████╔╝╚██████╔╝██║  ██║███████║\x1b[0m
\x1b[97m ╚═════╝  ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚══════╝\x1b[0m
\x1b[33m            G A M E S\x1b[0m
\x1b[90m ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\x1b[0m
\x1b[32m  Classic BBS-style games, played in your browser.\x1b[0m
\x1b[32m  Scores are recorded on global leaderboards.\x1b[0m`;
