import { db } from '../db/pool.js';
import { redis, Keys } from '../db/redis.js';

export async function getRooms() {
  const { rows } = await db.query(
    `SELECT id, name, description, is_system, created_at FROM chat_rooms ORDER BY is_system DESC, name ASC`
  );

  // Attach live member counts from Redis
  const withCounts = await Promise.all(
    rows.map(async (room) => {
      const count = await redis.scard(Keys.roomMembers(room.id as string));
      return { ...room, onlineCount: count };
    })
  );
  return withCounts;
}

export async function getRoom(roomId: string) {
  const { rows } = await db.query(
    'SELECT id, name, description, is_system FROM chat_rooms WHERE id = $1',
    [roomId]
  );
  if (rows.length === 0) throw Object.assign(new Error('Room not found'), { statusCode: 404 });
  return rows[0];
}

export async function getRoomHistory(roomId: string, before?: string, limit = 50) {
  const params: unknown[] = [roomId, limit];
  const beforeClause = before
    ? `AND cm.created_at < (SELECT created_at FROM chat_messages WHERE id = $3)`
    : '';
  if (before) params.push(before);

  const { rows } = await db.query(
    `SELECT cm.id, cm.room_id, cm.body, cm.created_at,
            u.id AS user_id, u.handle AS user_handle, u.role AS user_role
     FROM chat_messages cm
     JOIN users u ON u.id = cm.user_id
     WHERE cm.room_id = $1 ${beforeClause}
     ORDER BY cm.created_at DESC
     LIMIT $2`,
    params
  );
  // Return in chronological order
  return rows.reverse();
}

export async function getRoomMembers(roomId: string) {
  const memberIds = await redis.smembers(Keys.roomMembers(roomId));
  if (memberIds.length === 0) return [];

  const placeholders = memberIds.map((_, i) => `$${i + 1}`).join(',');
  const { rows } = await db.query(
    `SELECT id, handle, role FROM users WHERE id IN (${placeholders})`,
    memberIds
  );
  return rows;
}

export async function createRoom(name: string, description: string, createdBy: string) {
  const { rows } = await db.query(
    `INSERT INTO chat_rooms (name, description, is_system, created_by)
     VALUES ($1, $2, false, $3) RETURNING id`,
    [name, description, createdBy]
  );
  return rows[0].id as string;
}

export async function getOnlineUsers() {
  const onlineIds = await redis.smembers(Keys.onlineUsers());
  if (onlineIds.length === 0) return [];

  const placeholders = onlineIds.map((_, i) => `$${i + 1}`).join(',');
  const { rows } = await db.query(
    `SELECT id, handle, role, last_seen FROM users WHERE id IN (${placeholders})`,
    onlineIds
  );
  return rows;
}
