import type { Server as SocketServer, Socket } from 'socket.io';
import type { ServerToClientEvents, ClientToServerEvents } from '@bbs/shared';
import { db } from '../db/pool.js';
import { redis, Keys } from '../db/redis.js';
import type { FastifyInstance } from 'fastify';

const PRESENCE_TTL = 90;        // seconds
const MAX_MSG_LEN  = 1000;
const RL_WINDOW    = 10_000;    // ms
const RL_MAX       = 10;        // messages per window

interface SocketData {
  userId: string;
  handle: string;
  role: string;
}

type AppSocket = Socket<ClientToServerEvents, ServerToClientEvents> & {
  data: SocketData;
};

export function setupSocketHandlers(
  io: SocketServer<ClientToServerEvents, ServerToClientEvents>,
  fastify: FastifyInstance
) {
  // ── Auth middleware ───────────────────────────────────────
  io.use(async (socket, next) => {
    const token = socket.handshake.auth?.token as string | undefined;
    if (!token) return next(new Error('Authentication required'));

    try {
      const decoded = fastify.jwt.verify<{ sub: string }>(token);
      const { rows } = await db.query(
        'SELECT id, handle, role FROM users WHERE id = $1',
        [decoded.sub]
      );
      if (rows.length === 0) return next(new Error('User not found'));
      if (rows[0].role === 'banned') return next(new Error('Account banned'));

      socket.data.userId = rows[0].id as string;
      socket.data.handle = rows[0].handle as string;
      socket.data.role   = rows[0].role as string;
      next();
    } catch {
      next(new Error('Invalid token'));
    }
  });

  io.on('connection', async (socket: AppSocket) => {
    const { userId, handle } = socket.data;

    // ── Online presence ───────────────────────────────────────
    await redis.sadd(Keys.onlineUsers(), userId);
    await redis.setex(Keys.userStatus(userId), PRESENCE_TTL, 'online');

    // Update last_seen
    await db.query('UPDATE users SET last_seen = NOW() WHERE id = $1', [userId]);

    // Broadcast to everyone
    io.emit('presence:update', { userId, handle, status: 'online' });

    // ── Chat: join room ───────────────────────────────────────
    socket.on('chat:join', async (roomId) => {
      const { rows } = await db.query(
        'SELECT id FROM chat_rooms WHERE id = $1',
        [roomId]
      );
      if (rows.length === 0) {
        socket.emit('error', { message: 'Room not found' });
        return;
      }

      await socket.join(`room:${roomId}`);
      await redis.sadd(Keys.roomMembers(roomId), userId);

      // Notify room of join
      io.to(`room:${roomId}`).emit('chat:user_joined', { userId, handle, roomId });
    });

    // ── Chat: leave room ──────────────────────────────────────
    socket.on('chat:leave', async (roomId) => {
      await socket.leave(`room:${roomId}`);
      await redis.srem(Keys.roomMembers(roomId), userId);
      io.to(`room:${roomId}`).emit('chat:user_left', { userId, handle, roomId });
    });

    // ── Chat: send message ────────────────────────────────────
    socket.on('chat:message', async (payload) => {
      const { roomId, body } = payload;
      if (!body?.trim() || body.length > MAX_MSG_LEN) return;

      // Must be in the room
      if (!socket.rooms.has(`room:${roomId}`)) return;

      // Rate limiting per user
      const rlKey = `rl:chat:${userId}`;
      const count = await redis.incr(rlKey);
      if (count === 1) await redis.pexpire(rlKey, RL_WINDOW);
      if (count > RL_MAX) {
        socket.emit('error', { message: 'Slow down — you\'re sending messages too fast.' });
        return;
      }

      // Persist to DB
      const { rows } = await db.query(
        `INSERT INTO chat_messages (room_id, user_id, body)
         VALUES ($1, $2, $3) RETURNING id, created_at`,
        [roomId, userId, body.trim()]
      );

      const msg = {
        id:         rows[0].id as string,
        roomId,
        userId,
        userHandle: handle,
        userRole:   socket.data.role as 'validated',
        body:       body.trim(),
        createdAt:  (rows[0].created_at as Date).toISOString(),
      };

      // Broadcast to everyone in the room
      io.to(`room:${roomId}`).emit('chat:message', msg);
    });

    // ── Chat: typing indicator ────────────────────────────────
    socket.on('chat:typing', (roomId) => {
      // Only broadcast to others in the room
      if (!socket.rooms.has(`room:${roomId}`)) return;
      socket.to(`room:${roomId}`).emit('chat:typing', { userId, handle, roomId });
    });

    // ── Presence ping (keep-alive) ────────────────────────────
    socket.on('presence:ping', async () => {
      await redis.setex(Keys.userStatus(userId), PRESENCE_TTL, 'online');
      await db.query('UPDATE users SET last_seen = NOW() WHERE id = $1', [userId]);
    });

    // ── Door game I/O ─────────────────────────────────────────
    socket.on('door:input', (_payload) => {
      // Phase 5 — placeholder to avoid client errors
    });

    // ── Disconnect ────────────────────────────────────────────
    socket.on('disconnect', async () => {
      // Leave all rooms and clean up Redis membership
      for (const room of socket.rooms) {
        if (room.startsWith('room:')) {
          const roomId = room.replace('room:', '');
          await redis.srem(Keys.roomMembers(roomId), userId);
          io.to(room).emit('chat:user_left', { userId, handle, roomId });
        }
      }

      // Check if user has other active connections before marking offline
      const allSockets = await io.fetchSockets();
      const stillConnected = allSockets.some(
        (s) => s.id !== socket.id && (s.data as SocketData).userId === userId
      );

      if (!stillConnected) {
        await redis.srem(Keys.onlineUsers(), userId);
        await redis.del(Keys.userStatus(userId));
        await db.query('UPDATE users SET last_seen = NOW() WHERE id = $1', [userId]);
        io.emit('presence:update', { userId, handle, status: 'offline' });
      }
    });
  });

  // ── Presence decay sweep (every 2 minutes) ────────────────
  setInterval(async () => {
    const onlineIds = await redis.smembers(Keys.onlineUsers());
    for (const uid of onlineIds) {
      const status = await redis.get(Keys.userStatus(uid));
      if (!status) {
        // TTL expired — user timed out
        await redis.srem(Keys.onlineUsers(), uid);
        const { rows } = await db.query('SELECT handle FROM users WHERE id = $1', [uid]);
        if (rows.length > 0) {
          io.emit('presence:update', {
            userId: uid,
            handle: rows[0].handle as string,
            status: 'offline',
          });
        }
      }
    }
  }, 120_000);
}
