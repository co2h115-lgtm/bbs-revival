import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import {
  getRooms, getRoom, getRoomHistory,
  getRoomMembers, createRoom, getOnlineUsers,
} from '../services/chat.service.js';
import type { UserRole } from '@bbs/shared';

const createRoomSchema = z.object({
  name: z.string().min(1).max(64).trim(),
  description: z.string().max(255).trim().optional(),
});

function getUser(request: { user?: unknown }): { sub: string; role: UserRole } {
  return request.user as { sub: string; role: UserRole };
}

export async function chatRoutes(fastify: FastifyInstance) {
  // GET /api/chat/rooms
  fastify.get('/rooms', async (_req, reply) => {
    const rooms = await getRooms();
    return reply.send({ ok: true, data: rooms });
  });

  // GET /api/chat/rooms/:roomId
  fastify.get('/rooms/:roomId', async (request, reply) => {
    const { roomId } = request.params as { roomId: string };
    try {
      const room = await getRoom(roomId);
      return reply.send({ ok: true, data: room });
    } catch (err: unknown) {
      const e = err as Error & { statusCode?: number };
      return reply.code(e.statusCode ?? 500).send({ ok: false, error: e.message });
    }
  });

  // GET /api/chat/rooms/:roomId/history?before=<messageId>&limit=50
  fastify.get('/rooms/:roomId/history', { preHandler: [fastify.authenticate] }, async (request, reply) => {
    const { roomId } = request.params as { roomId: string };
    const q = request.query as { before?: string; limit?: string };
    const messages = await getRoomHistory(roomId, q.before, parseInt(q.limit ?? '50'));
    return reply.send({ ok: true, data: messages });
  });

  // GET /api/chat/rooms/:roomId/members
  fastify.get('/rooms/:roomId/members', { preHandler: [fastify.authenticate] }, async (request, reply) => {
    const { roomId } = request.params as { roomId: string };
    const members = await getRoomMembers(roomId);
    return reply.send({ ok: true, data: members });
  });

  // POST /api/chat/rooms  (validated users+)
  fastify.post('/rooms', { preHandler: [fastify.authenticate] }, async (request, reply) => {
    const { sub, role } = getUser(request);
    if (role === 'new' || role === 'banned') {
      return reply.code(403).send({ ok: false, error: 'Insufficient permissions' });
    }
    const body = createRoomSchema.safeParse(request.body);
    if (!body.success) return reply.code(400).send({ ok: false, error: body.error.issues[0].message });

    const roomId = await createRoom(body.data.name, body.data.description ?? '', sub);
    return reply.code(201).send({ ok: true, data: { roomId } });
  });

  // GET /api/chat/online
  fastify.get('/online', { preHandler: [fastify.authenticate] }, async (_req, reply) => {
    const users = await getOnlineUsers();
    return reply.send({ ok: true, data: users });
  });
}
