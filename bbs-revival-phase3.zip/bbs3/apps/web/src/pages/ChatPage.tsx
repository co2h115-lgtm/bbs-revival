import { useEffect, useRef, useState, useCallback } from 'react';
import { useAuthStore, apiFetch } from '../stores/auth.store';
import { useSocketStore } from '../stores/socket.store';
import type { ChatMessage, ChatRoom } from '@bbs/shared';
import { ROLE_DISPLAY } from '@bbs/shared';
import styles from './ChatPage.module.css';

export function ChatPage() {
  const { user, accessToken } = useAuthStore();
  const {
    socket, connected, connect,
    joinRoom, leaveRoom, sendMessage, sendTyping,
    setActiveRoom, loadHistory, clearUnread,
    messages, typingUsers, unreadCounts, onlineUsers, setRooms,
  } = useSocketStore();

  const [rooms, setLocalRooms] = useState<ChatRoom[]>([]);
  const [activeRoomId, setActiveRoomId_] = useState<string | null>(null);
  const [input, setInput] = useState('');
  const [loadingHistory, setLoadingHistory] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const typingTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Connect socket on mount
  useEffect(() => {
    if (!accessToken) return;
    if (!socket || !socket.connected) connect(accessToken);
    return () => {
      // Don't disconnect on unmount — keep alive while navigating
    };
  }, [accessToken, socket, connect]);

  // Load rooms
  useEffect(() => {
    apiFetch('/api/chat/rooms')
      .then((r) => r.json())
      .then((d) => {
        if (d.ok) {
          setLocalRooms(d.data);
          setRooms(d.data);
          // Auto-join first room
          if (d.data.length > 0 && !activeRoomId) {
            switchRoom(d.data[0].id);
          }
        }
      });
  }, []);

  // Scroll to bottom on new messages
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.get(activeRoomId ?? '')?.length]);

  const switchRoom = useCallback(async (roomId: string) => {
    if (activeRoomId && activeRoomId !== roomId) {
      leaveRoom(activeRoomId);
    }
    setActiveRoomId_(roomId);
    setActiveRoom(roomId);
    clearUnread(roomId);
    joinRoom(roomId);

    // Load history if not yet loaded
    const existing = messages.get(roomId) ?? [];
    if (existing.length === 0) {
      setLoadingHistory(true);
      try {
        const res = await apiFetch(`/api/chat/rooms/${roomId}/history`);
        const d = await res.json();
        if (d.ok) loadHistory(roomId, d.data);
      } finally {
        setLoadingHistory(false);
      }
    }
  }, [activeRoomId, leaveRoom, joinRoom, setActiveRoom, clearUnread, loadHistory, messages]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || !activeRoomId || !connected) return;
    sendMessage(activeRoomId, input.trim());
    setInput('');
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInput(e.target.value);

    // Debounce typing indicator
    if (!activeRoomId) return;
    if (typingTimeout.current) clearTimeout(typingTimeout.current);
    typingTimeout.current = setTimeout(() => {
      if (activeRoomId) sendTyping(activeRoomId);
    }, 400);
  };

  const activeMessages: ChatMessage[] = messages.get(activeRoomId ?? '') ?? [];
  const activeTyping = activeRoomId ? [...(typingUsers.get(activeRoomId) ?? [])] : [];
  const activeRoom = rooms.find((r) => r.id === activeRoomId);

  return (
    <div className={styles.layout}>
      {/* ── Room list ──────────────────────────────────────── */}
      <aside className={styles.roomList}>
        <div className={styles.roomListHeader}>CHAT ROOMS</div>
        {rooms.map((room) => {
          const unread = unreadCounts.get(room.id) ?? 0;
          const isActive = room.id === activeRoomId;
          return (
            <button
              key={room.id}
              className={`${styles.roomItem} ${isActive ? styles.roomItemActive : ''}`}
              onClick={() => switchRoom(room.id)}
            >
              <div className={styles.roomItemName}>
                {room.name}
                {unread > 0 && <span className={styles.unreadBadge}>{unread}</span>}
              </div>
              {room.description && (
                <div className={styles.roomItemDesc}>{room.description}</div>
              )}
            </button>
          );
        })}

        {/* Online users */}
        <div className={styles.onlineHeader}>
          ONLINE ({onlineUsers.size})
        </div>
        <div className={styles.onlineList}>
          {[...onlineUsers.values()].map((u) => (
            <div key={u.userId} className={styles.onlineUser}>
              <span className={styles.onlineDot} />
              {u.handle}
            </div>
          ))}
          {onlineUsers.size === 0 && (
            <div className={styles.onlineEmpty}>No one else here</div>
          )}
        </div>
      </aside>

      {/* ── Chat area ──────────────────────────────────────── */}
      <div className={styles.chatArea}>
        {/* Header */}
        <div className={styles.chatHeader}>
          <div className={styles.chatHeaderLeft}>
            <span className={styles.roomName}>{activeRoom?.name ?? 'Chat'}</span>
            {activeRoom?.description && (
              <span className={styles.roomDesc}> — {activeRoom.description}</span>
            )}
          </div>
          <div className={styles.connectionStatus}>
            <span className={connected ? styles.connDot : styles.connDotOff} />
            {connected ? 'CONNECTED' : 'RECONNECTING...'}
          </div>
        </div>

        {/* Messages */}
        <div className={styles.messages}>
          {loadingHistory && (
            <div className={styles.systemMsg}>Loading history...</div>
          )}

          {activeMessages.map((msg) => {
            const isSystem = msg.userId === 'system';
            const isSelf = msg.userId === user?.id;

            if (isSystem) {
              return (
                <div key={msg.id} className={styles.systemMsg}>{msg.body}</div>
              );
            }

            return (
              <div key={msg.id} className={`${styles.message} ${isSelf ? styles.self : ''}`}>
                <div className={styles.msgMeta}>
                  <span className={`${styles.msgHandle} ${getRoleClass(msg.userRole)}`}>
                    {msg.userHandle}
                  </span>
                  <span className={styles.msgRole}>{ROLE_DISPLAY[msg.userRole]}</span>
                  <span className={styles.msgTime}>
                    {formatTime(msg.createdAt)}
                  </span>
                </div>
                <div className={styles.msgBody}>{msg.body}</div>
              </div>
            );
          })}

          {/* Typing indicator */}
          {activeTyping.length > 0 && (
            <div className={styles.typing}>
              {activeTyping.join(', ')} {activeTyping.length === 1 ? 'is' : 'are'} typing
              <span className={styles.typingDots}>...</span>
            </div>
          )}

          <div ref={bottomRef} />
        </div>

        {/* Input */}
        <form className={styles.inputArea} onSubmit={handleSend}>
          <span className={styles.inputPrompt}>
            {user?.handle ?? 'GUEST'}&gt;
          </span>
          <input
            className={styles.input}
            type="text"
            value={input}
            onChange={handleInputChange}
            placeholder={connected ? 'Type a message...' : 'Connecting...'}
            disabled={!connected || !activeRoomId}
            maxLength={1000}
            autoComplete="off"
          />
          <button
            type="submit"
            className={styles.sendBtn}
            disabled={!connected || !input.trim() || !activeRoomId}
          >
            SEND
          </button>
        </form>
      </div>
    </div>
  );
}

function getRoleClass(role: string): string {
  const map: Record<string, string> = {
    sysop: styles.roleSysop,
    cosysop: styles.roleCosysop,
    validated: styles.roleUser,
    new: styles.roleNew,
  };
  return map[role] ?? '';
}

function formatTime(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
