import { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { WelcomeScreen } from './components/WelcomeScreen';
import { Shell } from './components/Shell';
import { AuthPage } from './pages/AuthPage';
import { BoardsPage } from './pages/BoardsPage';
import { ThreadListPage } from './pages/ThreadListPage';
import { ThreadPage } from './pages/ThreadPage';
import { MessagesPage } from './pages/MessagesPage';
import { SearchPage } from './pages/SearchPage';
import { ChatPage } from './pages/ChatPage';
import { PlaceholderPage } from './pages/PlaceholderPage';

export function App() {
  const [showWelcome, setShowWelcome] = useState(
    !sessionStorage.getItem('bbs_welcomed')
  );

  if (showWelcome) {
    return (
      <WelcomeScreen
        onContinue={() => {
          sessionStorage.setItem('bbs_welcomed', '1');
          setShowWelcome(false);
        }}
      />
    );
  }

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/auth" element={<AuthPage />} />

        <Route path="/" element={<Shell />}>
          <Route index element={<Navigate to="/boards" replace />} />

          {/* Phase 1 */}
          <Route path="boards" element={<BoardsPage />} />

          {/* Phase 2 */}
          <Route path="boards/:boardId" element={<ThreadListPage />} />
          <Route path="boards/threads/:threadId" element={<ThreadPage />} />
          <Route path="messages" element={<MessagesPage />} />
          <Route path="search" element={<SearchPage />} />

          {/* Phase 3 */}
          <Route path="chat" element={<ChatPage />} />

          {/* Phase 4–5 placeholders */}
          <Route path="files" element={
            <PlaceholderPage title="FILE AREAS" phase="Phase 4"
              description="Upload, browse, and download files. Organized by category with sysop approval queue." />
          } />
          <Route path="doors" element={
            <PlaceholderPage title="DOOR GAMES" phase="Phase 5"
              description="Classic BBS door games streamed over WebSocket. Leaderboards, session management." />
          } />
          <Route path="gallery" element={
            <PlaceholderPage title="ANSI ART GALLERY" phase="Phase 4"
              description="Community-submitted ANSI and ASCII art." />
          } />
          <Route path="profile" element={
            <PlaceholderPage title="MY PROFILE" phase="Phase 2 (coming soon)"
              description="View and edit your BBS profile, handle, bio, and account settings." />
          } />
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
