import { create } from 'zustand';
import { io, Socket } from 'socket.io-client';
import type { ServerToClientEvents, ClientToServerEvents, ChatMessage, ChatRoom } from '@bbs/shared';

type AppSocket = Socket<ServerToClientEvents, ClientToServerEvents>;

interface OnlineUser {
  userId: string;
  handle: string;
  status: 'online' | 'offline' | 'away';
}

interface SocketState {
  socket: AppSocket | null;
  connected: boolean;
  onlineUsers: Map<string, OnlineUser>;
  rooms: ChatRoom[];
  // roomId → messages
  messages: Map<string, ChatMessage[]>;
  // roomId → Set of typing user handles
  typingUsers: Map<string, Set<string>>;
  // roomId → unread count
  unreadCounts: Map<string, number>;
  activeRoomId: string | null;

  connect: (token: string) => void;
  disconnect: () => void;
  joinRoom: (roomId: string) => void;
  leaveRoom: (roomId: string) => void;
  sendMessage: (roomId: string, body: string) => void;
  sendTyping: (roomId: string) => void;
  setActiveRoom: (roomId: string | null) => void;
  loadHistory: (roomId: string, messages: ChatMessage[]) => void;
  clearUnread: (roomId: string) => void;
  setRooms: (rooms: ChatRoom[]) => void;
}

export const useSocketStore = create<SocketState>((set, get) => ({
  socket: null,
  connected: false,
  onlineUsers: new Map(),
  rooms: [],
  messages: new Map(),
  typingUsers: new Map(),
  unreadCounts: new Map(),
  activeRoomId: null,

  connect: (token: string) => {
    const existing = get().socket;
    if (existing?.connected) return;

    const socket: AppSocket = io('/', {
      auth: { token },
      transports: ['websocket'],
      reconnectionAttempts: 5,
      reconnectionDelay: 2000,
    });

    socket.on('connect', () => {
      set({ connected: true });
      // Ping every 30s to maintain presence
      const pingInterval = setInterval(() => {
        if (socket.connected) socket.emit('presence:ping');
      }, 30_000);
      socket.on('disconnect', () => clearInterval(pingInterval));
    });

    socket.on('disconnect', () => set({ connected: false }));

    // ── Presence ─────────────────────────────────────────────
    socket.on('presence:update', (payload) => {
      set((state) => {
        const next = new Map(state.onlineUsers);
        if (payload.status === 'offline') {
          next.delete(payload.userId);
        } else {
          next.set(payload.userId, payload);
        }
        return { onlineUsers: next };
      });
    });

    // ── Chat messages ─────────────────────────────────────────
    socket.on('chat:message', (msg) => {
      set((state) => {
        const next = new Map(state.messages);
        const roomMsgs = [...(next.get(msg.roomId) ?? []), msg];
        // Keep last 200 messages in memory per room
        next.set(msg.roomId, roomMsgs.slice(-200));

        // Increment unread if not the active room
        const unread = new Map(state.unreadCounts);
        if (state.activeRoomId !== msg.roomId) {
          unread.set(msg.roomId, (unread.get(msg.roomId) ?? 0) + 1);
        }

        return { messages: next, unreadCounts: unread };
      });
    });

    // ── Typing ────────────────────────────────────────────────
    socket.on('chat:typing', ({ handle, roomId }) => {
      set((state) => {
        const next = new Map(state.typingUsers);
        const set_ = new Set(next.get(roomId) ?? []);
        set_.add(handle);
        next.set(roomId, set_);
        return { typingUsers: next };
      });

      // Clear typing indicator after 3s
      setTimeout(() => {
        set((state) => {
          const next = new Map(state.typingUsers);
          const set_ = new Set(next.get(roomId) ?? []);
          set_.delete(handle);
          next.set(roomId, set_);
          return { typingUsers: next };
        });
      }, 3000);
    });

    // ── Room join/leave notifications ─────────────────────────
    socket.on('chat:user_joined', ({ roomId, handle }) => {
      // Optionally show a join message — inject as system message
      set((state) => {
        const next = new Map(state.messages);
        const roomMsgs = next.get(roomId) ?? [];
        next.set(roomId, [
          ...roomMsgs,
          {
            id: `system-${Date.now()}`,
            roomId,
            userId: 'system',
            userHandle: 'SYSTEM',
            userRole: 'validated' as const,
            body: `*** ${handle} has joined ***`,
            createdAt: new Date().toISOString(),
          },
        ]);
        return { messages: next };
      });
    });

    socket.on('chat:user_left', ({ roomId, handle }) => {
      set((state) => {
        const next = new Map(state.messages);
        const roomMsgs = next.get(roomId) ?? [];
        next.set(roomId, [
          ...roomMsgs,
          {
            id: `system-${Date.now()}`,
            roomId,
            userId: 'system',
            userHandle: 'SYSTEM',
            userRole: 'validated' as const,
            body: `*** ${handle} has left ***`,
            createdAt: new Date().toISOString(),
          },
        ]);
        return { messages: next };
      });
    });

    // ── System broadcast ──────────────────────────────────────
    socket.on('system:broadcast', ({ message, from }) => {
      // Inject into every open room
      set((state) => {
        const next = new Map(state.messages);
        for (const [roomId, msgs] of next.entries()) {
          next.set(roomId, [
            ...msgs,
            {
              id: `broadcast-${Date.now()}`,
              roomId,
              userId: 'system',
              userHandle: `[${from}]`,
              userRole: 'sysop' as const,
              body: `🔔 BROADCAST: ${message}`,
              createdAt: new Date().toISOString(),
            },
          ]);
        }
        return { messages: next };
      });
    });

    socket.on('error', ({ message }) => {
      console.warn('Socket error:', message);
    });

    set({ socket });
  },

  disconnect: () => {
    const { socket } = get();
    socket?.disconnect();
    set({
      socket: null,
      connected: false,
      onlineUsers: new Map(),
      messages: new Map(),
      typingUsers: new Map(),
      unreadCounts: new Map(),
      activeRoomId: null,
    });
  },

  joinRoom: (roomId) => {
    get().socket?.emit('chat:join', roomId);
    set((state) => {
      if (!state.messages.has(roomId)) {
        const next = new Map(state.messages);
        next.set(roomId, []);
        return { messages: next };
      }
      return {};
    });
  },

  leaveRoom: (roomId) => {
    get().socket?.emit('chat:leave', roomId);
  },

  sendMessage: (roomId, body) => {
    get().socket?.emit('chat:message', { roomId, body });
  },

  sendTyping: (roomId) => {
    get().socket?.emit('chat:typing', roomId);
  },

  setActiveRoom: (roomId) => {
    set({ activeRoomId: roomId });
    if (roomId) {
      set((state) => {
        const next = new Map(state.unreadCounts);
        next.delete(roomId);
        return { unreadCounts: next };
      });
    }
  },

  loadHistory: (roomId, messages) => {
    set((state) => {
      const next = new Map(state.messages);
      const existing = next.get(roomId) ?? [];
      // Prepend history, dedup by id
      const ids = new Set(existing.map((m) => m.id));
      const fresh = messages.filter((m) => !ids.has(m.id));
      next.set(roomId, [...fresh, ...existing]);
      return { messages: next };
    });
  },

  clearUnread: (roomId) => {
    set((state) => {
      const next = new Map(state.unreadCounts);
      next.delete(roomId);
      return { unreadCounts: next };
    });
  },

  setRooms: (rooms) => set({ rooms }),
}));
