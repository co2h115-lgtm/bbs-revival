# Phase 3 — Integration Instructions

No new migrations. No new dependencies (socket.io-client was already in Phase 1).

---

## New Files — copy into place

### Server
```
apps/server/src/services/chat.service.ts   → copy as-is
apps/server/src/routes/chat.routes.ts      → copy as-is
```

### Web
```
apps/web/src/stores/socket.store.ts              → copy as-is
apps/web/src/pages/ChatPage.tsx                  → copy as-is
apps/web/src/pages/ChatPage.module.css           → copy as-is
```

---

## Files to Replace Entirely

```
apps/server/src/plugins/socket.ts    → replace (enhanced presence decay, door:input stub)
apps/server/src/index.ts             → replace (adds chatRoutes registration)
apps/web/src/App.tsx                 → replace (adds /chat route)
apps/web/src/components/Shell.tsx    → replace (connects socket on login, chat unread badge)
apps/web/src/components/Shell.module.css → replace (adds connDotYellow, onlineDotOff, fixes pmBadge)
```

---

## After Merging — Test It

```bash
pnpm dev
```

1. Log in and click **Chat Rooms** in the sidebar
2. You should see the 3 default rooms (General, Tech Talk, Game Room)
3. Click a room — history loads, you're joined
4. Type a message — it appears instantly
5. Open a second browser tab, log in as sysop — both users see each other online
6. Type in one tab — the other sees the typing indicator
7. The sidebar shows a green connection dot when connected

---

## What's New in Phase 3

| Feature | Detail |
|---------|--------|
| Multi-room chat | Join/leave rooms, separate message histories |
| Persistent history | Loaded from DB on first join, 50 messages back |
| Real-time messaging | Socket.io with rate limiting (10 msg/10s) |
| Typing indicators | Debounced, auto-clear after 3s |
| Presence system | Online/offline via Redis with TTL decay |
| Join/leave notices | System messages when users enter/leave a room |
| System broadcast | Sysop can emit a message to all connected clients |
| Unread badges | Per-room unread counts in the chat sidebar |
| Chat unread in nav | Total unread shown on "Chat Rooms" nav item |
| Connection status | Live dot in sidebar and chat header |
| Multi-tab awareness | Won't mark offline until ALL tabs disconnect |
| Presence decay sweep | Background job clears stale online entries |
