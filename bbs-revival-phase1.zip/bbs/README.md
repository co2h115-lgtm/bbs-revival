# BBS Revival

```
 ██████╗ ██████╗ ███████╗    ██████╗ ███████╗██╗   ██╗██╗██╗   ██╗ █████╗ ██╗
 ██╔══██╗██╔══██╗██╔════╝    ██╔══██╗██╔════╝██║   ██║██║██║   ██║██╔══██╗██║
 ██████╔╝██████╔╝███████╗    ██████╔╝█████╗  ██║   ██║██║██║   ██║███████║██║
 ██╔══██╗██╔══██╗╚════██║    ██╔══██╗██╔══╝  ╚██╗ ██╔╝██║╚██╗ ██╔╝██╔══██║██║
 ██████╔╝██████╔╝███████║    ██║  ██║███████╗ ╚████╔╝ ██║ ╚████╔╝ ██║  ██║███████╗
 ╚═════╝ ╚═════╝ ╚══════╝    ╚═╝  ╚═╝╚══════╝  ╚═══╝  ╚═╝  ╚═══╝  ╚═╝  ╚═╝╚══════╝
```

A modern, open-source BBS (Bulletin Board System) for the public internet. Authentic ANSI/ASCII aesthetics with contemporary infrastructure. Available on Web, Mobile, and Desktop.

---

## Phase 1 Complete ✅

- Monorepo (pnpm workspaces + Turborepo)
- PostgreSQL schema — users, sessions, boards, threads, posts, chat, files
- Fastify backend — auth (JWT + refresh tokens), boards API, users API
- Redis — presence, rate limiting, session cache
- React web app — boot screen, auth page, boards listing, shell navigation
- Docker Compose dev environment

---

## Prerequisites

- Node.js 20+
- pnpm 9+ (`npm install -g pnpm`)
- Docker + Docker Compose

---

## Quick Start

### 1. Clone and install

```bash
git clone <your-repo>
cd bbs-revival
pnpm install
```

### 2. Start infrastructure

```bash
docker compose up -d
```

This starts:
- PostgreSQL on port 5432
- Redis on port 6379
- MinIO on ports 9000/9001 (file storage, used in Phase 4)

### 3. Configure environment

```bash
cp apps/server/.env.example apps/server/.env
```

Edit `apps/server/.env` if needed. Defaults work out of the box with Docker Compose.

### 4. Run migrations

```bash
pnpm db:migrate
```

### 5. Seed the database

```bash
pnpm db:seed
```

This creates:
- Sysop account: `sysop@bbs.local` / `changeme123`
- Default board groups and boards
- Default chat rooms
- Welcome thread

### 6. Start development servers

```bash
pnpm dev
```

This starts:
- API server: http://localhost:3001
- Web app: http://localhost:5173

---

## Project Structure

```
bbs-revival/
├── apps/
│   ├── server/          # Fastify backend (Node.js + TypeScript)
│   │   ├── src/
│   │   │   ├── db/          # PostgreSQL pool, Redis client, migrations, seed
│   │   │   ├── plugins/     # Fastify plugins (auth decorator, socket.io)
│   │   │   ├── routes/      # API route handlers
│   │   │   └── services/    # Business logic (auth, etc.)
│   │   └── Dockerfile
│   ├── web/             # React + Vite web app
│   │   └── src/
│   │       ├── components/  # Shell, WelcomeScreen
│   │       ├── pages/       # AuthPage, BoardsPage, placeholders
│   │       └── stores/      # Zustand stores (auth)
│   ├── mobile/          # React Native (Phase 6)
│   └── desktop/         # Tauri (Phase 6)
├── packages/
│   ├── shared/          # Shared TypeScript types, constants, utilities
│   ├── ui/              # Shared React components (Phase 2+)
│   └── api-client/      # Typed API client (Phase 2+)
├── docker-compose.yml
├── turbo.json
└── pnpm-workspace.yaml
```

---

## API Reference

### Auth
| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/auth/register` | Register new user |
| POST | `/api/auth/login` | Login |
| POST | `/api/auth/refresh` | Refresh access token |
| POST | `/api/auth/logout` | Logout (revoke refresh token) |
| GET  | `/api/auth/me` | Get current user (auth required) |

### Boards
| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/boards` | List all board groups + boards |
| GET | `/api/boards/:id/threads` | List threads in a board |
| POST | `/api/boards/:id/threads` | Create new thread |
| GET | `/api/boards/threads/:id/posts` | Get posts in thread |
| POST | `/api/boards/threads/:id/posts` | Reply to thread |

### Users
| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/users/online` | List online users |
| GET | `/api/users/:handle` | Get user profile |
| PATCH | `/api/users/me` | Update own profile |

### Health
| Method | Path | Description |
|--------|------|-------------|
| GET | `/health` | Server health check |

---

## Default Sysop Account

After seeding:
- **Email:** `sysop@bbs.local`
- **Password:** `changeme123`
- **Role:** `sysop`

⚠️ Change the password immediately after first login in production.

---

## Roadmap

| Phase | Status | Features |
|-------|--------|----------|
| 1 | ✅ Done | Foundation — monorepo, DB, auth, web shell |
| 2 | ⏳ Next | Full message boards — threads, posts, PM, search |
| 3 | ⏳ | Real-time chat + presence |
| 4 | ⏳ | File areas + ANSI art gallery |
| 5 | ⏳ | Door games + terminal polish |
| 6 | ⏳ | Mobile (React Native) + Desktop (Tauri) + launch |

---

## Stack

**Backend:** Node.js + Fastify + PostgreSQL + Redis + Socket.io  
**Web:** React 18 + Vite + XTerm.js + Zustand  
**Mobile:** React Native (Expo) _(Phase 6)_  
**Desktop:** Tauri _(Phase 6)_  
**Monorepo:** pnpm workspaces + Turborepo

---

## License

MIT
