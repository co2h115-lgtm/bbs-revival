// ─────────────────────────────────────────────
//  User & Role types
// ─────────────────────────────────────────────

export type UserRole = 'sysop' | 'cosysop' | 'validated' | 'new' | 'banned';

export interface User {
  id: string;
  handle: string;
  email: string;
  role: UserRole;
  bio: string | null;
  location: string | null;
  postCount: number;
  createdAt: string;
  lastSeen: string | null;
}

export interface PublicUser {
  id: string;
  handle: string;
  role: UserRole;
  bio: string | null;
  location: string | null;
  postCount: number;
  createdAt: string;
  lastSeen: string | null;
}

// ─────────────────────────────────────────────
//  Auth types
// ─────────────────────────────────────────────

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
}

export interface RegisterBody {
  handle: string;
  email: string;
  password: string;
}

export interface LoginBody {
  email: string;
  password: string;
}

export interface RefreshBody {
  refreshToken: string;
}

// ─────────────────────────────────────────────
//  Board / Thread / Post types
// ─────────────────────────────────────────────

export interface BoardGroup {
  id: string;
  name: string;
  displayOrder: number;
  description: string | null;
}

export interface Board {
  id: string;
  groupId: string;
  name: string;
  description: string | null;
  minRole: UserRole;
  displayOrder: number;
  threadCount: number;
  postCount: number;
  lastPostAt: string | null;
}

export interface Thread {
  id: string;
  boardId: string;
  authorId: string;
  authorHandle: string;
  title: string;
  replyCount: number;
  locked: boolean;
  pinned: boolean;
  createdAt: string;
  lastPostAt: string;
}

export interface Post {
  id: string;
  threadId: string;
  authorId: string;
  authorHandle: string;
  authorRole: UserRole;
  body: string;
  createdAt: string;
  editedAt: string | null;
}

// ─────────────────────────────────────────────
//  Chat types
// ─────────────────────────────────────────────

export interface ChatRoom {
  id: string;
  name: string;
  description: string | null;
  isSystem: boolean;
  onlineCount: number;
}

export interface ChatMessage {
  id: string;
  roomId: string;
  userId: string;
  userHandle: string;
  userRole: UserRole;
  body: string;
  createdAt: string;
}

// ─────────────────────────────────────────────
//  Socket event types
// ─────────────────────────────────────────────

export interface ServerToClientEvents {
  'chat:message': (msg: ChatMessage) => void;
  'chat:typing': (payload: { userId: string; handle: string; roomId: string }) => void;
  'chat:user_joined': (payload: { userId: string; handle: string; roomId: string }) => void;
  'chat:user_left': (payload: { userId: string; handle: string; roomId: string }) => void;
  'presence:update': (payload: { userId: string; handle: string; status: 'online' | 'offline' | 'away' }) => void;
  'board:new_post': (payload: { boardId: string; threadId: string; postId: string }) => void;
  'door:output': (payload: { sessionId: string; data: string }) => void;
  'door:end': (payload: { sessionId: string; reason: string }) => void;
  'system:broadcast': (payload: { message: string; from: string }) => void;
  'error': (payload: { message: string }) => void;
}

export interface ClientToServerEvents {
  'chat:join': (roomId: string) => void;
  'chat:leave': (roomId: string) => void;
  'chat:message': (payload: { roomId: string; body: string }) => void;
  'chat:typing': (roomId: string) => void;
  'door:input': (payload: { sessionId: string; data: string }) => void;
  'presence:ping': () => void;
}

// ─────────────────────────────────────────────
//  API response wrapper
// ─────────────────────────────────────────────

export interface ApiSuccess<T> {
  ok: true;
  data: T;
}

export interface ApiError {
  ok: false;
  error: string;
  statusCode: number;
}

export type ApiResponse<T> = ApiSuccess<T> | ApiError;

// ─────────────────────────────────────────────
//  ANSI / Terminal utilities
// ─────────────────────────────────────────────

export const ANSI_COLORS = {
  reset: '\x1b[0m',
  bold: '\x1b[1m',
  dim: '\x1b[2m',
  black: '\x1b[30m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
  white: '\x1b[37m',
  bgBlack: '\x1b[40m',
  bgCyan: '\x1b[46m',
  brightCyan: '\x1b[96m',
  brightGreen: '\x1b[92m',
  brightYellow: '\x1b[93m',
} as const;

export const ROLE_DISPLAY: Record<UserRole, string> = {
  sysop: '[SYSOP]',
  cosysop: '[CO-SYS]',
  validated: '[USER]',
  new: '[NEW]',
  banned: '[BANNED]',
};

export const ROLE_ORDER: UserRole[] = ['banned', 'new', 'validated', 'cosysop', 'sysop'];

export function hasMinRole(userRole: UserRole, minRole: UserRole): boolean {
  return ROLE_ORDER.indexOf(userRole) >= ROLE_ORDER.indexOf(minRole);
}
