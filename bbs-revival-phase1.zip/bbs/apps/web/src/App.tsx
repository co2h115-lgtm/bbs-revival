import { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { WelcomeScreen } from './components/WelcomeScreen';
import { Shell } from './components/Shell';
import { AuthPage } from './pages/AuthPage';
import { BoardsPage } from './pages/BoardsPage';
import { PlaceholderPage } from './pages/PlaceholderPage';

export function App() {
  const [showWelcome, setShowWelcome] = useState(
    !sessionStorage.getItem('bbs_welcomed')
  );

  const handleWelcomeDone = () => {
    sessionStorage.setItem('bbs_welcomed', '1');
    setShowWelcome(false);
  };

  if (showWelcome) {
    return <WelcomeScreen onContinue={handleWelcomeDone} />;
  }

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/auth" element={<AuthPage />} />

        <Route path="/" element={<Shell />}>
          <Route index element={<Navigate to="/boards" replace />} />
          <Route path="boards" element={<BoardsPage />} />
          <Route path="chat" element={
            <PlaceholderPage
              title="CHAT ROOMS"
              phase="Phase 3"
              description="Real-time multi-room chat with ANSI color support, presence indicators, and typing notifications."
            />
          } />
          <Route path="files" element={
            <PlaceholderPage
              title="FILE AREAS"
              phase="Phase 4"
              description="Upload, browse, and download files. Organized by category with sysop approval queue."
            />
          } />
          <Route path="doors" element={
            <PlaceholderPage
              title="DOOR GAMES"
              phase="Phase 5"
              description="Classic BBS door games streamed over WebSocket. Leaderboards, session management, and more."
            />
          } />
          <Route path="gallery" element={
            <PlaceholderPage
              title="ANSI ART GALLERY"
              phase="Phase 4"
              description="Community-submitted ANSI and ASCII art. Browse, like, and submit your own creations."
            />
          } />
          <Route path="profile" element={
            <PlaceholderPage
              title="MY PROFILE"
              phase="Phase 1 (coming soon)"
              description="View and edit your BBS profile, handle, bio, and account settings."
            />
          } />
          <Route path="messages" element={
            <PlaceholderPage
              title="PRIVATE MAIL"
              phase="Phase 2"
              description="Send and receive private messages with other users on the board."
            />
          } />
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
