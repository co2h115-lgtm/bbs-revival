import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { apiFetch } from '../stores/auth.store';
import styles from './BoardsPage.module.css';

interface Board {
  id: string;
  name: string;
  description: string;
  min_role: string;
  thread_count: number;
  post_count: number;
  last_post_at: string | null;
}

interface BoardGroup {
  id: string;
  name: string;
  description: string;
  boards: Board[];
}

export function BoardsPage() {
  const [groups, setGroups] = useState<BoardGroup[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiFetch('/api/boards')
      .then((r) => r.json())
      .then((d) => { if (d.ok) setGroups(d.data); })
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className={styles.loading}>Loading boards...</div>;

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <h1 className={styles.title}>MESSAGE BOARDS</h1>
        <div className={styles.divider}>{'═'.repeat(60)}</div>
      </div>

      {groups.map((group) => (
        <div key={group.id} className={styles.group}>
          <div className={styles.groupHeader}>
            <span className={styles.groupName}>▸ {group.name.toUpperCase()}</span>
            {group.description && (
              <span className={styles.groupDesc}> — {group.description}</span>
            )}
          </div>

          <div className={styles.boardList}>
            {group.boards.map((board) => (
              <Link to={`/boards/${board.id}`} key={board.id} className={styles.boardRow}>
                <div className={styles.boardName}>{board.name}</div>
                <div className={styles.boardDesc}>{board.description}</div>
                <div className={styles.boardStats}>
                  <span className={styles.stat}>
                    <span className={styles.statLabel}>Threads:</span> {board.thread_count}
                  </span>
                  <span className={styles.stat}>
                    <span className={styles.statLabel}>Posts:</span> {board.post_count}
                  </span>
                  {board.last_post_at && (
                    <span className={styles.stat}>
                      <span className={styles.statLabel}>Last:</span>{' '}
                      {new Date(board.last_post_at).toLocaleDateString()}
                    </span>
                  )}
                </div>
              </Link>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
