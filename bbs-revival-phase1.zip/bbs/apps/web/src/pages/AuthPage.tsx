import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../stores/auth.store';
import styles from './AuthPage.module.css';

type Mode = 'login' | 'register';

export function AuthPage() {
  const [mode, setMode] = useState<Mode>('login');
  const [handle, setHandle] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login, register, loading, error, clearError } = useAuthStore();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    if (mode === 'login') {
      await login(email, password);
    } else {
      await register(handle, email, password);
    }
    const { user } = useAuthStore.getState();
    if (user) navigate('/boards');
  };

  return (
    <div className={styles.page}>
      <div className={styles.scanlines} />
      <div className={styles.container}>
        <div className={styles.header}>
          <pre className={styles.logo}>
{`
 ██████╗ ██████╗ ███████╗
 ██╔══██╗██╔══██╗██╔════╝
 ██████╔╝██████╔╝███████╗
 ██╔══██╗██╔══██╗╚════██║
 ██████╔╝██████╔╝███████║
 ╚═════╝ ╚═════╝ ╚══════╝`}
          </pre>
          <p className={styles.tagline}>BBS Revival — {mode === 'login' ? 'LOGON' : 'NEW USER REGISTRATION'}</p>
        </div>

        <div className={styles.card}>
          <div className={styles.tabs}>
            <button
              className={mode === 'login' ? styles.tabActive : styles.tab}
              onClick={() => { setMode('login'); clearError(); }}
            >
              [ LOGON ]
            </button>
            <button
              className={mode === 'register' ? styles.tabActive : styles.tab}
              onClick={() => { setMode('register'); clearError(); }}
            >
              [ NEW USER ]
            </button>
          </div>

          <form className={styles.form} onSubmit={handleSubmit}>
            {mode === 'register' && (
              <div className={styles.field}>
                <label className={styles.label}>HANDLE:</label>
                <input
                  type="text"
                  value={handle}
                  onChange={(e) => setHandle(e.target.value)}
                  placeholder="Your BBS handle (3–32 chars)"
                  autoComplete="username"
                  required
                  maxLength={32}
                />
              </div>
            )}

            <div className={styles.field}>
              <label className={styles.label}>EMAIL:</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="user@example.com"
                autoComplete="email"
                required
              />
            </div>

            <div className={styles.field}>
              <label className={styles.label}>PASSWORD:</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={mode === 'register' ? 'Minimum 8 characters' : '••••••••'}
                autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                required
                minLength={mode === 'register' ? 8 : 1}
              />
            </div>

            {error && (
              <div className={styles.error}>
                ❌ {error}
              </div>
            )}

            <button
              type="submit"
              className={`btn-primary ${styles.submit}`}
              disabled={loading}
            >
              {loading
                ? '[ CONNECTING... ]'
                : mode === 'login'
                ? '[ CONNECT TO BBS ]'
                : '[ CREATE ACCOUNT ]'}
            </button>
          </form>

          <div className={styles.footer}>
            <span className={styles.footerDim}>
              {mode === 'login'
                ? 'No account? '
                : 'Already registered? '}
            </span>
            <button
              className={styles.switchLink}
              onClick={() => { setMode(mode === 'login' ? 'register' : 'login'); clearError(); }}
            >
              {mode === 'login' ? 'Register as new user' : 'Log on instead'}
            </button>
          </div>
        </div>

        <div className={styles.statusBar}>
          <span className={styles.statusDot} />
          <span>BBS REVIVAL — OPEN TO ALL — BE EXCELLENT</span>
        </div>
      </div>
    </div>
  );
}
