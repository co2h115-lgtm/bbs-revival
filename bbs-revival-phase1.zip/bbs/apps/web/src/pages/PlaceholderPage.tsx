import styles from './Placeholder.module.css';

interface Props {
  title: string;
  phase: string;
  description: string;
}

export function PlaceholderPage({ title, phase, description }: Props) {
  return (
    <div className={styles.page}>
      <div className={styles.box}>
        <div className={styles.phase}>{phase}</div>
        <h1 className={styles.title}>{title}</h1>
        <p className={styles.desc}>{description}</p>
        <div className={styles.progress}>
          <span className={styles.bar}>{'░'.repeat(20)}</span>
          <span className={styles.label}> COMING SOON</span>
        </div>
      </div>
    </div>
  );
}
