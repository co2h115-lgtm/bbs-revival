import { useEffect, useRef, useState } from 'react';
import styles from './WelcomeScreen.module.css';

const BBS_NAME = 'BBS REVIVAL';

const SPLASH_FRAMES = [
  `
  ██████╗ ██████╗ ███████╗    ██████╗ ███████╗██╗   ██╗██╗██╗   ██╗ █████╗ ██╗
  ██╔══██╗██╔══██╗██╔════╝    ██╔══██╗██╔════╝██║   ██║██║██║   ██║██╔══██╗██║
  ██████╔╝██████╔╝███████╗    ██████╔╝█████╗  ██║   ██║██║██║   ██║███████║██║
  ██╔══██╗██╔══██╗╚════██║    ██╔══██╗██╔══╝  ╚██╗ ██╔╝██║╚██╗ ██╔╝██╔══██║██║
  ██████╔╝██████╔╝███████║    ██║  ██║███████╗ ╚████╔╝ ██║ ╚████╔╝ ██║  ██║███████╗
  ╚═════╝ ╚═════╝ ╚══════╝    ╚═╝  ╚═╝╚══════╝  ╚═══╝  ╚═╝  ╚═══╝  ╚═╝  ╚═╝╚══════╝
  `,
];

const BOOT_LINES = [
  { text: '████ INITIALIZING SYSTEM...', delay: 0, color: 'cyan' },
  { text: '', delay: 200 },
  { text: 'BIOS v2.4.1  [BBS-Revival Systems]', delay: 300, color: 'dim' },
  { text: 'CPU: Neural Engine v∞  RAM: ∞K  VIDEO: ANSI/VT100', delay: 500, color: 'dim' },
  { text: '', delay: 700 },
  { text: 'Loading message boards...........[OK]', delay: 900, color: 'green' },
  { text: 'Loading chat subsystem...........[OK]', delay: 1200, color: 'green' },
  { text: 'Loading file areas...............[OK]', delay: 1500, color: 'green' },
  { text: 'Loading door games...............[OK]', delay: 1800, color: 'green' },
  { text: 'Connecting to network............[OK]', delay: 2100, color: 'green' },
  { text: '', delay: 2400 },
  { text: `Welcome to ${BBS_NAME}`, delay: 2700, color: 'yellow' },
  { text: 'Open to all. Be excellent.', delay: 3000, color: 'dim' },
  { text: '', delay: 3300 },
  { text: '[ PRESS ANY KEY TO CONTINUE ]', delay: 3600, color: 'blink' },
];

interface WelcomeScreenProps {
  onContinue: () => void;
}

export function WelcomeScreen({ onContinue }: WelcomeScreenProps) {
  const [visibleLines, setVisibleLines] = useState<typeof BOOT_LINES>([]);
  const [ready, setReady] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let timeouts: ReturnType<typeof setTimeout>[] = [];

    BOOT_LINES.forEach((line, i) => {
      const t = setTimeout(() => {
        setVisibleLines((prev) => [...prev, line]);
        if (containerRef.current) {
          containerRef.current.scrollTop = containerRef.current.scrollHeight;
        }
        if (i === BOOT_LINES.length - 1) setReady(true);
      }, line.delay);
      timeouts.push(t);
    });

    return () => timeouts.forEach(clearTimeout);
  }, []);

  useEffect(() => {
    if (!ready) return;
    const handler = () => onContinue();
    window.addEventListener('keydown', handler, { once: true });
    window.addEventListener('click', handler, { once: true });
    return () => {
      window.removeEventListener('keydown', handler);
      window.removeEventListener('click', handler);
    };
  }, [ready, onContinue]);

  return (
    <div className={styles.screen}>
      <div className={styles.scanlines} />
      <div className={styles.container} ref={containerRef}>
        <pre className={styles.logo}>{SPLASH_FRAMES[0]}</pre>
        <div className={styles.bootLog}>
          {visibleLines.map((line, i) => (
            <div
              key={i}
              className={`${styles.line} ${line.color ? styles[line.color] : ''}`}
            >
              {line.text || '\u00a0'}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
