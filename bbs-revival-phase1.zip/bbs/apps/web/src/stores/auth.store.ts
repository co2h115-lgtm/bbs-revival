import { create } from 'zustand';
import type { User } from '@bbs/shared';

const API = '/api';

interface AuthState {
  user: User | null;
  accessToken: string | null;
  refreshToken: string | null;
  loading: boolean;
  error: string | null;

  login: (email: string, password: string) => Promise<void>;
  register: (handle: string, email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  refresh: () => Promise<boolean>;
  clearError: () => void;
  setUser: (user: User) => void;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  accessToken: localStorage.getItem('bbs_access_token'),
  refreshToken: localStorage.getItem('bbs_refresh_token'),
  loading: false,
  error: null,

  login: async (email, password) => {
    set({ loading: true, error: null });
    try {
      const res = await fetch(`${API}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!data.ok) throw new Error(data.error);

      const { user, accessToken, refreshToken } = data.data;
      localStorage.setItem('bbs_access_token', accessToken);
      localStorage.setItem('bbs_refresh_token', refreshToken);
      set({ user, accessToken, refreshToken, loading: false });
    } catch (err) {
      set({ loading: false, error: (err as Error).message });
    }
  },

  register: async (handle, email, password) => {
    set({ loading: true, error: null });
    try {
      const res = await fetch(`${API}/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ handle, email, password }),
      });
      const data = await res.json();
      if (!data.ok) throw new Error(data.error);

      const { user, accessToken, refreshToken } = data.data;
      localStorage.setItem('bbs_access_token', accessToken);
      localStorage.setItem('bbs_refresh_token', refreshToken);
      set({ user, accessToken, refreshToken, loading: false });
    } catch (err) {
      set({ loading: false, error: (err as Error).message });
    }
  },

  logout: async () => {
    const { refreshToken } = get();
    if (refreshToken) {
      await fetch(`${API}/auth/logout`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refreshToken }),
      }).catch(() => {});
    }
    localStorage.removeItem('bbs_access_token');
    localStorage.removeItem('bbs_refresh_token');
    set({ user: null, accessToken: null, refreshToken: null });
  },

  refresh: async () => {
    const { refreshToken } = get();
    if (!refreshToken) return false;
    try {
      const res = await fetch(`${API}/auth/refresh`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refreshToken }),
      });
      const data = await res.json();
      if (!data.ok) {
        localStorage.removeItem('bbs_access_token');
        localStorage.removeItem('bbs_refresh_token');
        set({ user: null, accessToken: null, refreshToken: null });
        return false;
      }
      const { accessToken: newAccess, refreshToken: newRefresh } = data.data;
      localStorage.setItem('bbs_access_token', newAccess);
      localStorage.setItem('bbs_refresh_token', newRefresh);
      set({ accessToken: newAccess, refreshToken: newRefresh });
      return true;
    } catch {
      return false;
    }
  },

  clearError: () => set({ error: null }),
  setUser: (user) => set({ user }),
}));

// Authenticated fetch helper — auto-refreshes on 401
export async function apiFetch(
  url: string,
  options: RequestInit = {}
): Promise<Response> {
  const { accessToken, refresh } = useAuthStore.getState();

  const res = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
      ...(options.headers ?? {}),
    },
  });

  if (res.status === 401) {
    const refreshed = await refresh();
    if (!refreshed) return res;
    const { accessToken: newToken } = useAuthStore.getState();
    return fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(newToken ? { Authorization: `Bearer ${newToken}` } : {}),
        ...(options.headers ?? {}),
      },
    });
  }

  return res;
}
