import { db } from './pool.js';

const migrations: { name: string; sql: string }[] = [
  {
    name: '001_create_extensions',
    sql: `
      CREATE EXTENSION IF NOT EXISTS "pgcrypto";
      CREATE EXTENSION IF NOT EXISTS "pg_trgm";
    `,
  },
  {
    name: '002_create_users',
    sql: `
      CREATE TYPE user_role AS ENUM ('sysop', 'cosysop', 'validated', 'new', 'banned');

      CREATE TABLE users (
        id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        handle        VARCHAR(32) NOT NULL UNIQUE,
        email         VARCHAR(255) NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        role          user_role NOT NULL DEFAULT 'new',
        bio           TEXT,
        location      VARCHAR(128),
        post_count    INTEGER NOT NULL DEFAULT 0,
        email_verified BOOLEAN NOT NULL DEFAULT FALSE,
        created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        last_seen     TIMESTAMPTZ
      );

      CREATE INDEX idx_users_email ON users(email);
      CREATE INDEX idx_users_handle ON users(handle);
      CREATE INDEX idx_users_role ON users(role);
    `,
  },
  {
    name: '003_create_user_sessions',
    sql: `
      CREATE TABLE user_sessions (
        id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        user_id       UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        token_hash    TEXT NOT NULL UNIQUE,
        ip_address    INET,
        user_agent    TEXT,
        created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        expires_at    TIMESTAMPTZ NOT NULL,
        last_used_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );

      CREATE INDEX idx_sessions_user_id ON user_sessions(user_id);
      CREATE INDEX idx_sessions_token_hash ON user_sessions(token_hash);
      CREATE INDEX idx_sessions_expires_at ON user_sessions(expires_at);
    `,
  },
  {
    name: '004_create_email_verifications',
    sql: `
      CREATE TABLE email_verifications (
        id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        user_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        token      TEXT NOT NULL UNIQUE,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        expires_at TIMESTAMPTZ NOT NULL DEFAULT NOW() + INTERVAL '24 hours',
        used_at    TIMESTAMPTZ
      );

      CREATE INDEX idx_email_verif_token ON email_verifications(token);
      CREATE INDEX idx_email_verif_user ON email_verifications(user_id);
    `,
  },
  {
    name: '005_create_password_resets',
    sql: `
      CREATE TABLE password_resets (
        id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        user_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        token      TEXT NOT NULL UNIQUE,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        expires_at TIMESTAMPTZ NOT NULL DEFAULT NOW() + INTERVAL '1 hour',
        used_at    TIMESTAMPTZ
      );

      CREATE INDEX idx_password_resets_token ON password_resets(token);
    `,
  },
  {
    name: '006_create_board_groups',
    sql: `
      CREATE TABLE board_groups (
        id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        name          VARCHAR(64) NOT NULL,
        description   TEXT,
        display_order INTEGER NOT NULL DEFAULT 0,
        created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
    `,
  },
  {
    name: '007_create_boards',
    sql: `
      CREATE TABLE boards (
        id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        group_id      UUID NOT NULL REFERENCES board_groups(id) ON DELETE CASCADE,
        name          VARCHAR(64) NOT NULL,
        description   TEXT,
        min_role      user_role NOT NULL DEFAULT 'new',
        display_order INTEGER NOT NULL DEFAULT 0,
        thread_count  INTEGER NOT NULL DEFAULT 0,
        post_count    INTEGER NOT NULL DEFAULT 0,
        last_post_at  TIMESTAMPTZ,
        created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );

      CREATE INDEX idx_boards_group_id ON boards(group_id);
    `,
  },
  {
    name: '008_create_threads',
    sql: `
      CREATE TABLE threads (
        id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        board_id     UUID NOT NULL REFERENCES boards(id) ON DELETE CASCADE,
        author_id    UUID NOT NULL REFERENCES users(id),
        title        VARCHAR(255) NOT NULL,
        reply_count  INTEGER NOT NULL DEFAULT 0,
        view_count   INTEGER NOT NULL DEFAULT 0,
        locked       BOOLEAN NOT NULL DEFAULT FALSE,
        pinned       BOOLEAN NOT NULL DEFAULT FALSE,
        created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        last_post_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );

      CREATE INDEX idx_threads_board_id ON threads(board_id);
      CREATE INDEX idx_threads_author_id ON threads(author_id);
      CREATE INDEX idx_threads_last_post ON threads(board_id, last_post_at DESC);
      CREATE INDEX idx_threads_title_trgm ON threads USING gin(title gin_trgm_ops);
    `,
  },
  {
    name: '009_create_posts',
    sql: `
      CREATE TABLE posts (
        id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        thread_id  UUID NOT NULL REFERENCES threads(id) ON DELETE CASCADE,
        author_id  UUID NOT NULL REFERENCES users(id),
        body       TEXT NOT NULL,
        body_ansi  TEXT,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        edited_at  TIMESTAMPTZ,
        deleted_at TIMESTAMPTZ
      );

      CREATE INDEX idx_posts_thread_id ON posts(thread_id);
      CREATE INDEX idx_posts_author_id ON posts(author_id);
      CREATE INDEX idx_posts_body_trgm ON posts USING gin(body gin_trgm_ops);
    `,
  },
  {
    name: '010_create_thread_reads',
    sql: `
      CREATE TABLE thread_reads (
        user_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        thread_id  UUID NOT NULL REFERENCES threads(id) ON DELETE CASCADE,
        read_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        PRIMARY KEY (user_id, thread_id)
      );
    `,
  },
  {
    name: '011_create_chat_rooms',
    sql: `
      CREATE TABLE chat_rooms (
        id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        name        VARCHAR(64) NOT NULL,
        description TEXT,
        is_system   BOOLEAN NOT NULL DEFAULT FALSE,
        created_by  UUID REFERENCES users(id),
        created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
    `,
  },
  {
    name: '012_create_chat_messages',
    sql: `
      CREATE TABLE chat_messages (
        id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        room_id    UUID NOT NULL REFERENCES chat_rooms(id) ON DELETE CASCADE,
        user_id    UUID NOT NULL REFERENCES users(id),
        body       TEXT NOT NULL,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );

      CREATE INDEX idx_chat_messages_room ON chat_messages(room_id, created_at DESC);
      CREATE INDEX idx_chat_messages_user ON chat_messages(user_id);
    `,
  },
  {
    name: '013_create_private_messages',
    sql: `
      CREATE TABLE private_messages (
        id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        from_id    UUID NOT NULL REFERENCES users(id),
        to_id      UUID NOT NULL REFERENCES users(id),
        subject    VARCHAR(255) NOT NULL,
        body       TEXT NOT NULL,
        read_at    TIMESTAMPTZ,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );

      CREATE INDEX idx_pm_to_id ON private_messages(to_id, created_at DESC);
      CREATE INDEX idx_pm_from_id ON private_messages(from_id, created_at DESC);
    `,
  },
  {
    name: '014_create_audit_log',
    sql: `
      CREATE TABLE audit_log (
        id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        actor_id    UUID REFERENCES users(id),
        action      VARCHAR(64) NOT NULL,
        target_type VARCHAR(32),
        target_id   UUID,
        meta        JSONB,
        ip_address  INET,
        created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );

      CREATE INDEX idx_audit_actor ON audit_log(actor_id);
      CREATE INDEX idx_audit_action ON audit_log(action);
      CREATE INDEX idx_audit_created ON audit_log(created_at DESC);
    `,
  },
  {
    name: '015_create_migrations_table',
    sql: `
      -- (self-referential, already handled by migration runner)
    `,
  },
];

async function runMigrations() {
  const client = await db.connect();
  try {
    // Create migrations tracking table
    await client.query(`
      CREATE TABLE IF NOT EXISTS schema_migrations (
        name       TEXT PRIMARY KEY,
        applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      )
    `);

    for (const migration of migrations) {
      const { rows } = await client.query(
        'SELECT name FROM schema_migrations WHERE name = $1',
        [migration.name]
      );

      if (rows.length > 0) {
        console.log(`  ✓ ${migration.name} (already applied)`);
        continue;
      }

      await client.query('BEGIN');
      try {
        await client.query(migration.sql);
        await client.query(
          'INSERT INTO schema_migrations (name) VALUES ($1)',
          [migration.name]
        );
        await client.query('COMMIT');
        console.log(`  ✅ ${migration.name}`);
      } catch (err) {
        await client.query('ROLLBACK');
        throw err;
      }
    }

    console.log('\n✅ All migrations applied successfully.\n');
  } finally {
    client.release();
    await db.end();
  }
}

runMigrations().catch((err) => {
  console.error('❌ Migration failed:', err);
  process.exit(1);
});
