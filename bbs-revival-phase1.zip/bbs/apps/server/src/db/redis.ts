import Redis from 'ioredis';

if (!process.env.REDIS_URL) {
  throw new Error('REDIS_URL environment variable is required');
}

export const redis = new Redis(process.env.REDIS_URL, {
  maxRetriesPerRequest: 3,
  enableReadyCheck: true,
  lazyConnect: false,
});

redis.on('error', (err) => {
  console.error('Redis error:', err);
});

// Key helpers — keeps key naming consistent across the app
export const Keys = {
  session: (userId: string) => `session:${userId}`,
  onlineUsers: () => 'presence:online',
  userStatus: (userId: string) => `presence:status:${userId}`,
  roomMembers: (roomId: string) => `chat:room:${roomId}:members`,
  rateLimitAuth: (ip: string) => `rl:auth:${ip}`,
  emailVerifyToken: (token: string) => `verify:${token}`,
  refreshToken: (tokenHash: string) => `refresh:${tokenHash}`,
};

export async function checkRedisConnection(): Promise<void> {
  await redis.ping();
}
