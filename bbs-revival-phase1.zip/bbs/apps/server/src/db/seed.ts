import { db } from './pool.js';
import bcrypt from 'bcrypt';

async function seed() {
  const client = await db.connect();

  try {
    console.log('🌱 Seeding database...\n');

    // ── Sysop user ──────────────────────────────────────────
    const existing = await client.query(
      "SELECT id FROM users WHERE email = 'sysop@bbs.local'"
    );

    let sysopId: string;

    if (existing.rows.length === 0) {
      const hash = await bcrypt.hash('changeme123', 12);
      const { rows } = await client.query(
        `INSERT INTO users (handle, email, password_hash, role, email_verified, bio)
         VALUES ($1, $2, $3, 'sysop', true, $4)
         RETURNING id`,
        [
          'SYSOP',
          'sysop@bbs.local',
          hash,
          'I run this board. Welcome to the BBS.',
        ]
      );
      sysopId = rows[0].id;
      console.log('  ✅ Created sysop user (email: sysop@bbs.local / pass: changeme123)');
    } else {
      sysopId = existing.rows[0].id;
      console.log('  ✓  Sysop user already exists');
    }

    // ── Board groups ────────────────────────────────────────
    const groups = [
      { name: 'General', description: 'General discussion boards', order: 1 },
      { name: 'Tech', description: 'Technology and programming', order: 2 },
      { name: 'Games', description: 'Games and door games', order: 3 },
      { name: 'Creative', description: 'ANSI art, writing, and creative work', order: 4 },
      { name: 'Sysop', description: 'Sysop and administration', order: 5 },
    ];

    const groupIds: Record<string, string> = {};

    for (const group of groups) {
      const existing = await client.query(
        'SELECT id FROM board_groups WHERE name = $1',
        [group.name]
      );
      if (existing.rows.length === 0) {
        const { rows } = await client.query(
          `INSERT INTO board_groups (name, description, display_order)
           VALUES ($1, $2, $3) RETURNING id`,
          [group.name, group.description, group.order]
        );
        groupIds[group.name] = rows[0].id;
        console.log(`  ✅ Created board group: ${group.name}`);
      } else {
        groupIds[group.name] = existing.rows[0].id;
        console.log(`  ✓  Board group exists: ${group.name}`);
      }
    }

    // ── Boards ──────────────────────────────────────────────
    const boards = [
      { group: 'General', name: 'Lobby', description: 'Say hello — new users start here', role: 'new', order: 1 },
      { group: 'General', name: 'Announcements', description: 'Official BBS announcements', role: 'new', order: 2 },
      { group: 'General', name: 'Off-Topic', description: 'Anything goes', role: 'validated', order: 3 },
      { group: 'Tech', name: 'Programming', description: 'Code, tools, and dev talk', role: 'validated', order: 1 },
      { group: 'Tech', name: 'Networking', description: 'Networks, protocols, and hardware', role: 'validated', order: 2 },
      { group: 'Tech', name: 'Security', description: 'Infosec, CTFs, and research', role: 'validated', order: 3 },
      { group: 'Games', name: 'Door Games', description: 'Discussion about door games', role: 'validated', order: 1 },
      { group: 'Games', name: 'Game Reviews', description: 'Reviews and recommendations', role: 'validated', order: 2 },
      { group: 'Creative', name: 'ANSI Art Gallery', description: 'Share your ANSI and ASCII art', role: 'validated', order: 1 },
      { group: 'Creative', name: 'Writing', description: 'Stories, poetry, and creative writing', role: 'validated', order: 2 },
      { group: 'Sysop', name: 'Sysop Lounge', description: 'Sysop-only discussions', role: 'cosysop', order: 1 },
    ];

    for (const board of boards) {
      const gid = groupIds[board.group];
      if (!gid) continue;
      const existing = await client.query(
        'SELECT id FROM boards WHERE name = $1 AND group_id = $2',
        [board.name, gid]
      );
      if (existing.rows.length === 0) {
        await client.query(
          `INSERT INTO boards (group_id, name, description, min_role, display_order)
           VALUES ($1, $2, $3, $4, $5)`,
          [gid, board.name, board.description, board.role, board.order]
        );
        console.log(`  ✅ Created board: ${board.group} > ${board.name}`);
      } else {
        console.log(`  ✓  Board exists: ${board.name}`);
      }
    }

    // ── Chat rooms ──────────────────────────────────────────
    const rooms = [
      { name: 'General', description: 'Main chat room — always open', isSystem: true },
      { name: 'Tech Talk', description: 'Technical discussions in real-time', isSystem: true },
      { name: 'Game Room', description: 'Games and door game chat', isSystem: true },
    ];

    for (const room of rooms) {
      const existing = await client.query(
        'SELECT id FROM chat_rooms WHERE name = $1',
        [room.name]
      );
      if (existing.rows.length === 0) {
        await client.query(
          `INSERT INTO chat_rooms (name, description, is_system, created_by)
           VALUES ($1, $2, $3, $4)`,
          [room.name, room.description, room.isSystem, sysopId]
        );
        console.log(`  ✅ Created chat room: ${room.name}`);
      } else {
        console.log(`  ✓  Chat room exists: ${room.name}`);
      }
    }

    // ── Welcome post ────────────────────────────────────────
    const lobbyBoard = await client.query(
      "SELECT id FROM boards WHERE name = 'Lobby'"
    );
    if (lobbyBoard.rows.length > 0) {
      const boardId = lobbyBoard.rows[0].id;
      const existingThread = await client.query(
        "SELECT id FROM threads WHERE title = 'Welcome to the BBS!'"
      );
      if (existingThread.rows.length === 0) {
        const { rows: threadRows } = await client.query(
          `INSERT INTO threads (board_id, author_id, title)
           VALUES ($1, $2, $3) RETURNING id`,
          [boardId, sysopId, 'Welcome to the BBS!']
        );
        const threadId = threadRows[0].id;
        await client.query(
          `INSERT INTO posts (thread_id, author_id, body)
           VALUES ($1, $2, $3)`,
          [
            threadId,
            sysopId,
            `Welcome, traveler.\r\n\r\nThis board is open to all. Register an account, introduce yourself in the Lobby, and explore.\r\n\r\nRules are simple: be excellent to each other.\r\n\r\n-- SYSOP`,
          ]
        );
        await client.query(
          `UPDATE boards SET thread_count = 1, post_count = 1, last_post_at = NOW()
           WHERE id = $1`,
          [boardId]
        );
        console.log('  ✅ Created welcome thread');
      }
    }

    console.log('\n✅ Seed complete.\n');
  } finally {
    client.release();
    await db.end();
  }
}

seed().catch((err) => {
  console.error('❌ Seed failed:', err);
  process.exit(1);
});
