import type { Server as SocketServer } from 'socket.io';
import type { ServerToClientEvents, ClientToServerEvents } from '@bbs/shared';
import { db } from '../db/pool.js';
import { redis, Keys } from '../db/redis.js';
import type { FastifyInstance } from 'fastify';

const PRESENCE_TTL = 60; // seconds before marked offline
const MAX_MESSAGE_LENGTH = 1000;
const RATE_LIMIT_WINDOW = 10_000; // ms
const RATE_LIMIT_MAX = 10; // messages per window

export function setupSocketHandlers(
  io: SocketServer<ClientToServerEvents, ServerToClientEvents>,
  fastify: FastifyInstance
) {
  // Auth middleware for socket connections
  io.use(async (socket, next) => {
    const token = socket.handshake.auth?.token as string | undefined;
    if (!token) return next(new Error('Authentication required'));

    try {
      const decoded = fastify.jwt.verify<{ sub: string }>(token);
      const { rows } = await db.query(
        'SELECT id, handle, role FROM users WHERE id = $1',
        [decoded.sub]
      );
      if (rows.length === 0) return next(new Error('User not found'));
      if (rows[0].role === 'banned') return next(new Error('Account banned'));

      socket.data.userId = rows[0].id as string;
      socket.data.handle = rows[0].handle as string;
      socket.data.role = rows[0].role as string;
      next();
    } catch {
      next(new Error('Invalid token'));
    }
  });

  io.on('connection', async (socket) => {
    const { userId, handle } = socket.data as { userId: string; handle: string };

    // Mark online
    await redis.sadd(Keys.onlineUsers(), userId);
    await redis.setex(Keys.userStatus(userId), PRESENCE_TTL, 'online');

    io.emit('presence:update', { userId, handle, status: 'online' });

    // ── Chat ──────────────────────────────────────────────────
    socket.on('chat:join', async (roomId) => {
      const { rows } = await db.query(
        'SELECT id FROM chat_rooms WHERE id = $1',
        [roomId]
      );
      if (rows.length === 0) return;

      await socket.join(`room:${roomId}`);
      await redis.sadd(Keys.roomMembers(roomId), userId);

      io.to(`room:${roomId}`).emit('chat:user_joined', { userId, handle, roomId });
    });

    socket.on('chat:leave', async (roomId) => {
      await socket.leave(`room:${roomId}`);
      await redis.srem(Keys.roomMembers(roomId), userId);
      io.to(`room:${roomId}`).emit('chat:user_left', { userId, handle, roomId });
    });

    socket.on('chat:message', async (payload) => {
      const { roomId, body } = payload;
      if (!body?.trim() || body.length > MAX_MESSAGE_LENGTH) return;

      // Rate limiting
      const rlKey = `rl:chat:${userId}`;
      const count = await redis.incr(rlKey);
      if (count === 1) await redis.pexpire(rlKey, RATE_LIMIT_WINDOW);
      if (count > RATE_LIMIT_MAX) {
        socket.emit('error', { message: 'You are sending messages too fast.' });
        return;
      }

      // Verify user is in the room
      if (!socket.rooms.has(`room:${roomId}`)) return;

      const { rows } = await db.query(
        `INSERT INTO chat_messages (room_id, user_id, body)
         VALUES ($1, $2, $3)
         RETURNING id, created_at`,
        [roomId, userId, body.trim()]
      );

      const msg = {
        id: rows[0].id as string,
        roomId,
        userId,
        userHandle: handle,
        userRole: socket.data.role as 'validated',
        body: body.trim(),
        createdAt: (rows[0].created_at as Date).toISOString(),
      };

      io.to(`room:${roomId}`).emit('chat:message', msg);
    });

    socket.on('chat:typing', (roomId) => {
      socket.to(`room:${roomId}`).emit('chat:typing', { userId, handle, roomId });
    });

    // ── Presence ping ─────────────────────────────────────────
    socket.on('presence:ping', async () => {
      await redis.setex(Keys.userStatus(userId), PRESENCE_TTL, 'online');
      await db.query('UPDATE users SET last_seen = NOW() WHERE id = $1', [userId]);
    });

    // ── Disconnect ────────────────────────────────────────────
    socket.on('disconnect', async () => {
      // Check if user has other active connections
      const sockets = await io.fetchSockets();
      const stillConnected = sockets.some(
        (s) => s.id !== socket.id && (s.data as { userId: string }).userId === userId
      );

      if (!stillConnected) {
        await redis.srem(Keys.onlineUsers(), userId);
        await redis.del(Keys.userStatus(userId));
        await db.query('UPDATE users SET last_seen = NOW() WHERE id = $1', [userId]);
        io.emit('presence:update', { userId, handle, status: 'offline' });
      }
    });
  });
}
