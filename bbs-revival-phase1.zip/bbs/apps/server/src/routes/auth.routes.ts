import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import {
  registerUser,
  loginUser,
  refreshTokens,
  revokeRefreshToken,
  getUserById,
} from '../services/auth.service.js';

const registerSchema = z.object({
  handle: z.string().min(3).max(32),
  email: z.string().email(),
  password: z.string().min(8).max(128),
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

const refreshSchema = z.object({
  refreshToken: z.string().min(1),
});

export async function authRoutes(fastify: FastifyInstance) {
  // POST /api/auth/register
  fastify.post('/register', async (request, reply) => {
    const body = registerSchema.safeParse(request.body);
    if (!body.success) {
      return reply.code(400).send({ ok: false, error: body.error.issues[0].message });
    }

    try {
      const result = await registerUser(body.data, fastify);
      return reply.code(201).send({ ok: true, data: result });
    } catch (err: unknown) {
      const e = err as Error & { statusCode?: number };
      return reply.code(e.statusCode ?? 500).send({ ok: false, error: e.message });
    }
  });

  // POST /api/auth/login
  fastify.post('/login', async (request, reply) => {
    const body = loginSchema.safeParse(request.body);
    if (!body.success) {
      return reply.code(400).send({ ok: false, error: body.error.issues[0].message });
    }

    try {
      const ip = request.ip;
      const result = await loginUser(body.data, fastify, ip);
      return reply.send({ ok: true, data: result });
    } catch (err: unknown) {
      const e = err as Error & { statusCode?: number };
      return reply.code(e.statusCode ?? 500).send({ ok: false, error: e.message });
    }
  });

  // POST /api/auth/refresh
  fastify.post('/refresh', async (request, reply) => {
    const body = refreshSchema.safeParse(request.body);
    if (!body.success) {
      return reply.code(400).send({ ok: false, error: 'refreshToken is required' });
    }

    try {
      const tokens = await refreshTokens(body.data.refreshToken, fastify);
      return reply.send({ ok: true, data: tokens });
    } catch (err: unknown) {
      const e = err as Error & { statusCode?: number };
      return reply.code(e.statusCode ?? 500).send({ ok: false, error: e.message });
    }
  });

  // POST /api/auth/logout
  fastify.post('/logout', async (request, reply) => {
    const body = refreshSchema.safeParse(request.body);
    if (body.success) {
      await revokeRefreshToken(body.data.refreshToken).catch(() => {});
    }
    return reply.send({ ok: true, data: null });
  });

  // GET /api/auth/me  (requires auth)
  fastify.get(
    '/me',
    {
      preHandler: [fastify.authenticate],
    },
    async (request, reply) => {
      const { sub } = request.user as { sub: string };
      const user = await getUserById(sub);
      if (!user) {
        return reply.code(404).send({ ok: false, error: 'User not found' });
      }
      return reply.send({ ok: true, data: { user } });
    }
  );
}
