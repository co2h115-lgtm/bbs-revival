import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { db } from '../db/pool.js';
import { hasMinRole } from '@bbs/shared';
import type { UserRole } from '@bbs/shared';

const createThreadSchema = z.object({
  title: z.string().min(1).max(255),
  body: z.string().min(1).max(50_000),
});

const createPostSchema = z.object({
  body: z.string().min(1).max(50_000),
});

export async function boardRoutes(fastify: FastifyInstance) {
  // GET /api/boards  — all groups with their boards
  fastify.get('/', async (_req, reply) => {
    const { rows: groups } = await db.query(
      'SELECT id, name, description, display_order FROM board_groups ORDER BY display_order'
    );
    const { rows: boards } = await db.query(
      `SELECT id, group_id, name, description, min_role, display_order,
              thread_count, post_count, last_post_at
       FROM boards ORDER BY group_id, display_order`
    );

    const result = groups.map((g) => ({
      ...g,
      boards: boards.filter((b) => b.group_id === g.id),
    }));

    return reply.send({ ok: true, data: result });
  });

  // GET /api/boards/:boardId/threads
  fastify.get('/:boardId/threads', async (request, reply) => {
    const { boardId } = request.params as { boardId: string };
    const query = request.query as { page?: string; limit?: string };
    const page = Math.max(1, parseInt(query.page ?? '1'));
    const limit = Math.min(50, parseInt(query.limit ?? '25'));
    const offset = (page - 1) * limit;

    const { rows: board } = await db.query(
      'SELECT id, min_role FROM boards WHERE id = $1',
      [boardId]
    );
    if (board.length === 0) {
      return reply.code(404).send({ ok: false, error: 'Board not found' });
    }

    const { rows } = await db.query(
      `SELECT t.id, t.board_id, t.title, t.reply_count, t.view_count,
              t.locked, t.pinned, t.created_at, t.last_post_at,
              u.id as author_id, u.handle as author_handle
       FROM threads t
       JOIN users u ON u.id = t.author_id
       WHERE t.board_id = $1
       ORDER BY t.pinned DESC, t.last_post_at DESC
       LIMIT $2 OFFSET $3`,
      [boardId, limit, offset]
    );

    const { rows: countRows } = await db.query(
      'SELECT COUNT(*) FROM threads WHERE board_id = $1',
      [boardId]
    );

    return reply.send({
      ok: true,
      data: {
        threads: rows,
        total: parseInt(countRows[0].count),
        page,
        limit,
      },
    });
  });

  // POST /api/boards/:boardId/threads
  fastify.post(
    '/:boardId/threads',
    { preHandler: [fastify.authenticate] },
    async (request, reply) => {
      const { sub } = request.user as { sub: string };
      const { boardId } = request.params as { boardId: string };

      const body = createThreadSchema.safeParse(request.body);
      if (!body.success) {
        return reply.code(400).send({ ok: false, error: body.error.issues[0].message });
      }

      const { rows: board } = await db.query(
        'SELECT id, min_role FROM boards WHERE id = $1',
        [boardId]
      );
      if (board.length === 0) {
        return reply.code(404).send({ ok: false, error: 'Board not found' });
      }

      const { rows: user } = await db.query('SELECT role FROM users WHERE id = $1', [sub]);
      if (user.length === 0 || !hasMinRole(user[0].role as UserRole, board[0].min_role as UserRole)) {
        return reply.code(403).send({ ok: false, error: 'Insufficient permissions' });
      }

      const client = await db.connect();
      try {
        await client.query('BEGIN');

        const { rows: threadRows } = await client.query(
          `INSERT INTO threads (board_id, author_id, title)
           VALUES ($1, $2, $3) RETURNING id`,
          [boardId, sub, body.data.title]
        );
        const threadId = threadRows[0].id;

        await client.query(
          `INSERT INTO posts (thread_id, author_id, body) VALUES ($1, $2, $3)`,
          [threadId, sub, body.data.body]
        );

        await client.query(
          `UPDATE boards SET thread_count = thread_count + 1,
                             post_count = post_count + 1,
                             last_post_at = NOW()
           WHERE id = $1`,
          [boardId]
        );

        await client.query(
          `UPDATE users SET post_count = post_count + 1 WHERE id = $1`,
          [sub]
        );

        await client.query('COMMIT');
        return reply.code(201).send({ ok: true, data: { threadId } });
      } catch (err) {
        await client.query('ROLLBACK');
        throw err;
      } finally {
        client.release();
      }
    }
  );

  // GET /api/boards/threads/:threadId/posts
  fastify.get('/threads/:threadId/posts', async (request, reply) => {
    const { threadId } = request.params as { threadId: string };
    const query = request.query as { page?: string };
    const page = Math.max(1, parseInt(query.page ?? '1'));
    const limit = 25;
    const offset = (page - 1) * limit;

    const { rows: thread } = await db.query(
      `SELECT t.*, u.handle as author_handle FROM threads t
       JOIN users u ON u.id = t.author_id WHERE t.id = $1`,
      [threadId]
    );
    if (thread.length === 0) {
      return reply.code(404).send({ ok: false, error: 'Thread not found' });
    }

    // Increment view count
    await db.query('UPDATE threads SET view_count = view_count + 1 WHERE id = $1', [threadId]);

    const { rows: posts } = await db.query(
      `SELECT p.id, p.thread_id, p.body, p.created_at, p.edited_at,
              u.id as author_id, u.handle as author_handle, u.role as author_role
       FROM posts p
       JOIN users u ON u.id = p.author_id
       WHERE p.thread_id = $1 AND p.deleted_at IS NULL
       ORDER BY p.created_at ASC
       LIMIT $2 OFFSET $3`,
      [threadId, limit, offset]
    );

    return reply.send({
      ok: true,
      data: { thread: thread[0], posts, page, limit },
    });
  });

  // POST /api/boards/threads/:threadId/posts
  fastify.post(
    '/threads/:threadId/posts',
    { preHandler: [fastify.authenticate] },
    async (request, reply) => {
      const { sub } = request.user as { sub: string };
      const { threadId } = request.params as { threadId: string };

      const body = createPostSchema.safeParse(request.body);
      if (!body.success) {
        return reply.code(400).send({ ok: false, error: body.error.issues[0].message });
      }

      const { rows: thread } = await db.query(
        `SELECT t.id, t.locked, b.min_role, b.id as board_id
         FROM threads t JOIN boards b ON b.id = t.board_id WHERE t.id = $1`,
        [threadId]
      );
      if (thread.length === 0) {
        return reply.code(404).send({ ok: false, error: 'Thread not found' });
      }
      if (thread[0].locked) {
        return reply.code(403).send({ ok: false, error: 'Thread is locked' });
      }

      const { rows: user } = await db.query('SELECT role FROM users WHERE id = $1', [sub]);
      if (!hasMinRole(user[0].role as UserRole, thread[0].min_role as UserRole)) {
        return reply.code(403).send({ ok: false, error: 'Insufficient permissions' });
      }

      const client = await db.connect();
      try {
        await client.query('BEGIN');

        const { rows } = await client.query(
          `INSERT INTO posts (thread_id, author_id, body) VALUES ($1, $2, $3) RETURNING id`,
          [threadId, sub, body.data.body]
        );

        await client.query(
          `UPDATE threads SET reply_count = reply_count + 1, last_post_at = NOW() WHERE id = $1`,
          [threadId]
        );
        await client.query(
          `UPDATE boards SET post_count = post_count + 1, last_post_at = NOW() WHERE id = $1`,
          [thread[0].board_id]
        );
        await client.query(
          `UPDATE users SET post_count = post_count + 1 WHERE id = $1`,
          [sub]
        );

        await client.query('COMMIT');
        return reply.code(201).send({ ok: true, data: { postId: rows[0].id } });
      } catch (err) {
        await client.query('ROLLBACK');
        throw err;
      } finally {
        client.release();
      }
    }
  );
}
