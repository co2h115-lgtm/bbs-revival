import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { db } from '../db/pool.js';
import { redis, Keys } from '../db/redis.js';

const updateProfileSchema = z.object({
  bio: z.string().max(500).optional(),
  location: z.string().max(128).optional(),
});

export async function userRoutes(fastify: FastifyInstance) {
  // GET /api/users/online
  fastify.get('/online', { preHandler: [fastify.authenticate] }, async (_req, reply) => {
    const onlineIds = await redis.smembers(Keys.onlineUsers());
    if (onlineIds.length === 0) return reply.send({ ok: true, data: [] });

    const placeholders = onlineIds.map((_, i) => `$${i + 1}`).join(',');
    const { rows } = await db.query(
      `SELECT id, handle, role, last_seen FROM users WHERE id IN (${placeholders})`,
      onlineIds
    );
    return reply.send({ ok: true, data: rows });
  });

  // GET /api/users/:handle
  fastify.get('/:handle', async (request, reply) => {
    const { handle } = request.params as { handle: string };
    const { rows } = await db.query(
      `SELECT id, handle, role, bio, location, post_count, created_at, last_seen
       FROM users WHERE handle ILIKE $1`,
      [handle]
    );
    if (rows.length === 0) {
      return reply.code(404).send({ ok: false, error: 'User not found' });
    }
    return reply.send({ ok: true, data: rows[0] });
  });

  // PATCH /api/users/me
  fastify.patch('/me', { preHandler: [fastify.authenticate] }, async (request, reply) => {
    const { sub } = request.user as { sub: string };
    const body = updateProfileSchema.safeParse(request.body);
    if (!body.success) {
      return reply.code(400).send({ ok: false, error: body.error.issues[0].message });
    }

    const updates: string[] = [];
    const values: unknown[] = [];

    if (body.data.bio !== undefined) {
      updates.push(`bio = $${updates.length + 1}`);
      values.push(body.data.bio);
    }
    if (body.data.location !== undefined) {
      updates.push(`location = $${updates.length + 1}`);
      values.push(body.data.location);
    }

    if (updates.length === 0) {
      return reply.code(400).send({ ok: false, error: 'No fields to update' });
    }

    values.push(sub);
    const { rows } = await db.query(
      `UPDATE users SET ${updates.join(', ')} WHERE id = $${values.length}
       RETURNING id, handle, email, role, bio, location, post_count, created_at, last_seen`,
      values
    );

    return reply.send({ ok: true, data: rows[0] });
  });
}
