import bcrypt from 'bcrypt';
import { nanoid } from 'nanoid';
import { createHash } from 'crypto';
import type { FastifyInstance } from 'fastify';
import { db } from '../db/pool.js';
import { redis, Keys } from '../db/redis.js';
import type { User } from '@bbs/shared';

const BCRYPT_ROUNDS = 12;
const ACCESS_TOKEN_TTL = 15 * 60; // 15 minutes in seconds
const REFRESH_TOKEN_TTL = 7 * 24 * 60 * 60; // 7 days in seconds

export function hashToken(token: string): string {
  return createHash('sha256').update(token).digest('hex');
}

export interface RegisterInput {
  handle: string;
  email: string;
  password: string;
}

export interface LoginInput {
  email: string;
  password: string;
}

export interface AuthResult {
  user: User;
  accessToken: string;
  refreshToken: string;
}

export async function registerUser(
  input: RegisterInput,
  fastify: FastifyInstance
): Promise<AuthResult> {
  const { handle, email, password } = input;

  // Check uniqueness
  const existing = await db.query(
    'SELECT id FROM users WHERE email = $1 OR handle = $2',
    [email.toLowerCase(), handle]
  );
  if (existing.rows.length > 0) {
    throw Object.assign(new Error('Handle or email already in use'), { statusCode: 409 });
  }

  // Validate handle format
  if (!/^[a-zA-Z0-9_-]{3,32}$/.test(handle)) {
    throw Object.assign(
      new Error('Handle must be 3–32 characters, letters/numbers/hyphens/underscores only'),
      { statusCode: 400 }
    );
  }

  const passwordHash = await bcrypt.hash(password, BCRYPT_ROUNDS);

  const requireApproval = process.env.BBS_REQUIRE_APPROVAL === 'true';
  const role = requireApproval ? 'new' : 'validated';
  const emailVerified = process.env.SMTP_SKIP_VERIFY === 'true';

  const { rows } = await db.query(
    `INSERT INTO users (handle, email, password_hash, role, email_verified)
     VALUES ($1, $2, $3, $4, $5)
     RETURNING id, handle, email, role, bio, location, post_count, email_verified, created_at, last_seen`,
    [handle, email.toLowerCase(), passwordHash, role, emailVerified]
  );

  const user = dbRowToUser(rows[0]);
  const tokens = await issueTokens(user.id, fastify);

  return { user, ...tokens };
}

export async function loginUser(
  input: LoginInput,
  fastify: FastifyInstance,
  ip?: string
): Promise<AuthResult> {
  const { email, password } = input;

  const { rows } = await db.query(
    `SELECT id, handle, email, password_hash, role, bio, location,
            post_count, email_verified, created_at, last_seen
     FROM users WHERE email = $1`,
    [email.toLowerCase()]
  );

  if (rows.length === 0) {
    throw Object.assign(new Error('Invalid credentials'), { statusCode: 401 });
  }

  const row = rows[0];

  if (row.role === 'banned') {
    throw Object.assign(new Error('This account has been banned'), { statusCode: 403 });
  }

  const valid = await bcrypt.compare(password, row.password_hash);
  if (!valid) {
    throw Object.assign(new Error('Invalid credentials'), { statusCode: 401 });
  }

  // Update last_seen
  await db.query('UPDATE users SET last_seen = NOW() WHERE id = $1', [row.id]);

  const user = dbRowToUser(row);
  const tokens = await issueTokens(user.id, fastify);

  return { user, ...tokens };
}

export async function refreshTokens(
  refreshToken: string,
  fastify: FastifyInstance
): Promise<{ accessToken: string; refreshToken: string }> {
  const tokenHash = hashToken(refreshToken);

  // Check Redis first (fast path)
  const cachedUserId = await redis.get(Keys.refreshToken(tokenHash));
  if (!cachedUserId) {
    throw Object.assign(new Error('Invalid or expired refresh token'), { statusCode: 401 });
  }

  // Verify in DB (also invalidates old token — rotation)
  const { rows } = await db.query(
    `DELETE FROM user_sessions WHERE token_hash = $1 AND expires_at > NOW()
     RETURNING user_id`,
    [tokenHash]
  );

  if (rows.length === 0) {
    await redis.del(Keys.refreshToken(tokenHash));
    throw Object.assign(new Error('Invalid or expired refresh token'), { statusCode: 401 });
  }

  const userId = rows[0].user_id;
  await redis.del(Keys.refreshToken(tokenHash));

  return issueTokens(userId, fastify);
}

export async function revokeRefreshToken(refreshToken: string): Promise<void> {
  const tokenHash = hashToken(refreshToken);
  await db.query('DELETE FROM user_sessions WHERE token_hash = $1', [tokenHash]);
  await redis.del(Keys.refreshToken(tokenHash));
}

async function issueTokens(
  userId: string,
  fastify: FastifyInstance
): Promise<{ accessToken: string; refreshToken: string }> {
  const accessToken = fastify.jwt.sign(
    { sub: userId },
    { expiresIn: ACCESS_TOKEN_TTL }
  );

  const refreshToken = nanoid(64);
  const tokenHash = hashToken(refreshToken);

  const expiresAt = new Date(Date.now() + REFRESH_TOKEN_TTL * 1000);

  await db.query(
    `INSERT INTO user_sessions (user_id, token_hash, expires_at)
     VALUES ($1, $2, $3)`,
    [userId, tokenHash, expiresAt]
  );

  await redis.setex(Keys.refreshToken(tokenHash), REFRESH_TOKEN_TTL, userId);

  return { accessToken, refreshToken };
}

function dbRowToUser(row: Record<string, unknown>): User {
  return {
    id: row.id as string,
    handle: row.handle as string,
    email: row.email as string,
    role: row.role as User['role'],
    bio: (row.bio as string) ?? null,
    location: (row.location as string) ?? null,
    postCount: row.post_count as number,
    createdAt: (row.created_at as Date).toISOString(),
    lastSeen: row.last_seen ? (row.last_seen as Date).toISOString() : null,
  };
}

export async function getUserById(id: string): Promise<User | null> {
  const { rows } = await db.query(
    `SELECT id, handle, email, role, bio, location, post_count, created_at, last_seen
     FROM users WHERE id = $1`,
    [id]
  );
  if (rows.length === 0) return null;
  return dbRowToUser(rows[0]);
}
