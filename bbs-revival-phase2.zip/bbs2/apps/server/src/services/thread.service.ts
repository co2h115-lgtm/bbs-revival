import { db } from '../db/pool.js';
import { hasMinRole } from '@bbs/shared';
import type { UserRole } from '@bbs/shared';

export interface CreateThreadInput {
  boardId: string;
  authorId: string;
  title: string;
  body: string;
}

export interface CreatePostInput {
  threadId: string;
  authorId: string;
  body: string;
  quotePostId?: string;
}

export interface UpdatePostInput {
  postId: string;
  userId: string;
  userRole: UserRole;
  body: string;
}

export interface ThreadListOptions {
  boardId: string;
  page?: number;
  limit?: number;
}

export interface PostListOptions {
  threadId: string;
  page?: number;
  limit?: number;
}

// ─────────────────────────────────────────────────────────
//  Threads
// ─────────────────────────────────────────────────────────

export async function createThread(input: CreateThreadInput) {
  const { boardId, authorId, title, body } = input;

  const { rows: boardRows } = await db.query(
    'SELECT id, min_role FROM boards WHERE id = $1',
    [boardId]
  );
  if (boardRows.length === 0) {
    throw Object.assign(new Error('Board not found'), { statusCode: 404 });
  }

  const { rows: userRows } = await db.query(
    'SELECT role FROM users WHERE id = $1',
    [authorId]
  );
  if (!hasMinRole(userRows[0].role as UserRole, boardRows[0].min_role as UserRole)) {
    throw Object.assign(new Error('Insufficient permissions'), { statusCode: 403 });
  }

  const client = await db.connect();
  try {
    await client.query('BEGIN');

    const { rows: threadRows } = await client.query(
      `INSERT INTO threads (board_id, author_id, title)
       VALUES ($1, $2, $3) RETURNING id`,
      [boardId, authorId, title]
    );
    const threadId = threadRows[0].id as string;

    const { rows: postRows } = await client.query(
      `INSERT INTO posts (thread_id, author_id, body) VALUES ($1, $2, $3) RETURNING id`,
      [threadId, authorId, body]
    );

    await client.query(
      `UPDATE boards SET thread_count = thread_count + 1,
                         post_count = post_count + 1,
                         last_post_at = NOW()
       WHERE id = $1`,
      [boardId]
    );
    await client.query(
      `UPDATE users SET post_count = post_count + 1 WHERE id = $1`,
      [authorId]
    );

    await client.query('COMMIT');
    return { threadId, postId: postRows[0].id as string };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

export async function getThreadList(opts: ThreadListOptions) {
  const { boardId, page = 1, limit = 25 } = opts;
  const offset = (page - 1) * limit;

  const { rows: boardRows } = await db.query(
    'SELECT id, name, description, min_role, group_id FROM boards WHERE id = $1',
    [boardId]
  );
  if (boardRows.length === 0) {
    throw Object.assign(new Error('Board not found'), { statusCode: 404 });
  }

  const { rows: threads } = await db.query(
    `SELECT t.id, t.title, t.reply_count, t.view_count, t.locked, t.pinned,
            t.created_at, t.last_post_at,
            u.id   AS author_id,
            u.handle AS author_handle,
            u.role AS author_role,
            -- last poster info
            lp.handle AS last_poster_handle
     FROM threads t
     JOIN users u ON u.id = t.author_id
     LEFT JOIN LATERAL (
       SELECT u2.handle
       FROM posts p2
       JOIN users u2 ON u2.id = p2.author_id
       WHERE p2.thread_id = t.id AND p2.deleted_at IS NULL
       ORDER BY p2.created_at DESC LIMIT 1
     ) lp ON true
     WHERE t.board_id = $1
     ORDER BY t.pinned DESC, t.last_post_at DESC
     LIMIT $2 OFFSET $3`,
    [boardId, limit, offset]
  );

  const { rows: countRows } = await db.query(
    'SELECT COUNT(*) FROM threads WHERE board_id = $1',
    [boardId]
  );

  return {
    board: boardRows[0],
    threads,
    total: parseInt(countRows[0].count),
    page,
    limit,
  };
}

export async function getThread(threadId: string) {
  const { rows } = await db.query(
    `SELECT t.*, b.id AS board_id, b.name AS board_name,
            bg.name AS group_name,
            u.handle AS author_handle, u.role AS author_role
     FROM threads t
     JOIN boards b ON b.id = t.board_id
     JOIN board_groups bg ON bg.id = b.group_id
     JOIN users u ON u.id = t.author_id
     WHERE t.id = $1`,
    [threadId]
  );
  if (rows.length === 0) {
    throw Object.assign(new Error('Thread not found'), { statusCode: 404 });
  }

  // Increment view count
  await db.query('UPDATE threads SET view_count = view_count + 1 WHERE id = $1', [threadId]);
  return rows[0];
}

export async function updateThread(
  threadId: string,
  userId: string,
  userRole: UserRole,
  updates: { locked?: boolean; pinned?: boolean; title?: string; boardId?: string }
) {
  const isSysop = userRole === 'sysop' || userRole === 'cosysop';

  const { rows } = await db.query(
    'SELECT id, author_id, board_id FROM threads WHERE id = $1',
    [threadId]
  );
  if (rows.length === 0) throw Object.assign(new Error('Thread not found'), { statusCode: 404 });

  if (!isSysop) {
    throw Object.assign(new Error('Insufficient permissions'), { statusCode: 403 });
  }

  const fields: string[] = [];
  const values: unknown[] = [];

  if (updates.locked !== undefined) { fields.push(`locked = $${fields.length + 1}`); values.push(updates.locked); }
  if (updates.pinned !== undefined) { fields.push(`pinned = $${fields.length + 1}`); values.push(updates.pinned); }
  if (updates.title !== undefined)  { fields.push(`title = $${fields.length + 1}`);  values.push(updates.title); }
  if (updates.boardId !== undefined){ fields.push(`board_id = $${fields.length + 1}`); values.push(updates.boardId); }

  if (fields.length === 0) return;

  values.push(threadId);
  await db.query(
    `UPDATE threads SET ${fields.join(', ')} WHERE id = $${values.length}`,
    values
  );

  // Audit log
  await db.query(
    `INSERT INTO audit_log (actor_id, action, target_type, target_id, meta)
     VALUES ($1, 'thread_update', 'thread', $2, $3)`,
    [userId, threadId, JSON.stringify(updates)]
  );
}

export async function deleteThread(threadId: string, userId: string, userRole: UserRole) {
  if (userRole !== 'sysop' && userRole !== 'cosysop') {
    throw Object.assign(new Error('Insufficient permissions'), { statusCode: 403 });
  }

  const { rows } = await db.query(
    'SELECT board_id FROM threads WHERE id = $1',
    [threadId]
  );
  if (rows.length === 0) throw Object.assign(new Error('Thread not found'), { statusCode: 404 });

  const boardId = rows[0].board_id as string;

  const client = await db.connect();
  try {
    await client.query('BEGIN');
    const { rows: postCount } = await client.query(
      'SELECT COUNT(*) FROM posts WHERE thread_id = $1 AND deleted_at IS NULL',
      [threadId]
    );
    await client.query('DELETE FROM threads WHERE id = $1', [threadId]);
    await client.query(
      `UPDATE boards SET thread_count = GREATEST(0, thread_count - 1),
                         post_count   = GREATEST(0, post_count - $1)
       WHERE id = $2`,
      [parseInt(postCount[0].count), boardId]
    );
    await client.query(
      `INSERT INTO audit_log (actor_id, action, target_type, target_id)
       VALUES ($1, 'thread_delete', 'thread', $2)`,
      [userId, threadId]
    );
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

// ─────────────────────────────────────────────────────────
//  Posts
// ─────────────────────────────────────────────────────────

export async function getPostList(opts: PostListOptions) {
  const { threadId, page = 1, limit = 25 } = opts;
  const offset = (page - 1) * limit;

  const { rows: posts } = await db.query(
    `SELECT p.id, p.thread_id, p.body, p.created_at, p.edited_at,
            u.id       AS author_id,
            u.handle   AS author_handle,
            u.role     AS author_role,
            u.post_count AS author_post_count,
            u.created_at AS author_joined,
            u.location AS author_location
     FROM posts p
     JOIN users u ON u.id = p.author_id
     WHERE p.thread_id = $1 AND p.deleted_at IS NULL
     ORDER BY p.created_at ASC
     LIMIT $2 OFFSET $3`,
    [threadId, limit, offset]
  );

  const { rows: countRows } = await db.query(
    'SELECT COUNT(*) FROM posts WHERE thread_id = $1 AND deleted_at IS NULL',
    [threadId]
  );

  return { posts, total: parseInt(countRows[0].count), page, limit };
}

export async function createPost(input: CreatePostInput) {
  const { threadId, authorId, body, quotePostId } = input;

  const { rows: threadRows } = await db.query(
    `SELECT t.id, t.locked, b.min_role, b.id AS board_id
     FROM threads t JOIN boards b ON b.id = t.board_id WHERE t.id = $1`,
    [threadId]
  );
  if (threadRows.length === 0) throw Object.assign(new Error('Thread not found'), { statusCode: 404 });
  if (threadRows[0].locked) throw Object.assign(new Error('Thread is locked'), { statusCode: 403 });

  const { rows: userRows } = await db.query('SELECT role FROM users WHERE id = $1', [authorId]);
  if (!hasMinRole(userRows[0].role as UserRole, threadRows[0].min_role as UserRole)) {
    throw Object.assign(new Error('Insufficient permissions'), { statusCode: 403 });
  }

  // Build body with quote if requested
  let finalBody = body;
  if (quotePostId) {
    const { rows: qRows } = await db.query(
      'SELECT body, author_id FROM posts WHERE id = $1',
      [quotePostId]
    );
    if (qRows.length > 0) {
      const { rows: qUser } = await db.query('SELECT handle FROM users WHERE id = $1', [qRows[0].author_id]);
      const quotedHandle = qUser[0]?.handle ?? 'Unknown';
      const quotedBody = (qRows[0].body as string).split('\n').map((l: string) => `> ${l}`).join('\n');
      finalBody = `${quotedHandle} wrote:\n${quotedBody}\n\n${body}`;
    }
  }

  const client = await db.connect();
  try {
    await client.query('BEGIN');

    const { rows } = await client.query(
      `INSERT INTO posts (thread_id, author_id, body) VALUES ($1, $2, $3) RETURNING id`,
      [threadId, authorId, finalBody]
    );

    await client.query(
      `UPDATE threads SET reply_count = reply_count + 1, last_post_at = NOW() WHERE id = $1`,
      [threadId]
    );
    await client.query(
      `UPDATE boards SET post_count = post_count + 1, last_post_at = NOW() WHERE id = $1`,
      [threadRows[0].board_id]
    );
    await client.query(
      `UPDATE users SET post_count = post_count + 1 WHERE id = $1`,
      [authorId]
    );

    await client.query('COMMIT');
    return { postId: rows[0].id as string };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

export async function updatePost(input: UpdatePostInput) {
  const { postId, userId, userRole, body } = input;

  const { rows } = await db.query(
    'SELECT id, author_id, created_at FROM posts WHERE id = $1 AND deleted_at IS NULL',
    [postId]
  );
  if (rows.length === 0) throw Object.assign(new Error('Post not found'), { statusCode: 404 });

  const isSysop = userRole === 'sysop' || userRole === 'cosysop';
  const isAuthor = rows[0].author_id === userId;

  // Authors can edit within 1 hour; sysops can edit anytime
  if (!isSysop) {
    if (!isAuthor) throw Object.assign(new Error('Cannot edit another user\'s post'), { statusCode: 403 });
    const age = Date.now() - new Date(rows[0].created_at as string).getTime();
    if (age > 60 * 60 * 1000) {
      throw Object.assign(new Error('Posts can only be edited within 1 hour'), { statusCode: 403 });
    }
  }

  await db.query(
    `UPDATE posts SET body = $1, edited_at = NOW() WHERE id = $2`,
    [body, postId]
  );
}

export async function deletePost(postId: string, userId: string, userRole: UserRole) {
  const { rows } = await db.query(
    `SELECT p.id, p.author_id, p.thread_id, t.board_id
     FROM posts p JOIN threads t ON t.id = p.thread_id
     WHERE p.id = $1 AND p.deleted_at IS NULL`,
    [postId]
  );
  if (rows.length === 0) throw Object.assign(new Error('Post not found'), { statusCode: 404 });

  const isSysop = userRole === 'sysop' || userRole === 'cosysop';
  const isAuthor = rows[0].author_id === userId;

  if (!isSysop && !isAuthor) {
    throw Object.assign(new Error('Cannot delete another user\'s post'), { statusCode: 403 });
  }

  await db.query('UPDATE posts SET deleted_at = NOW() WHERE id = $1', [postId]);
  await db.query(
    `UPDATE threads SET reply_count = GREATEST(0, reply_count - 1) WHERE id = $1`,
    [rows[0].thread_id]
  );
  await db.query(
    `UPDATE boards SET post_count = GREATEST(0, post_count - 1) WHERE id = $1`,
    [rows[0].board_id]
  );

  if (isSysop) {
    await db.query(
      `INSERT INTO audit_log (actor_id, action, target_type, target_id)
       VALUES ($1, 'post_delete', 'post', $2)`,
      [userId, postId]
    );
  }
}
