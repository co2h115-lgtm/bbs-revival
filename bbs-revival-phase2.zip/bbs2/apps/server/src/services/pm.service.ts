import { db } from '../db/pool.js';

export async function sendPrivateMessage(
  fromId: string,
  toHandle: string,
  subject: string,
  body: string
) {
  const { rows: toRows } = await db.query(
    'SELECT id, role FROM users WHERE handle ILIKE $1',
    [toHandle]
  );
  if (toRows.length === 0) throw Object.assign(new Error('User not found'), { statusCode: 404 });
  if (toRows[0].role === 'banned') throw Object.assign(new Error('Cannot message this user'), { statusCode: 403 });
  if (toRows[0].id === fromId) throw Object.assign(new Error('Cannot message yourself'), { statusCode: 400 });

  const { rows } = await db.query(
    `INSERT INTO private_messages (from_id, to_id, subject, body)
     VALUES ($1, $2, $3, $4) RETURNING id`,
    [fromId, toRows[0].id, subject, body]
  );
  return { messageId: rows[0].id as string };
}

export async function getInbox(userId: string, page = 1, limit = 25) {
  const offset = (page - 1) * limit;
  const { rows } = await db.query(
    `SELECT pm.id, pm.subject, pm.created_at, pm.read_at,
            u.handle AS from_handle, u.id AS from_id
     FROM private_messages pm
     JOIN users u ON u.id = pm.from_id
     WHERE pm.to_id = $1
     ORDER BY pm.created_at DESC
     LIMIT $2 OFFSET $3`,
    [userId, limit, offset]
  );
  const { rows: countRows } = await db.query(
    'SELECT COUNT(*) FROM private_messages WHERE to_id = $1',
    [userId]
  );
  const { rows: unreadRows } = await db.query(
    'SELECT COUNT(*) FROM private_messages WHERE to_id = $1 AND read_at IS NULL',
    [userId]
  );
  return {
    messages: rows,
    total: parseInt(countRows[0].count),
    unread: parseInt(unreadRows[0].count),
    page,
    limit,
  };
}

export async function getSentMessages(userId: string, page = 1, limit = 25) {
  const offset = (page - 1) * limit;
  const { rows } = await db.query(
    `SELECT pm.id, pm.subject, pm.created_at, pm.read_at,
            u.handle AS to_handle, u.id AS to_id
     FROM private_messages pm
     JOIN users u ON u.id = pm.to_id
     WHERE pm.from_id = $1
     ORDER BY pm.created_at DESC
     LIMIT $2 OFFSET $3`,
    [userId, limit, offset]
  );
  return { messages: rows, page, limit };
}

export async function getMessage(messageId: string, userId: string) {
  const { rows } = await db.query(
    `SELECT pm.*, 
            fu.handle AS from_handle,
            tu.handle AS to_handle
     FROM private_messages pm
     JOIN users fu ON fu.id = pm.from_id
     JOIN users tu ON tu.id = pm.to_id
     WHERE pm.id = $1 AND (pm.to_id = $2 OR pm.from_id = $2)`,
    [messageId, userId]
  );
  if (rows.length === 0) throw Object.assign(new Error('Message not found'), { statusCode: 404 });

  // Mark as read
  if (rows[0].to_id === userId && !rows[0].read_at) {
    await db.query('UPDATE private_messages SET read_at = NOW() WHERE id = $1', [messageId]);
  }

  return rows[0];
}

export async function deleteMessage(messageId: string, userId: string) {
  const { rows } = await db.query(
    'SELECT id FROM private_messages WHERE id = $1 AND (to_id = $2 OR from_id = $2)',
    [messageId, userId]
  );
  if (rows.length === 0) throw Object.assign(new Error('Message not found'), { statusCode: 404 });
  await db.query('DELETE FROM private_messages WHERE id = $1', [messageId]);
}

export async function getUnreadCount(userId: string): Promise<number> {
  const { rows } = await db.query(
    'SELECT COUNT(*) FROM private_messages WHERE to_id = $1 AND read_at IS NULL',
    [userId]
  );
  return parseInt(rows[0].count);
}
