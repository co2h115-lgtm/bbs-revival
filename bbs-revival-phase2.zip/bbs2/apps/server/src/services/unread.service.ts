import { db } from '../db/pool.js';
import { redis } from '../db/redis.js';

// Cache unread counts in Redis for performance
const UNREAD_CACHE_TTL = 300; // 5 minutes

export async function markThreadRead(userId: string, threadId: string) {
  await db.query(
    `INSERT INTO thread_reads (user_id, thread_id, read_at)
     VALUES ($1, $2, NOW())
     ON CONFLICT (user_id, thread_id) DO UPDATE SET read_at = NOW()`,
    [userId, threadId]
  );
  await redis.del(`unread:${userId}`);
}

export async function getUnreadThreadIds(userId: string, boardId?: string): Promise<string[]> {
  const boardFilter = boardId ? 'AND t.board_id = $2' : '';
  const params: unknown[] = [userId];
  if (boardId) params.push(boardId);

  const { rows } = await db.query(
    `SELECT t.id
     FROM threads t
     LEFT JOIN thread_reads tr ON tr.thread_id = t.id AND tr.user_id = $1
     WHERE (tr.read_at IS NULL OR tr.read_at < t.last_post_at)
           ${boardFilter}
     ORDER BY t.last_post_at DESC`,
    params
  );
  return rows.map((r) => r.id as string);
}

export async function getBoardUnreadCounts(
  userId: string,
  boardIds: string[]
): Promise<Record<string, number>> {
  if (boardIds.length === 0) return {};

  const placeholders = boardIds.map((_, i) => `$${i + 2}`).join(',');
  const { rows } = await db.query(
    `SELECT t.board_id, COUNT(*) AS unread_count
     FROM threads t
     LEFT JOIN thread_reads tr ON tr.thread_id = t.id AND tr.user_id = $1
     WHERE t.board_id IN (${placeholders})
       AND (tr.read_at IS NULL OR tr.read_at < t.last_post_at)
     GROUP BY t.board_id`,
    [userId, ...boardIds]
  );

  const result: Record<string, number> = {};
  for (const row of rows) {
    result[row.board_id as string] = parseInt(row.unread_count);
  }
  return result;
}
