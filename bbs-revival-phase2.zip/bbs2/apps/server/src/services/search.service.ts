import { db } from '../db/pool.js';

export interface SearchOptions {
  query: string;
  type?: 'threads' | 'posts' | 'all';
  boardId?: string;
  page?: number;
  limit?: number;
}

export async function search(opts: SearchOptions) {
  const { query, type = 'all', boardId, page = 1, limit = 20 } = opts;
  const offset = (page - 1) * limit;

  if (!query || query.trim().length < 2) {
    throw Object.assign(new Error('Search query must be at least 2 characters'), { statusCode: 400 });
  }

  const results: { threads: unknown[]; posts: unknown[]; total: number } = {
    threads: [],
    posts: [],
    total: 0,
  };

  if (type === 'threads' || type === 'all') {
    const boardFilter = boardId ? 'AND t.board_id = $3' : '';
    const params: unknown[] = [query, limit];
    if (boardId) params.push(boardId);

    const { rows: threads } = await db.query(
      `SELECT t.id, t.title, t.reply_count, t.created_at, t.last_post_at,
              b.name AS board_name, b.id AS board_id,
              u.handle AS author_handle,
              ts_rank(to_tsvector('english', t.title), plainto_tsquery('english', $1)) AS rank
       FROM threads t
       JOIN boards b ON b.id = t.board_id
       JOIN users u ON u.id = t.author_id
       WHERE to_tsvector('english', t.title) @@ plainto_tsquery('english', $1)
             ${boardFilter}
       ORDER BY rank DESC, t.last_post_at DESC
       LIMIT $2 OFFSET ${offset}`,
      params
    );
    results.threads = threads;
  }

  if (type === 'posts' || type === 'all') {
    const boardFilter = boardId ? 'AND b.id = $3' : '';
    const params: unknown[] = [query, limit];
    if (boardId) params.push(boardId);

    const { rows: posts } = await db.query(
      `SELECT p.id, p.body, p.created_at,
              t.id AS thread_id, t.title AS thread_title,
              b.name AS board_name, b.id AS board_id,
              u.handle AS author_handle,
              ts_rank(to_tsvector('english', p.body), plainto_tsquery('english', $1)) AS rank
       FROM posts p
       JOIN threads t ON t.id = p.thread_id
       JOIN boards b ON b.id = t.board_id
       JOIN users u ON u.id = p.author_id
       WHERE p.deleted_at IS NULL
             AND to_tsvector('english', p.body) @@ plainto_tsquery('english', $1)
             ${boardFilter}
       ORDER BY rank DESC, p.created_at DESC
       LIMIT $2 OFFSET ${offset}`,
      params
    );
    results.posts = posts;
  }

  results.total = results.threads.length + results.posts.length;
  return results;
}
