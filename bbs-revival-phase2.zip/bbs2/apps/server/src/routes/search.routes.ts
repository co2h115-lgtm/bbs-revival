import type { FastifyInstance } from 'fastify';
import { search } from '../services/search.service.js';

export async function searchRoutes(fastify: FastifyInstance) {
  // GET /api/search?q=...&type=all|threads|posts&boardId=...&page=1
  fastify.get('/', async (request, reply) => {
    const q = request.query as {
      q?: string;
      type?: 'threads' | 'posts' | 'all';
      boardId?: string;
      page?: string;
    };

    if (!q.q) return reply.code(400).send({ ok: false, error: 'q parameter is required' });

    try {
      const results = await search({
        query: q.q,
        type: q.type ?? 'all',
        boardId: q.boardId,
        page: parseInt(q.page ?? '1'),
      });
      return reply.send({ ok: true, data: results });
    } catch (err: unknown) {
      const e = err as Error & { statusCode?: number };
      return reply.code(e.statusCode ?? 500).send({ ok: false, error: e.message });
    }
  });
}
