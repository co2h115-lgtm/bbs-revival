import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import {
  sendPrivateMessage, getInbox, getSentMessages,
  getMessage, deleteMessage, getUnreadCount,
} from '../services/pm.service.js';
import type { UserRole } from '@bbs/shared';

const sendSchema = z.object({
  toHandle: z.string().min(1).max(32),
  subject: z.string().min(1).max(255).trim(),
  body: z.string().min(1).max(10_000),
});

function getUser(request: { user?: unknown }): { sub: string; role: UserRole } {
  return request.user as { sub: string; role: UserRole };
}

export async function pmRoutes(fastify: FastifyInstance) {
  // GET /api/messages  — inbox
  fastify.get('/', { preHandler: [fastify.authenticate] }, async (request, reply) => {
    const { sub } = getUser(request);
    const q = request.query as { page?: string; box?: string };
    const page = parseInt(q.page ?? '1');

    if (q.box === 'sent') {
      const data = await getSentMessages(sub, page);
      return reply.send({ ok: true, data });
    }

    const data = await getInbox(sub, page);
    return reply.send({ ok: true, data });
  });

  // GET /api/messages/unread
  fastify.get('/unread', { preHandler: [fastify.authenticate] }, async (request, reply) => {
    const { sub } = getUser(request);
    const count = await getUnreadCount(sub);
    return reply.send({ ok: true, data: { count } });
  });

  // POST /api/messages
  fastify.post('/', { preHandler: [fastify.authenticate] }, async (request, reply) => {
    const { sub } = getUser(request);
    const body = sendSchema.safeParse(request.body);
    if (!body.success) return reply.code(400).send({ ok: false, error: body.error.issues[0].message });

    try {
      const result = await sendPrivateMessage(sub, body.data.toHandle, body.data.subject, body.data.body);
      return reply.code(201).send({ ok: true, data: result });
    } catch (err: unknown) {
      const e = err as Error & { statusCode?: number };
      return reply.code(e.statusCode ?? 500).send({ ok: false, error: e.message });
    }
  });

  // GET /api/messages/:id
  fastify.get('/:id', { preHandler: [fastify.authenticate] }, async (request, reply) => {
    const { sub } = getUser(request);
    const { id } = request.params as { id: string };
    try {
      const msg = await getMessage(id, sub);
      return reply.send({ ok: true, data: msg });
    } catch (err: unknown) {
      const e = err as Error & { statusCode?: number };
      return reply.code(e.statusCode ?? 500).send({ ok: false, error: e.message });
    }
  });

  // DELETE /api/messages/:id
  fastify.delete('/:id', { preHandler: [fastify.authenticate] }, async (request, reply) => {
    const { sub } = getUser(request);
    const { id } = request.params as { id: string };
    try {
      await deleteMessage(id, sub);
      return reply.send({ ok: true, data: null });
    } catch (err: unknown) {
      const e = err as Error & { statusCode?: number };
      return reply.code(e.statusCode ?? 500).send({ ok: false, error: e.message });
    }
  });
}
