import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import {
  createThread, getThreadList, getThread,
  updateThread, deleteThread,
  getPostList, createPost, updatePost, deletePost,
} from '../services/thread.service.js';
import { markThreadRead, getUnreadThreadIds, getBoardUnreadCounts } from '../services/unread.service.js';
import type { UserRole } from '@bbs/shared';

const createThreadSchema = z.object({
  title: z.string().min(1).max(255).trim(),
  body: z.string().min(1).max(50_000),
});

const createPostSchema = z.object({
  body: z.string().min(1).max(50_000),
  quotePostId: z.string().uuid().optional(),
});

const updatePostSchema = z.object({
  body: z.string().min(1).max(50_000),
});

const updateThreadSchema = z.object({
  locked: z.boolean().optional(),
  pinned: z.boolean().optional(),
  title: z.string().min(1).max(255).optional(),
  boardId: z.string().uuid().optional(),
});

function getUser(request: { user?: unknown }): { sub: string; role: UserRole } {
  return request.user as { sub: string; role: UserRole };
}

export async function threadRoutes(fastify: FastifyInstance) {
  // ── Board thread listing ─────────────────────────────────

  // GET /api/boards/:boardId/threads
  fastify.get('/:boardId/threads', async (request, reply) => {
    const { boardId } = request.params as { boardId: string };
    const q = request.query as { page?: string; limit?: string };

    try {
      const data = await getThreadList({
        boardId,
        page: parseInt(q.page ?? '1'),
        limit: parseInt(q.limit ?? '25'),
      });

      // Attach unread counts if authenticated
      const authHeader = request.headers.authorization;
      if (authHeader) {
        try {
          await request.jwtVerify();
          const { sub } = getUser(request);
          const threadIds = data.threads.map((t: { id: string }) => t.id);
          const unreadIds = new Set(await getUnreadThreadIds(sub, boardId));
          data.threads = data.threads.map((t: { id: string }) => ({
            ...t,
            hasUnread: unreadIds.has(t.id),
          }));
        } catch { /* not authenticated — skip unread */ }
      }

      return reply.send({ ok: true, data });
    } catch (err: unknown) {
      const e = err as Error & { statusCode?: number };
      return reply.code(e.statusCode ?? 500).send({ ok: false, error: e.message });
    }
  });

  // POST /api/boards/:boardId/threads
  fastify.post('/:boardId/threads', { preHandler: [fastify.authenticate] }, async (request, reply) => {
    const { sub } = getUser(request);
    const { boardId } = request.params as { boardId: string };
    const body = createThreadSchema.safeParse(request.body);
    if (!body.success) return reply.code(400).send({ ok: false, error: body.error.issues[0].message });

    try {
      const result = await createThread({ boardId, authorId: sub, ...body.data });
      return reply.code(201).send({ ok: true, data: result });
    } catch (err: unknown) {
      const e = err as Error & { statusCode?: number };
      return reply.code(e.statusCode ?? 500).send({ ok: false, error: e.message });
    }
  });

  // GET /api/boards/unread  (unread counts per board)
  fastify.get('/unread', { preHandler: [fastify.authenticate] }, async (request, reply) => {
    const { sub } = getUser(request);
    const q = request.query as { boardIds?: string };
    const boardIds = q.boardIds ? q.boardIds.split(',') : [];
    const counts = await getBoardUnreadCounts(sub, boardIds);
    return reply.send({ ok: true, data: counts });
  });

  // ── Thread CRUD ──────────────────────────────────────────

  // GET /api/boards/threads/:threadId
  fastify.get('/threads/:threadId', async (request, reply) => {
    const { threadId } = request.params as { threadId: string };
    try {
      const thread = await getThread(threadId);
      return reply.send({ ok: true, data: thread });
    } catch (err: unknown) {
      const e = err as Error & { statusCode?: number };
      return reply.code(e.statusCode ?? 500).send({ ok: false, error: e.message });
    }
  });

  // PATCH /api/boards/threads/:threadId  (sysop: lock, pin, move, rename)
  fastify.patch('/threads/:threadId', { preHandler: [fastify.authenticate] }, async (request, reply) => {
    const { sub, role } = getUser(request);
    const { threadId } = request.params as { threadId: string };
    const body = updateThreadSchema.safeParse(request.body);
    if (!body.success) return reply.code(400).send({ ok: false, error: body.error.issues[0].message });

    try {
      await updateThread(threadId, sub, role, body.data);
      return reply.send({ ok: true, data: null });
    } catch (err: unknown) {
      const e = err as Error & { statusCode?: number };
      return reply.code(e.statusCode ?? 500).send({ ok: false, error: e.message });
    }
  });

  // DELETE /api/boards/threads/:threadId  (sysop only)
  fastify.delete('/threads/:threadId', { preHandler: [fastify.authenticate] }, async (request, reply) => {
    const { sub, role } = getUser(request);
    const { threadId } = request.params as { threadId: string };
    try {
      await deleteThread(threadId, sub, role);
      return reply.send({ ok: true, data: null });
    } catch (err: unknown) {
      const e = err as Error & { statusCode?: number };
      return reply.code(e.statusCode ?? 500).send({ ok: false, error: e.message });
    }
  });

  // ── Posts ────────────────────────────────────────────────

  // GET /api/boards/threads/:threadId/posts
  fastify.get('/threads/:threadId/posts', async (request, reply) => {
    const { threadId } = request.params as { threadId: string };
    const q = request.query as { page?: string };
    try {
      const data = await getPostList({ threadId, page: parseInt(q.page ?? '1') });

      // Mark as read if authenticated
      const authHeader = request.headers.authorization;
      if (authHeader) {
        try {
          await request.jwtVerify();
          const { sub } = getUser(request);
          await markThreadRead(sub, threadId);
        } catch { /* skip */ }
      }

      return reply.send({ ok: true, data });
    } catch (err: unknown) {
      const e = err as Error & { statusCode?: number };
      return reply.code(e.statusCode ?? 500).send({ ok: false, error: e.message });
    }
  });

  // POST /api/boards/threads/:threadId/posts
  fastify.post('/threads/:threadId/posts', { preHandler: [fastify.authenticate] }, async (request, reply) => {
    const { sub } = getUser(request);
    const { threadId } = request.params as { threadId: string };
    const body = createPostSchema.safeParse(request.body);
    if (!body.success) return reply.code(400).send({ ok: false, error: body.error.issues[0].message });

    try {
      const result = await createPost({ threadId, authorId: sub, ...body.data });

      // Notify subscribers via socket (fire and forget)
      const io = fastify.io;
      if (io) {
        io.to(`board:${threadId}`).emit('board:new_post', {
          boardId: '',
          threadId,
          postId: result.postId,
        });
      }

      return reply.code(201).send({ ok: true, data: result });
    } catch (err: unknown) {
      const e = err as Error & { statusCode?: number };
      return reply.code(e.statusCode ?? 500).send({ ok: false, error: e.message });
    }
  });

  // PATCH /api/boards/posts/:postId
  fastify.patch('/posts/:postId', { preHandler: [fastify.authenticate] }, async (request, reply) => {
    const { sub, role } = getUser(request);
    const { postId } = request.params as { postId: string };
    const body = updatePostSchema.safeParse(request.body);
    if (!body.success) return reply.code(400).send({ ok: false, error: body.error.issues[0].message });

    try {
      await updatePost({ postId, userId: sub, userRole: role, body: body.data.body });
      return reply.send({ ok: true, data: null });
    } catch (err: unknown) {
      const e = err as Error & { statusCode?: number };
      return reply.code(e.statusCode ?? 500).send({ ok: false, error: e.message });
    }
  });

  // DELETE /api/boards/posts/:postId
  fastify.delete('/posts/:postId', { preHandler: [fastify.authenticate] }, async (request, reply) => {
    const { sub, role } = getUser(request);
    const { postId } = request.params as { postId: string };
    try {
      await deletePost(postId, sub, role);
      return reply.send({ ok: true, data: null });
    } catch (err: unknown) {
      const e = err as Error & { statusCode?: number };
      return reply.code(e.statusCode ?? 500).send({ ok: false, error: e.message });
    }
  });
}

// Extend Fastify types for socket.io reference
declare module 'fastify' {
  interface FastifyInstance {
    io?: import('socket.io').Server;
  }
}
