import { useEffect, useState } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuthStore, apiFetch } from '../stores/auth.store';
import { ROLE_DISPLAY } from '@bbs/shared';
import styles from './Shell.module.css';

export function Shell() {
  const { user, logout, accessToken } = useAuthStore();
  const navigate = useNavigate();
  const [unreadPm, setUnreadPm] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');

  // Load current user on mount
  useEffect(() => {
    if (!accessToken) { navigate('/auth'); return; }
    if (!user) {
      fetch('/api/auth/me', {
        headers: { Authorization: `Bearer ${accessToken}` },
      })
        .then((r) => r.json())
        .then((d) => {
          if (d.ok) useAuthStore.getState().setUser(d.data.user);
          else navigate('/auth');
        })
        .catch(() => navigate('/auth'));
    }
  }, [accessToken, user, navigate]);

  // Poll unread PM count
  useEffect(() => {
    if (!user) return;
    const check = async () => {
      const res = await apiFetch('/api/messages/unread').catch(() => null);
      if (res?.ok) {
        const d = await res.json();
        if (d.ok) setUnreadPm(d.data.count);
      }
    };
    check();
    const interval = setInterval(check, 60_000);
    return () => clearInterval(interval);
  }, [user]);

  const handleLogout = async () => {
    await logout();
    navigate('/auth');
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
    setSearchQuery('');
  };

  return (
    <div className={styles.shell}>
      {/* ── Sidebar ─────────────────────────── */}
      <aside className={styles.sidebar}>
        <div className={styles.sidebarTop}>
          <div className={styles.bbsName}>
            <span className={styles.bbsNameBracket}>[</span>BBS<span className={styles.bbsNameBracket}>]</span>
          </div>
          <div className={styles.bbsSubtitle}>REVIVAL</div>
        </div>

        {user && (
          <div className={styles.userPanel}>
            <div className={styles.userHandle}>{user.handle}</div>
            <div className={styles.userRole}>{ROLE_DISPLAY[user.role]}</div>
          </div>
        )}

        {/* Search */}
        <form className={styles.searchForm} onSubmit={handleSearch}>
          <input
            className={styles.searchInput}
            type="text"
            placeholder="Search..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </form>

        <nav className={styles.nav}>
          <div className={styles.navSection}>MAIN</div>
          <NavLink to="/boards" className={({ isActive }) => isActive ? styles.navItemActive : styles.navItem}>
            ◆ Message Boards
          </NavLink>
          <NavLink to="/chat" className={({ isActive }) => isActive ? styles.navItemActive : styles.navItem}>
            ◆ Chat Rooms
          </NavLink>
          <NavLink to="/files" className={({ isActive }) => isActive ? styles.navItemActive : styles.navItem}>
            ◆ File Areas
          </NavLink>
          <NavLink to="/doors" className={({ isActive }) => isActive ? styles.navItemActive : styles.navItem}>
            ◆ Door Games
          </NavLink>
          <NavLink to="/gallery" className={({ isActive }) => isActive ? styles.navItemActive : styles.navItem}>
            ◆ ANSI Gallery
          </NavLink>

          <div className={styles.navSection}>ACCOUNT</div>
          <NavLink to="/profile" className={({ isActive }) => isActive ? styles.navItemActive : styles.navItem}>
            ◆ My Profile
          </NavLink>
          <NavLink to="/messages" className={({ isActive }) => isActive ? styles.navItemActive : styles.navItem}>
            ◆ Private Mail
            {unreadPm > 0 && <span className={styles.pmBadge}>{unreadPm}</span>}
          </NavLink>
          <NavLink to="/search" className={({ isActive }) => isActive ? styles.navItemActive : styles.navItem}>
            ◆ Search
          </NavLink>

          {user && (user.role === 'sysop' || user.role === 'cosysop') && (
            <>
              <div className={styles.navSection}>SYSOP</div>
              <NavLink to="/admin" className={({ isActive }) => isActive ? styles.navItemActive : styles.navItem}>
                ◆ Admin Panel
              </NavLink>
            </>
          )}
        </nav>

        <div className={styles.sidebarBottom}>
          <button className={styles.logoutBtn} onClick={handleLogout}>[ LOGOFF ]</button>
          <div className={styles.statusLine}>
            <span className={styles.onlineDot} />
            <span>CONNECTED</span>
          </div>
        </div>
      </aside>

      {/* ── Main Content ─────────────────────── */}
      <main className={styles.main}>
        <Outlet />
      </main>
    </div>
  );
}
