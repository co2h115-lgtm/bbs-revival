import { useEffect, useState, useCallback, useRef } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { apiFetch, useAuthStore } from '../stores/auth.store';
import styles from './ThreadPage.module.css';
import { ROLE_DISPLAY } from '@bbs/shared';
import type { UserRole } from '@bbs/shared';

interface Post {
  id: string;
  body: string;
  created_at: string;
  edited_at: string | null;
  author_id: string;
  author_handle: string;
  author_role: UserRole;
  author_post_count: number;
  author_joined: string;
  author_location: string | null;
}

interface Thread {
  id: string;
  title: string;
  board_id: string;
  board_name: string;
  group_name: string;
  locked: boolean;
  pinned: boolean;
  reply_count: number;
  author_handle: string;
  created_at: string;
}

export function ThreadPage() {
  const { threadId } = useParams<{ threadId: string }>();
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [thread, setThread] = useState<Thread | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [replyBody, setReplyBody] = useState('');
  const [quotePostId, setQuotePostId] = useState<string | undefined>();
  const [quotePreview, setQuotePreview] = useState('');
  const [posting, setPosting] = useState(false);
  const [editingPost, setEditingPost] = useState<string | null>(null);
  const [editBody, setEditBody] = useState('');
  const [error, setError] = useState('');
  const replyRef = useRef<HTMLTextAreaElement>(null);
  const limit = 25;

  const isSysop = user?.role === 'sysop' || user?.role === 'cosysop';

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [threadRes, postsRes] = await Promise.all([
        apiFetch(`/api/boards/threads/${threadId}`),
        apiFetch(`/api/boards/threads/${threadId}/posts?page=${page}`),
      ]);
      const td = await threadRes.json();
      const pd = await postsRes.json();
      if (td.ok) setThread(td.data);
      if (pd.ok) {
        setPosts(pd.data.posts);
        setTotal(pd.data.total);
      }
    } finally {
      setLoading(false);
    }
  }, [threadId, page]);

  useEffect(() => { load(); }, [load]);

  const handleQuote = (post: Post) => {
    setQuotePostId(post.id);
    setQuotePreview(`${post.author_handle} wrote:\n${post.body.substring(0, 100)}${post.body.length > 100 ? '...' : ''}`);
    replyRef.current?.focus();
    replyRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const clearQuote = () => {
    setQuotePostId(undefined);
    setQuotePreview('');
  };

  const submitReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyBody.trim()) return;
    setPosting(true);
    setError('');
    try {
      const res = await apiFetch(`/api/boards/threads/${threadId}/posts`, {
        method: 'POST',
        body: JSON.stringify({ body: replyBody.trim(), quotePostId }),
      });
      const d = await res.json();
      if (!d.ok) { setError(d.error); return; }
      setReplyBody('');
      clearQuote();
      // Go to last page to see the new post
      const newTotal = total + 1;
      const newLastPage = Math.ceil(newTotal / limit);
      if (page === newLastPage) {
        load();
      } else {
        setPage(newLastPage);
      }
    } finally {
      setPosting(false);
    }
  };

  const startEdit = (post: Post) => {
    setEditingPost(post.id);
    setEditBody(post.body);
  };

  const submitEdit = async (postId: string) => {
    const res = await apiFetch(`/api/boards/posts/${postId}`, {
      method: 'PATCH',
      body: JSON.stringify({ body: editBody }),
    });
    const d = await res.json();
    if (!d.ok) { setError(d.error); return; }
    setEditingPost(null);
    load();
  };

  const handleDelete = async (postId: string) => {
    if (!confirm('Delete this post?')) return;
    await apiFetch(`/api/boards/posts/${postId}`, { method: 'DELETE' });
    load();
  };

  const toggleLock = async () => {
    await apiFetch(`/api/boards/threads/${threadId}`, {
      method: 'PATCH',
      body: JSON.stringify({ locked: !thread?.locked }),
    });
    load();
  };

  const togglePin = async () => {
    await apiFetch(`/api/boards/threads/${threadId}`, {
      method: 'PATCH',
      body: JSON.stringify({ pinned: !thread?.pinned }),
    });
    load();
  };

  const handleDeleteThread = async () => {
    if (!confirm('Delete this entire thread? This cannot be undone.')) return;
    await apiFetch(`/api/boards/threads/${threadId}`, { method: 'DELETE' });
    navigate(`/boards/${thread?.board_id}`);
  };

  if (loading) return <div className={styles.loading}>Loading thread...</div>;
  if (!thread) return <div className={styles.loading}>Thread not found.</div>;

  const totalPages = Math.ceil(total / limit);

  return (
    <div className={styles.page}>
      {/* Breadcrumb */}
      <div className={styles.breadcrumb}>
        <Link to="/boards" className={styles.crumb}>Boards</Link>
        <span className={styles.sep}> › </span>
        <Link to={`/boards/${thread.board_id}`} className={styles.crumb}>{thread.board_name}</Link>
        <span className={styles.sep}> › </span>
        <span className={styles.crumbCurrent}>{thread.title}</span>
      </div>

      {/* Thread header */}
      <div className={styles.threadHeader}>
        <div>
          <h1 className={styles.title}>
            {thread.pinned && '📌 '}
            {thread.locked && '🔒 '}
            {thread.title}
          </h1>
          <div className={styles.meta}>
            Posted by <span className={styles.handle}>{thread.author_handle}</span>
            {' · '}{new Date(thread.created_at).toLocaleDateString()}
            {' · '}{total} {total === 1 ? 'post' : 'posts'}
          </div>
        </div>

        {/* Sysop controls */}
        {isSysop && (
          <div className={styles.sysopControls}>
            <span className={styles.sysopLabel}>SYSOP:</span>
            <button className={styles.sysopBtn} onClick={togglePin}>
              {thread.pinned ? 'Unpin' : 'Pin'}
            </button>
            <button className={styles.sysopBtn} onClick={toggleLock}>
              {thread.locked ? 'Unlock' : 'Lock'}
            </button>
            <button className={`${styles.sysopBtn} ${styles.danger}`} onClick={handleDeleteThread}>
              Delete
            </button>
          </div>
        )}
      </div>

      <div className={styles.divider}>{'═'.repeat(80)}</div>

      {/* Posts */}
      {posts.map((post, idx) => {
        const postNum = (page - 1) * limit + idx + 1;
        const canEdit = user && (user.id === post.author_id || isSysop);
        const isEditing = editingPost === post.id;

        return (
          <div key={post.id} className={styles.post}>
            {/* Author sidebar */}
            <div className={styles.postAuthor}>
              <div className={styles.authorHandle}>{post.author_handle}</div>
              <div className={styles.authorRole}>{ROLE_DISPLAY[post.author_role]}</div>
              {post.author_location && (
                <div className={styles.authorMeta}>{post.author_location}</div>
              )}
              <div className={styles.authorMeta}>Posts: {post.author_post_count}</div>
              <div className={styles.authorMeta}>
                Joined: {new Date(post.author_joined).toLocaleDateString()}
              </div>
            </div>

            {/* Post content */}
            <div className={styles.postContent}>
              <div className={styles.postMeta}>
                <span className={styles.postNum}>#{postNum}</span>
                <span className={styles.postDate}>
                  {new Date(post.created_at).toLocaleString()}
                  {post.edited_at && (
                    <span className={styles.edited}> (edited)</span>
                  )}
                </span>
                {canEdit && !isEditing && (
                  <div className={styles.postActions}>
                    <button className={styles.actionBtn} onClick={() => handleQuote(post)}>Quote</button>
                    <button className={styles.actionBtn} onClick={() => startEdit(post)}>Edit</button>
                    <button className={`${styles.actionBtn} ${styles.danger}`} onClick={() => handleDelete(post.id)}>Del</button>
                  </div>
                )}
              </div>

              {isEditing ? (
                <div className={styles.editForm}>
                  <textarea
                    className={styles.editTextarea}
                    value={editBody}
                    onChange={(e) => setEditBody(e.target.value)}
                    rows={8}
                  />
                  <div className={styles.editActions}>
                    <button className="btn-primary" onClick={() => submitEdit(post.id)}>[ Save ]</button>
                    <button onClick={() => setEditingPost(null)}>[ Cancel ]</button>
                  </div>
                </div>
              ) : (
                <pre className={styles.postBody}>{post.body}</pre>
              )}
            </div>
          </div>
        );
      })}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className={styles.pagination}>
          <button onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1}>[ ◀ PREV ]</button>
          <span className={styles.pageInfo}>Page {page} of {totalPages}</span>
          <button onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page === totalPages}>[ NEXT ▶ ]</button>
        </div>
      )}

      {/* Reply form */}
      {user && !thread.locked && (
        <div className={styles.replySection}>
          <div className={styles.replyHeader}>REPLY TO THREAD</div>
          <div className={styles.divider}>{'─'.repeat(60)}</div>

          {quotePostId && (
            <div className={styles.quotePreview}>
              <pre className={styles.quoteText}>{quotePreview}</pre>
              <button className={styles.clearQuote} onClick={clearQuote}>× Clear quote</button>
            </div>
          )}

          <form onSubmit={submitReply}>
            <textarea
              ref={replyRef}
              className={styles.replyTextarea}
              value={replyBody}
              onChange={(e) => setReplyBody(e.target.value)}
              placeholder="Write your reply..."
              rows={8}
              required
            />
            {error && <div className={styles.error}>❌ {error}</div>}
            <div className={styles.replyActions}>
              <button type="submit" className="btn-primary" disabled={posting}>
                {posting ? '[ POSTING... ]' : '[ POST REPLY ]'}
              </button>
            </div>
          </form>
        </div>
      )}

      {thread.locked && (
        <div className={styles.lockedBanner}>
          🔒 This thread is locked. No new replies can be posted.
        </div>
      )}

      {!user && (
        <div className={styles.loginBanner}>
          <Link to="/auth">Log in</Link> to reply to this thread.
        </div>
      )}
    </div>
  );
}
