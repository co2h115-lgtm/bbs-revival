import { useEffect, useState, useCallback } from 'react';
import { apiFetch } from '../stores/auth.store';
import styles from './MessagesPage.module.css';

interface Message {
  id: string;
  subject: string;
  created_at: string;
  read_at: string | null;
  from_handle?: string;
  to_handle?: string;
}

interface FullMessage extends Message {
  body: string;
  from_id: string;
  to_id: string;
}

type Box = 'inbox' | 'sent' | 'compose' | 'read';

export function MessagesPage() {
  const [box, setBox] = useState<Box>('inbox');
  const [messages, setMessages] = useState<Message[]>([]);
  const [unread, setUnread] = useState(0);
  const [selected, setSelected] = useState<FullMessage | null>(null);
  const [loading, setLoading] = useState(false);

  // Compose state
  const [toHandle, setToHandle] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [sending, setSending] = useState(false);
  const [sendError, setSendError] = useState('');
  const [sendSuccess, setSendSuccess] = useState(false);

  const loadMessages = useCallback(async () => {
    if (box === 'compose' || box === 'read') return;
    setLoading(true);
    try {
      const res = await apiFetch(`/api/messages${box === 'sent' ? '?box=sent' : ''}`);
      const d = await res.json();
      if (d.ok) {
        setMessages(d.data.messages);
        if (d.data.unread !== undefined) setUnread(d.data.unread);
      }
    } finally {
      setLoading(false);
    }
  }, [box]);

  useEffect(() => { loadMessages(); }, [loadMessages]);

  const openMessage = async (msg: Message) => {
    const res = await apiFetch(`/api/messages/${msg.id}`);
    const d = await res.json();
    if (d.ok) {
      setSelected(d.data);
      setBox('read');
      if (!msg.read_at) setUnread((u) => Math.max(0, u - 1));
    }
  };

  const deleteMessage = async (id: string) => {
    if (!confirm('Delete this message?')) return;
    await apiFetch(`/api/messages/${id}`, { method: 'DELETE' });
    setBox('inbox');
    loadMessages();
  };

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    setSending(true);
    setSendError('');
    try {
      const res = await apiFetch('/api/messages', {
        method: 'POST',
        body: JSON.stringify({ toHandle, subject, body }),
      });
      const d = await res.json();
      if (!d.ok) { setSendError(d.error); return; }
      setSendSuccess(true);
      setToHandle('');
      setSubject('');
      setBody('');
      setTimeout(() => { setSendSuccess(false); setBox('sent'); }, 1500);
    } finally {
      setSending(false);
    }
  };

  const replyTo = (msg: FullMessage) => {
    setToHandle(msg.from_handle ?? '');
    setSubject(`Re: ${msg.subject}`);
    setBody('');
    setBox('compose');
  };

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <h1 className={styles.title}>PRIVATE MAIL</h1>
        {unread > 0 && <span className={styles.unreadBadge}>{unread} unread</span>}
      </div>

      <div className={styles.tabs}>
        <button
          className={box === 'inbox' || box === 'read' ? styles.tabActive : styles.tab}
          onClick={() => setBox('inbox')}
        >
          [ INBOX {unread > 0 ? `(${unread})` : ''} ]
        </button>
        <button
          className={box === 'sent' ? styles.tabActive : styles.tab}
          onClick={() => setBox('sent')}
        >
          [ SENT ]
        </button>
        <button
          className={box === 'compose' ? styles.tabActive : styles.tab}
          onClick={() => setBox('compose')}
        >
          [ COMPOSE ]
        </button>
      </div>

      {/* Inbox / Sent */}
      {(box === 'inbox' || box === 'sent') && (
        <div className={styles.messageList}>
          {loading && <div className={styles.empty}>Loading...</div>}
          {!loading && messages.length === 0 && (
            <div className={styles.empty}>
              {box === 'inbox' ? 'Your inbox is empty.' : 'No sent messages.'}
            </div>
          )}
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`${styles.messageRow} ${!msg.read_at && box === 'inbox' ? styles.unreadRow : ''}`}
              onClick={() => openMessage(msg)}
            >
              {!msg.read_at && box === 'inbox' && <span className={styles.unreadDot} />}
              <div className={styles.msgFrom}>
                {box === 'inbox' ? msg.from_handle : `→ ${msg.to_handle}`}
              </div>
              <div className={styles.msgSubject}>{msg.subject}</div>
              <div className={styles.msgDate}>
                {new Date(msg.created_at).toLocaleDateString()}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Read message */}
      {box === 'read' && selected && (
        <div className={styles.readView}>
          <div className={styles.readHeader}>
            <div className={styles.readSubject}>{selected.subject}</div>
            <div className={styles.readMeta}>
              From: <span className={styles.handle}>{selected.from_handle}</span>
              {' · '}
              {new Date(selected.created_at).toLocaleString()}
            </div>
          </div>
          <pre className={styles.readBody}>{selected.body}</pre>
          <div className={styles.readActions}>
            <button className="btn-primary" onClick={() => replyTo(selected)}>[ Reply ]</button>
            <button onClick={() => setBox('inbox')}>[ Back ]</button>
            <button className={styles.deleteBtn} onClick={() => deleteMessage(selected.id)}>[ Delete ]</button>
          </div>
        </div>
      )}

      {/* Compose */}
      {box === 'compose' && (
        <div className={styles.composeForm}>
          {sendSuccess ? (
            <div className={styles.success}>✅ Message sent successfully!</div>
          ) : (
            <form onSubmit={sendMessage}>
              <div className={styles.field}>
                <label className={styles.label}>TO (handle):</label>
                <input
                  type="text"
                  value={toHandle}
                  onChange={(e) => setToHandle(e.target.value)}
                  placeholder="username"
                  required
                  maxLength={32}
                  autoFocus
                />
              </div>
              <div className={styles.field}>
                <label className={styles.label}>SUBJECT:</label>
                <input
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="Message subject"
                  required
                  maxLength={255}
                />
              </div>
              <div className={styles.field}>
                <label className={styles.label}>MESSAGE:</label>
                <textarea
                  value={body}
                  onChange={(e) => setBody(e.target.value)}
                  placeholder="Write your message..."
                  rows={10}
                  required
                  className={styles.composeTextarea}
                />
              </div>
              {sendError && <div className={styles.error}>❌ {sendError}</div>}
              <div className={styles.composeActions}>
                <button type="submit" className="btn-primary" disabled={sending}>
                  {sending ? '[ SENDING... ]' : '[ SEND MESSAGE ]'}
                </button>
              </div>
            </form>
          )}
        </div>
      )}
    </div>
  );
}
