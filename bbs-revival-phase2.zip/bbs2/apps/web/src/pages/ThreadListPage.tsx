import { useEffect, useState, useCallback } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { apiFetch, useAuthStore } from '../stores/auth.store';
import styles from './ThreadListPage.module.css';

interface Thread {
  id: string;
  title: string;
  reply_count: number;
  view_count: number;
  locked: boolean;
  pinned: boolean;
  created_at: string;
  last_post_at: string;
  author_handle: string;
  last_poster_handle: string | null;
  hasUnread?: boolean;
}

interface Board {
  id: string;
  name: string;
  description: string;
  min_role: string;
  group_name?: string;
}

interface PageData {
  board: Board;
  threads: Thread[];
  total: number;
  page: number;
  limit: number;
}

export function ThreadListPage() {
  const { boardId } = useParams<{ boardId: string }>();
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [data, setData] = useState<PageData | null>(null);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [showNewThread, setShowNewThread] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newBody, setNewBody] = useState('');
  const [posting, setPosting] = useState(false);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiFetch(`/api/boards/${boardId}/threads?page=${page}`);
      const d = await res.json();
      if (d.ok) setData(d.data);
    } finally {
      setLoading(false);
    }
  }, [boardId, page]);

  useEffect(() => { load(); }, [load]);

  const submitThread = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newBody.trim()) return;
    setPosting(true);
    setError('');
    try {
      const res = await apiFetch(`/api/boards/${boardId}/threads`, {
        method: 'POST',
        body: JSON.stringify({ title: newTitle.trim(), body: newBody.trim() }),
      });
      const d = await res.json();
      if (!d.ok) { setError(d.error); return; }
      setShowNewThread(false);
      setNewTitle('');
      setNewBody('');
      navigate(`/boards/threads/${d.data.threadId}`);
    } finally {
      setPosting(false);
    }
  };

  if (loading) return <div className={styles.loading}>Loading threads...</div>;
  if (!data) return <div className={styles.loading}>Board not found.</div>;

  const totalPages = Math.ceil(data.total / data.limit);

  return (
    <div className={styles.page}>
      {/* Breadcrumb */}
      <div className={styles.breadcrumb}>
        <Link to="/boards" className={styles.crumb}>Boards</Link>
        <span className={styles.sep}> › </span>
        <span className={styles.crumbCurrent}>{data.board.name}</span>
      </div>

      {/* Header */}
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>{data.board.name.toUpperCase()}</h1>
          {data.board.description && (
            <p className={styles.desc}>{data.board.description}</p>
          )}
        </div>
        {user && (
          <button
            className="btn-primary"
            onClick={() => setShowNewThread(!showNewThread)}
          >
            {showNewThread ? '[ CANCEL ]' : '[ + NEW THREAD ]'}
          </button>
        )}
      </div>

      {/* New thread form */}
      {showNewThread && (
        <form className={styles.newThreadForm} onSubmit={submitThread}>
          <div className={styles.formLabel}>SUBJECT:</div>
          <input
            type="text"
            value={newTitle}
            onChange={(e) => setNewTitle(e.target.value)}
            placeholder="Thread subject..."
            maxLength={255}
            required
            autoFocus
          />
          <div className={styles.formLabel} style={{ marginTop: 12 }}>MESSAGE:</div>
          <textarea
            value={newBody}
            onChange={(e) => setNewBody(e.target.value)}
            placeholder="Write your message..."
            rows={8}
            required
            className={styles.textarea}
          />
          {error && <div className={styles.error}>❌ {error}</div>}
          <div className={styles.formActions}>
            <button type="submit" className="btn-primary" disabled={posting}>
              {posting ? '[ POSTING... ]' : '[ POST THREAD ]'}
            </button>
          </div>
        </form>
      )}

      <div className={styles.divider}>{'─'.repeat(80)}</div>

      {/* Column headers */}
      <div className={styles.colHeaders}>
        <span className={styles.colTitle}>SUBJECT</span>
        <span className={styles.colAuthor}>AUTHOR</span>
        <span className={styles.colReplies}>REPLIES</span>
        <span className={styles.colLast}>LAST POST</span>
      </div>

      {/* Thread list */}
      {data.threads.length === 0 ? (
        <div className={styles.empty}>No threads yet. Be the first to post!</div>
      ) : (
        data.threads.map((thread) => (
          <Link
            key={thread.id}
            to={`/boards/threads/${thread.id}`}
            className={`${styles.threadRow} ${thread.hasUnread ? styles.unread : ''} ${thread.pinned ? styles.pinned : ''}`}
          >
            <div className={styles.threadTitle}>
              {thread.pinned && <span className={styles.badge}>📌</span>}
              {thread.locked && <span className={styles.badge}>🔒</span>}
              {thread.hasUnread && <span className={styles.unreadDot} />}
              {thread.title}
            </div>
            <div className={styles.threadAuthor}>{thread.author_handle}</div>
            <div className={styles.threadReplies}>{thread.reply_count}</div>
            <div className={styles.threadLast}>
              <div>{thread.last_poster_handle ?? thread.author_handle}</div>
              <div className={styles.lastDate}>
                {new Date(thread.last_post_at).toLocaleDateString()}
              </div>
            </div>
          </Link>
        ))
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className={styles.pagination}>
          <button onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1}>
            [ ◀ PREV ]
          </button>
          <span className={styles.pageInfo}>
            Page {page} of {totalPages}
          </span>
          <button onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page === totalPages}>
            [ NEXT ▶ ]
          </button>
        </div>
      )}
    </div>
  );
}
