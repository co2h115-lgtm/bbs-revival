import { useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { apiFetch } from '../stores/auth.store';
import styles from './SearchPage.module.css';

interface ThreadResult {
  id: string;
  title: string;
  board_name: string;
  board_id: string;
  author_handle: string;
  reply_count: number;
  last_post_at: string;
}

interface PostResult {
  id: string;
  body: string;
  thread_id: string;
  thread_title: string;
  board_name: string;
  board_id: string;
  author_handle: string;
  created_at: string;
}

export function SearchPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [query, setQuery] = useState(searchParams.get('q') ?? '');
  const [type, setType] = useState<'all' | 'threads' | 'posts'>('all');
  const [results, setResults] = useState<{ threads: ThreadResult[]; posts: PostResult[]; total: number } | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const doSearch = async (q = query) => {
    if (!q.trim()) return;
    setLoading(true);
    setError('');
    setSearchParams({ q });
    try {
      const res = await apiFetch(`/api/search?q=${encodeURIComponent(q)}&type=${type}`);
      const d = await res.json();
      if (!d.ok) { setError(d.error); return; }
      setResults(d.data);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    doSearch();
  };

  return (
    <div className={styles.page}>
      <h1 className={styles.title}>SEARCH</h1>

      <form className={styles.searchForm} onSubmit={handleSubmit}>
        <div className={styles.searchRow}>
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search boards..."
            className={styles.searchInput}
            autoFocus
          />
          <button type="submit" className="btn-primary" disabled={loading}>
            {loading ? '[ ... ]' : '[ SEARCH ]'}
          </button>
        </div>

        <div className={styles.typeRow}>
          {(['all', 'threads', 'posts'] as const).map((t) => (
            <label key={t} className={styles.typeLabel}>
              <input
                type="radio"
                name="type"
                checked={type === t}
                onChange={() => setType(t)}
              />
              {t.charAt(0).toUpperCase() + t.slice(1)}
            </label>
          ))}
        </div>
      </form>

      {error && <div className={styles.error}>❌ {error}</div>}

      {results && (
        <div className={styles.results}>
          <div className={styles.summary}>
            {results.total === 0
              ? `No results found for "${searchParams.get('q')}"`
              : `Found ${results.threads.length} thread${results.threads.length !== 1 ? 's' : ''} and ${results.posts.length} post${results.posts.length !== 1 ? 's' : ''}`}
          </div>

          {results.threads.length > 0 && (
            <div className={styles.section}>
              <div className={styles.sectionHeader}>▸ THREADS</div>
              {results.threads.map((t) => (
                <Link key={t.id} to={`/boards/threads/${t.id}`} className={styles.resultRow}>
                  <div className={styles.resultTitle}>{t.title}</div>
                  <div className={styles.resultMeta}>
                    <span className={styles.boardName}>{t.board_name}</span>
                    {' · '}by <span className={styles.handle}>{t.author_handle}</span>
                    {' · '}{t.reply_count} replies
                  </div>
                </Link>
              ))}
            </div>
          )}

          {results.posts.length > 0 && (
            <div className={styles.section}>
              <div className={styles.sectionHeader}>▸ POSTS</div>
              {results.posts.map((p) => (
                <Link key={p.id} to={`/boards/threads/${p.thread_id}`} className={styles.resultRow}>
                  <div className={styles.resultTitle}>{p.thread_title}</div>
                  <div className={styles.resultSnippet}>
                    {p.body.substring(0, 180)}{p.body.length > 180 ? '...' : ''}
                  </div>
                  <div className={styles.resultMeta}>
                    <span className={styles.boardName}>{p.board_name}</span>
                    {' · '}by <span className={styles.handle}>{p.author_handle}</span>
                    {' · '}{new Date(p.created_at).toLocaleDateString()}
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
