# Phase 2 — Integration Instructions

This zip contains **only the new and changed files** for Phase 2. Follow these steps to merge them into your Phase 1 project.

---

## New Files (just copy into place)

### Server
```
apps/server/src/services/thread.service.ts   → copy as-is
apps/server/src/services/pm.service.ts        → copy as-is
apps/server/src/services/search.service.ts    → copy as-is
apps/server/src/routes/thread.routes.ts       → copy as-is
apps/server/src/routes/pm.routes.ts           → copy as-is
apps/server/src/routes/search.routes.ts       → copy as-is
```

### Web
```
apps/web/src/pages/ThreadListPage.tsx         → copy as-is
apps/web/src/pages/ThreadListPage.module.css  → copy as-is
apps/web/src/pages/ThreadPage.tsx             → copy as-is
apps/web/src/pages/ThreadPage.module.css      → copy as-is
apps/web/src/pages/MessagesPage.tsx           → copy as-is
apps/web/src/pages/MessagesPage.module.css    → copy as-is
apps/web/src/pages/SearchPage.tsx             → copy as-is
apps/web/src/pages/SearchPage.module.css      → copy as-is
```

---

## Files to Replace Entirely

These replace the Phase 1 versions completely:

```
apps/server/src/index.ts           → replace with Phase 2 version
apps/web/src/App.tsx               → replace with Phase 2 version
apps/web/src/components/Shell.tsx  → replace with Phase 2 version
```

---

## Shell.module.css — Append Only

Open `apps/web/src/components/Shell.module.css` and **append** the contents of
`apps/web/src/components/Shell.additions.module.css` to the bottom.

---

## No New Dependencies

Phase 2 uses only packages already installed in Phase 1. No `pnpm install` needed.

---

## No New Migrations

All tables used in Phase 2 (threads, posts, private_messages, thread_reads) were already
created in Phase 1 migrations 008–013. No migration step needed.

---

## After Merging — Test It

```bash
pnpm dev
```

Then open http://localhost:5173 and:

1. Log in with sysop@bbs.local / changeme123
2. Click Message Boards → click a board → you should see the thread list
3. Click the Welcome thread → you should see the post
4. Try posting a reply
5. Try Private Mail → Compose → send a message to SYSOP
6. Try Search in the sidebar

---

## What's New in Phase 2

| Feature | Where |
|---------|-------|
| Thread list with unread dots | `/boards/:boardId` |
| Thread view with paginated posts | `/boards/threads/:threadId` |
| New thread form | Thread list page |
| Reply with quote | Thread page |
| Edit posts (1hr window for users, always for sysop) | Thread page |
| Soft-delete posts | Thread page |
| Sysop: lock, pin, move, delete threads | Thread page |
| Private messaging inbox/compose/read | `/messages` |
| Full-text search | `/search` + sidebar |
| Unread PM badge in sidebar | Shell |
| Search bar in sidebar | Shell |
